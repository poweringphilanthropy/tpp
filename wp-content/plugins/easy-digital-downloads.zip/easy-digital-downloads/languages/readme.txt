********************************************************

  Easy Digital Downloads I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Easy Digital Downloads updates.
  
  Keep custom EDD translations in /wp-content/languages/edd/
  
  You want to translate, help, or improve a translation.
  
  Join our WP-Translations Community at
  https://www.transifex.com/projects/p/easy-digital-downloads/

  More info at http://wp-translations.org/

********************************************************
