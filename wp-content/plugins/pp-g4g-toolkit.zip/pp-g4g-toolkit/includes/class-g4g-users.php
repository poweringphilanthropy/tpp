<?php
/**
 * G4G_Users Class.
 *
 * @class       G4G_Users
 * @version     1.0
 * @author lafif <hello@lafif.me>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * G4G_Users class.
 */
class G4G_Users {

    private $post_types;
    private $taxonomies;
    private $metaboxes;
    private $taxonomy_name = 'college';

    /**
     * Singleton method
     *
     * @return self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new G4G_Users();
        }

        return $instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->includes();

        add_action( 'init', array($this, 'create_post_types_and_tax'), 11 );

        add_filter( 'charitable_submenu_pages', array($this, 'add_to_submenu'), 10, 1 );

        add_filter( 'charitable_user_fields', array($this, 'g4g_charitable_user_fields'), 30, 2 );

    }

    public function create_post_types_and_tax(){

        // create taxonomy for university
        $this->taxonomies[$this->taxonomy_name] = register_cuztom_taxonomy( $this->taxonomy_name, 'campaign', array(
            // 'rewrite' => array(
            //  'slug' => 'dashboard'
            // ),
            'public' => false,
            // 'show_admin_column' => true,
            // 'admin_column_sortable' => true,
            // 'admin_column_filter' => true
        ) );
    }

    public function add_to_submenu($menu){

        $leaderboard_menu = array(
            array(
                'page_title' => __('Colleges / Universities', 'philanthropy'),
                'menu_title' => __('Colleges', 'philanthropy'),
                'menu_slug' => 'edit-tags.php?taxonomy='.$this->taxonomy_name.'&post_type=campaign',
            )
        );

        array_splice( $menu, 5, 0, $leaderboard_menu ); // splice in at position 3

        return $menu;
    }

    public function g4g_charitable_user_fields( $fields, $form ) {

        $fields[ 'chapter' ][ 'attrs' ] = array(
            'label' => __('Fraternity/Sorority Name', 'philanthropy'),
            'data-source' => esc_attr( wp_json_encode( g4g_get_parent_campaign_group_names() ) ),
            'class' => 'autocomplete',
        );

        $fields[ 'organisation' ][ 'attrs' ] = array(
            'label' => __('College/University Name', 'philanthropy'),
            'data-source' => esc_attr( wp_json_encode( g4g_get_college_names() ) ),
            'class' => 'autocomplete',
        );

        return $fields;
    }


    public function includes(){

    }

}

G4G_Users::init();