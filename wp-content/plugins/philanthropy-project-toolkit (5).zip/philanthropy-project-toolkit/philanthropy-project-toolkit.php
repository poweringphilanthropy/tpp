<?php
/**
 * Plugin Name:     Philanthropy Project - Toolkit
 * Plugin URI:      http://www.poweringphilanthropy.com/
 * Description:     Custom features for The Philanthropy Project
 * Author:          Powering Philanthropy
 * Author URI:      http://www.poweringphilanthropy.com/
 * Author Email:    info@poweringphilanthropy.com
 * Version:         2.0
 * Text Domain:     pp-toolkit
 * Domain Path:     /languages/ 
 */

if (!defined('ABSPATH')) exit;


/**
 * Philanthropy_Project
 *
 * @since       1.0.0
 */
class Philanthropy_Project {

    /**
     * @var Philanthropy_Project
     */
    private static $instance = null;

    /**
     * The root file of the plugin. 
     * 
     * @var     string
     * @access  private
     */
    private $plugin_file; 

    /**
     * The root directory of the plugin.
     *
     * Setting these to public until a better function can be built than "get_path()"
     *
     * @var     string
     * @access  private
     */
    public $directory_path;

    /**
     * The root directory of the plugin as a URL.  
     *
     * @var     string
     * @access  private
     */
    public $directory_url;

    /**
	 * @var string
	 */
	public $version = '2.0';

    /**
     * Create class instance. 
     * 
     * @return  void
     * @since   1.0.0
     */
    public function __construct() {        
        $this->plugin_file      = __FILE__;
        $this->directory_path   = plugin_dir_path( __FILE__ );
        $this->directory_url    = plugin_dir_url( __FILE__ );

        $this->load_dependencies();

        register_activation_hook( __FILE__, array( $this, 'install' ) );
        register_uninstall_hook( __FILE__, 'uninstall' );
        
        add_action( 'charitable_start', array( $this, 'start' ), 10 );
    }

    /**
     * All install stuff
     * @return [type] [description]
     */
    public function install() {
        
        do_action( 'on_pp_toolkit_install' );
    }

    /**
     * All uninstall stuff
     * @return [type] [description]
     */
    public function uninstall() {

        do_action( 'on_pp_toolkit_uninstall' );
    }

    /**
     * Returns the original instance of this class. 
     * 
     * @return  Charitable
     * @since   1.0.0
     */
    public static function get_instance() {

    	if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
    }

    /**
     * Start the plugin functionality. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function start() {

        /* If we've already started (i.e. run this function once before), do not pass go. */
        if ( $this->started() ) {
            return;
        }

        /* Set static instance */
        self::$instance = $this;

        $this->attach_hooks_and_filters();

        /* Hook in here to do something when the plugin is first loaded */
        do_action('philanthropy_project_start', $this);
    }

    /**
     * Include necessary files.
     * 
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function load_dependencies() {

        /**
         * Main PP Toolkit Functions
         */
        include_once( $this->directory_path . 'includes/functions-pp-toolkit.php' );

        // Bootstrap Campaigns
        include_once( $this->directory_path . 'includes/class-pp-charitable-campaign-form.php');

        /**
         * Helper Classes
         */
        include_once( $this->directory_path . 'helpers/cuztom/cuztom.php');
        include_once( $this->directory_path . 'helpers/class-rename-wp-login.php');
        include_once( $this->directory_path . 'helpers/class-aq_resizer.php');
        include_once( $this->directory_path . 'helpers/class-pp-charitable-fundraisers-donor-query.php');
        include_once( $this->directory_path . 'helpers/class-pp-charitable-leaderboard.php');

        /**
         * Plugin modifications
         */
        include_once( $this->directory_path . 'plugin-modifications/class-pp-charitable.php');
        include_once( $this->directory_path . 'plugin-modifications/class-pp-charitable-ambassadors.php');
        include_once( $this->directory_path . 'plugin-modifications/class-pp-charitable-edd.php');
        include_once( $this->directory_path . 'plugin-modifications/class-pp-edd.php');
        include_once( $this->directory_path . 'plugin-modifications/class-pp-edd-stripe.php');
        include_once( $this->directory_path . 'plugin-modifications/class-pp-ninja-form.php');

        /**
         * Our classes
         */
        if(is_admin()){
            include_once( $this->directory_path . 'includes/class-pp-admin.php');
        }

        include_once( $this->directory_path . 'includes/class-pp-templates.php');
        include_once( $this->directory_path . 'includes/class-pp-embed-media.php');
        include_once( $this->directory_path . 'includes/class-pp-frontend.php');
        include_once( $this->directory_path . 'includes/class-pp-shortcodes.php');
        include_once( $this->directory_path . 'includes/class-pp-widgets.php');
        include_once( $this->directory_path . 'includes/class-pp-exports.php');
        include_once( $this->directory_path . 'includes/class-pp-reports.php');
        include_once( $this->directory_path . 'includes/class-pp-users.php');
        include_once( $this->directory_path . 'includes/class-pp-emails.php');
        include_once( $this->directory_path . 'includes/class-pp-chapters.php');
        include_once( $this->directory_path . 'includes/class-pp-leaderboard.php');
        include_once( $this->directory_path . 'includes/class-pp-team-fundraising.php');
        include_once( $this->directory_path . 'includes/class-pp-rest-api.php');
    }

    /**
     * Set up hook and filter callback functions.
     * 
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function attach_hooks_and_filters() {

        /**
         * Load our campaign class on philanthropy_project_start
         */
        add_action( 'philanthropy_project_start', array( 'PP_Charitable_Campaign_Form', 'start' ) );
        
        add_action( 'init', array($this, 'register_scripts') );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
   
    }

    /**
     * Returns whether we are currently in the start phase of the plugin. 
     *
     * @return  bool
     * @access  public
     * @since   1.0.0
     */
    public function is_start() {
        return current_filter() == 'philanthropy_project_start';
    }

    /**
     * Returns whether the plugin has already started.
     * 
     * @return  bool
     * @access  public
     * @since   1.0.0
     */
    public function started() {
        return did_action( 'philanthropy_project_start' ) || current_filter() == 'philanthropy_project_start';
    }

    public function register_scripts(){
        
        /* admin */
        wp_register_style( 'pp-toolkit-admin', plugins_url( '/assets/css/pp-toolkit-admin.css', __FILE__ ) );
        wp_register_script( 'pp-toolkit-admin', plugins_url( '/assets/js/pp-toolkit-admin.js', __FILE__ ), array('jquery'), $this->version, true );

        wp_register_script( 'pp-registration-handler', $this->directory_url.'assets/js/registration-handler.js', array( 'jquery-ui-datepicker' ), '1.0.0', true );


        /* This script is registered here, but enqueued by the form class to ensure that it's only loaded when we're looking at the form. */
        wp_register_script( 'cropit', plugins_url( '/assets/js/jquery.cropit.js', __FILE__ ), array('jquery'), $this->version, true );
        wp_register_script( 'smartWizard', plugins_url( '/assets/js/jquery.smartWizard.js', __FILE__ ), array('jquery'), $this->version, true );
        
        wp_register_script( 'sweetalert', plugins_url( '/assets/js/sweetalert.min.js', __FILE__ ), array(), $this->version, true );
       
        wp_register_style( 'pp-toolkit-campaign-submission', plugins_url( '/assets/css/pp-toolkit-campaign-submission.css', __FILE__ ), array(), $this->version );
        wp_register_script( 'pp-toolkit-campaign-submission', plugins_url( '/assets/js/pp-toolkit-campaign-submission.js', __FILE__ ), array('jquery', 'smartWizard', 'jquery-ui-datepicker'), $this->version, true );

        wp_register_style( 'philanthropy-modal', plugins_url( '/assets/css/philanthropy-modal.css', __FILE__ ) );
        wp_register_script( 'philanthropy-modal', plugins_url( '/assets/js/philanthropy-modal.js', __FILE__ ), array('jquery'), $this->version, true );

        wp_register_style( 'pp-toolkit', $this->directory_url.'assets/css/pp-toolkit.css', false, '1.0' );
        wp_register_script( 'pp-toolkit', plugins_url( '/assets/js/pp-toolkit.js', __FILE__ ), array('jquery'), $this->version, true );

        /* For Volunteer, but should extend to all modals eventually */
        // wp_register_style( 'animate', '//cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.0/animate.min.css', false, '3.2.0');
        // wp_register_script( 'pt-animatedModal', $this->directory_url.'assets/js/animatedModal.min.js', false, '1.0');
        // wp_register_script('font-awesome', 'https://use.fontawesome.com/4897c4c6a4.js', false, false);
    
        // dashboard embed related
        wp_register_script( 'iframeResizer', plugins_url( '/assets/js/iframe-resizer.min.js', __FILE__ ), array(), $this->version, true );
    }

    /**
     * Load custom scripts.  
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function enqueue_scripts() {

        wp_enqueue_style( 'pp-toolkit' );
        wp_enqueue_script( 'pp-toolkit' );
        // wp_enqueue_style('animate');
        // wp_enqueue_script('pt-animatedModal');
        // wp_enqueue_script('font-awesome');
        
        wp_enqueue_script( 'sweetalert' );

        // TODO | Check if dashboard widget page
        if(charitable_is_page( 'leaderboard_widget' )){
            wp_enqueue_script( 'iframeResizer' );
        }

        if ( charitable_is_page( 'registration_page' ) ) {
            wp_enqueue_script( 'pp-registration-handler' );
        }

        if ( charitable_is_page( 'campaign_submission_page' ) ) {

            wp_enqueue_script( 'charitable-script' );
            wp_enqueue_script( 'charitable-plup-fields' );
            wp_enqueue_style( 'charitable-plup-styles' );

            wp_enqueue_style( 'pp-toolkit-campaign-submission' );
            wp_enqueue_script( 'pp-toolkit-campaign-submission' );

            ob_start();

            pp_toolkit_template( 'form-fields/donation-levels-row.php', array(
                'index'       => '{index}',
                'key'         => 'suggested_donations',
                'amount'      => '',
                'description' => '',
            ) );

            $row = ob_get_clean();

            ob_start();

            pp_toolkit_template( 'form-fields/sponsors-row.php', array(
                'index'       => '{index}',
                'key'         => 'sponsors',
                'value'      => '',
            ) );

            $sponsors_row = ob_get_clean();

            $vars = array(
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'donation_levels_row' => $row,
                'sponsors_row' => $sponsors_row,
            );

            wp_localize_script(
                'pp-toolkit-campaign-submission',
                'PP_CAMPAIGN_SUBMISSION',
                $vars
            );
            
        }
    }

} // end class


/**
 * Notice if dependencies not activated
 * @return [type] [description]
 */
function pp_toolkit_need_deps(){
	?>
    <div class="updated">
        <p><?php _e('Please activate required plugins', 'pp-toolkit'); ?></p>
    </div>
    <?php
}

/**
 * Returns the main instance of PP_Toolkit to prevent the need to use globals.
 *
 * @since  1.0
 * @return PP_Toolkit
 */
function pp_toolkit() {

	$needed = array(
		'easy-digital-downloads/easy-digital-downloads.php',
		'charitable/charitable.php',
		'charitable-ambassadors/charitable-ambassadors.php',
		'charitable-edd/charitable-edd.php',
		'the-events-calendar/the-events-calendar.php',
		'event-tickets/event-tickets.php',
		'event-tickets-plus/event-tickets-plus.php',
	);

	$activated = apply_filters( 'active_plugins', get_option( 'active_plugins' ) );

	$pass = count(array_intersect($needed, $activated)) == count($needed);

	// var_dump($pass);
	// echo "<pre>";
	// print_r($activated);
	// echo "</pre>";
	// exit();

	if ( $pass ) {
		return Philanthropy_Project::get_instance();
	} else {
		add_action( 'admin_notices', 'pp_toolkit_need_deps' );
	}
}

$GLOBALS['pp-toolkit'] = pp_toolkit();