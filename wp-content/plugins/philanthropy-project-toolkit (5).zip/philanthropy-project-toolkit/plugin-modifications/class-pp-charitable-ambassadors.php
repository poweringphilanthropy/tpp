<?php
/**
 * PP_Charitble_Ambassadors Class.
 * Overrides plugin dependencies template
 *
 * @class       PP_Charitble_Ambassadors
 * @version     1.0
 * @author lafif <hello@lafif.me>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * PP_Charitble_Ambassadors class.
 */
class PP_Charitble_Ambassadors {

    /**
     * Singleton method
     *
     * @return self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new PP_Charitble_Ambassadors();
        }

        return $instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->includes();

        add_action( 'wp_ajax_create_dummy_post', array($this, 'create_dummy_post_id') );
        add_filter( 'charitable_ambassadors_form_submission_buttons_primary_new_text', array($this, 'form_submission_buttons_primary_new_text'), 10, 1 );
    }

    /**
     * Create dummy post id for preview campaign
     * @return [type] [description]
     */
    public function create_dummy_post_id(){
        $id = wp_insert_post(array('post_type' => 'campaign'));
        if( is_wp_error( $id ) ) {
            $id = 0;
        }

        echo $id;
        exit();
    }

    public function form_submission_buttons_primary_new_text($text){
        $text = __('Launch Campaign', 'philanthropy');
        return $text;
    }

    public function includes(){

    }

}

PP_Charitble_Ambassadors::init();