<?php
/**
 * PP_Leaderboard Class.
 *
 * @class       PP_Leaderboard
 * @version     1.0
 * @author lafif <hello@lafif.me>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * PP_Leaderboard class.
 */
class PP_Leaderboard {

    private $post_types;
    private $taxonomies;
    private $metaboxes;
    private $taxonomy_name = 'campaign_group';

    /**
     * Singleton method
     *
     * @return self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new PP_Leaderboard();
        }

        return $instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->includes();

        add_action( 'init', array($this, 'create_post_types_and_tax'), 11 );
        add_filter( 'charitable_submenu_pages', array($this, 'add_to_submenu'), 10, 1 );

        add_filter( 'template_include', array($this, 'leaderboard_template_include'), 1, 1 );
        add_action( 'philanthropy_after_dashboard_content', array($this, 'display_share'), 10 );

        add_filter( 'charitable_is_page_leaderboard_widget', array($this, 'is_page_leaderboard_widget'), 2 );
        add_filter( 'body_class', array( $this, 'add_body_classes' ) );
        add_filter( 'cuztom_field_name', array($this, 'remove_name_for_widget_input'), 10, 2 );
    }

    public function create_post_types_and_tax(){

        // create post type
        $this->post_types['dashboard'] = register_cuztom_post_type('Dashboard', array(
            'supports' => array( 'title', 'editor', 'thumbnail' ),
            'menu_icon' => 'dashicons-awards',
            'show_in_menu' => false
        ) );

        // $this->post_types['chapter'] = register_cuztom_post_type('Chapter', array(
        //     'supports' => array( 'title', 'editor', 'thumbnail' ),
        //     'menu_icon' => 'dashicons-awards',
        //     'show_in_menu' => true,
        //     // 'public' => false
        // ) );

        // create post type
        $this->taxonomies[$this->taxonomy_name] = register_cuztom_taxonomy( $this->taxonomy_name, 'campaign', array(
            // 'rewrite' => array(
            //  'slug' => 'dashboard'
            // ),
            'public' => true,
            // 'show_admin_column' => true,
            // 'admin_column_sortable' => true,
            // 'admin_column_filter' => true
        ) );

        /**
         * Add metabox
         */
        $this->metaboxes['campaign_groups'] = register_cuztom_meta_box(
            'campaign_groups',
            'dashboard',
            array(
                'title'  => __('Associated Groups', 'philanthropy'),  
                'fields' => array(
                    array(
                        'id'            => '_campaign_group',
                        'type'          => 'select',
                        'label'         => __('Campaign Group', 'philanthropy'),
                        'options'       => $this->get_campaign_groups(),
                        // 'show_admin_column'     => true,
                        // 'admin_column_sortable' => true,
                        // 'admin_column_filter'   => true,
                    ),
                    array(
                        'id'            => '_support_email',
                        'type'          => 'text',
                        'label'         => __('Support Email', 'philanthropy'),
                        // 'show_admin_column'     => true,
                        // 'admin_column_sortable' => true,
                        // 'admin_column_filter'   => true,
                    )
                )
            ),
            'side'
        );

        $this->metaboxes['display'] = register_cuztom_meta_box(
            'display',
            'dashboard',
            array(
                'title'  => __('Display', 'philanthropy'),  
                'fields' => array(
                    array(
                        'id'    => '_page_color',
                        'type'  => 'color',
                        'label' => __('Color', 'philanthropy'),
                    ),
                )
            ),
            'side'
        );

        // Community Service Hours
        $this->metaboxes['service_hours'] = register_cuztom_meta_box(
            'service_hours',
            'dashboard',
            array(
                'title'  => __('Community Service Hours', 'philanthropy'),  
                'fields' => array(
                    array(
                        'id'                    => '_enable_log_service_hours',
                        'type'                  => 'yesno',
                        'label'                 => __('Enable Tracking'),
                        'default_value'         => 'no',
                        // 'show_admin_column'     => false,
                        // 'admin_column_sortable' => false,
                        // 'admin_column_filter'   => false,
                    ),
                    array(
                        'id'                    => '_prepopulate_chapters',
                        'type'                  => 'yesno',
                        'label'                 => __('Prepopulate Chapters'),
                        'default_value'         => 'no',
                        // 'show_admin_column'     => false,
                        // 'admin_column_sortable' => false,
                        // 'admin_column_filter'   => false,
                    ),
                )
            ),
            'normal'
        );


        if(isset($_GET['post'])){
            $this->metaboxes['widget'] = register_cuztom_meta_box(
                'widget',
                'dashboard',
                array(
                    'title'  => __('Widget', 'philanthropy'),  
                    'fields' => array(
                        array(
                            'id'                    => 'widget_embed_code',
                            'type'                  => 'textarea',
                            'label'                 => __('Widget embed code'),
                            'default_value'         => pp_get_dashbaord_embed_code(intval($_GET['post'])),
                            'args'                  => array(
                                'class' => 'dasdasd'
                            ),
                            // 'show_admin_column'     => false,
                            // 'admin_column_sortable' => false,
                            // 'admin_column_filter'   => false,
                        ),
                    )
                ),
                'normal'
            );
        }
    }

    public function add_to_submenu($menu){

        $leaderboard_menu = array(
            array(
                'page_title' => __('Dashboards', 'philanthropy'),
                'menu_title' => __('Dashboards', 'philanthropy'),
                'menu_slug' => 'edit.php?post_type=dashboard',
            ),
            array(
                'page_title' => __('Campaign Groups', 'philanthropy'),
                'menu_title' => __('Groups', 'philanthropy'),
                'menu_slug' => 'edit-tags.php?taxonomy='.$this->taxonomy_name.'&post_type=campaign',
            )
        );

        array_splice( $menu, 3, 0, $leaderboard_menu ); // splice in at position 3

        return $menu;
    }
    
    public function get_campaign_groups(){
        $terms = get_terms( array(
            'taxonomy' => $this->taxonomy_name,
            'hide_empty' => false,
            'fields' => 'id=>name'
        ) );

        $terms = (is_array($terms) && !is_wp_error( $terms )) ? $terms : array();

        return array('0' => __('Please select group', 'philanthropy') ) + $terms;
    }

    public function display_share($post){
        echo '<div class="campaign-summary" style="border: none;padding: 0px;">';
        echo '<div class="share-under-desc">';
        pp_toolkit_template( 'dashboard/share.php', array('dashboard' => $post) );
        echo '</div>';
        echo '</div>';
    }

    public function leaderboard_template_include($template){

        // disable force user dashboard template
        if(is_tax($this->taxonomy_name)){
            add_filter( 'charitable_force_user_dashboard_template', '__return_false', 100 );
        }

        if ( charitable_is_page( 'leaderboard_widget' ) ) {

            do_action( 'charitable_is_widget' );

            add_filter( 'show_admin_bar', '__return_false' );
            add_action( 'wp_head', 'charitable_hide_admin_bar' );

            $new_template = apply_filters( 'charitable_widget_page_template', 'dashboard-widget.php' );
            $template = pp_get_template_path( $new_template, $template );
        }

        return $template;
    }

    public function is_page_leaderboard_widget(){
        global $wp_query;

        return $wp_query->is_main_query()
            && isset( $wp_query->query_vars['widget'] )
            && $wp_query->is_singular( 'dashboard' );
    }

    public function add_body_classes( $classes ) {
        if ( charitable_is_page( 'leaderboard_widget' ) ) {
            $classes[] = 'dashboard-widget';
            $classes[] = 'single-campaign';
            $classes[] = 'campaign-widget';
        }

        return $classes;
    }

    public function remove_name_for_widget_input($name, $Field){
        if($Field->id == 'widget_embed_code'){
            $name = "";
        }

        return $name;
    }

    public function includes(){

    }

}

PP_Leaderboard::init();