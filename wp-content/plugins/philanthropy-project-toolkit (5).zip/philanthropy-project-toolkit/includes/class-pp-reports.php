<?php
/**
 * PP_Reports Class.
 * Overrides plugin dependencies template
 *
 * @class       PP_Reports
 * @version     1.0
 * @author lafif <hello@lafif.me>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * PP_Reports class.
 */
class PP_Reports {

    /**
     * Singleton method
     *
     * @return self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new PP_Reports();
        }

        return $instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->includes();

        add_action( 'init', array( $this, 'add_rewrite_rule' ), 10 );
        add_filter( 'query_vars', array($this, 'add_query_vars'));
        add_filter( 'wp_title', array($this, 'modify_title'), 100, 1 );

        add_filter( 'charitable_campaign_submission_form_args', array($this, 'hide_charitable_submit_campaign') );
        add_action( 'charitable_submit_campaign_shortcode_hidden', array($this, 'display_pp_action'), 10, 1 );

        add_filter( 'charitable_permalink_campaign_report_page', array($this, 'charitable_get_campaign_report_page_permalink'), 2, 2 ); 
        
        add_action('init', array($this, 'maybe_download_campaign_reports'));
    }

    public function add_query_vars($vars){
        $vars[] = "view_report";
        return $vars;
    }

    public function modify_title($title){

        if(get_query_var( 'view_report', false )){
            $title = __('Campaign Reports', 'pp-toolkit');
        }

        return $title;
    }

    /**
     * Add endpoint for report campaigns.
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function add_rewrite_rule() {
        add_rewrite_rule( '(.?.+?)/([0-9]+)/report/?$', 'index.php?pagename=$matches[1]&campaign_id=$matches[2]&view_report=true', 'top' );
    }

    public function hide_charitable_submit_campaign($args){

        if( !get_query_var( 'view_report', false ) || !get_query_var( 'campaign_id', false ) )
            return $args;

        $campaign  = new Charitable_Campaign( get_query_var( 'campaign_id' ) );
        if($campaign->post_author != get_current_user_id())
            return $args;

        $args['hidden'] = true;
        $args['view_report'] = true;
        $args['campaign'] = $campaign;

        return $args;
    }

    public function display_pp_action($args){
        if ( ! $args['view_report'] )
            return;

        pp_toolkit_template('reports/campaign-report.php', array(
            'campaign' => $args['campaign']
        ));
    }

    public function charitable_get_campaign_report_page_permalink( $url, $args = array() ) {
        global $wp_rewrite;
        
        $campaign_id = isset( $args[ 'campaign_id' ] ) ? $args[ 'campaign_id' ] : get_the_ID();
        $base_url = charitable_get_permalink( 'campaign_submission_page' );

        if ( $base_url ) {

            if ( $wp_rewrite->using_permalinks() ) {
                $url = trailingslashit( $base_url ) . $campaign_id . '/report/';
            }
            else {
                $url = esc_url_raw( add_query_arg( array( 'campaign_id' => $campaign_id ), $base_url ) );   
            }

        }    

        return $url;
    }

    public static function sort_by_amount($a, $b) {
        return $b["amount"] - $a["amount"];
    }

    public static function sort_by_last_name($a, $b) {
        return strcmp($a["last_name"], $b["last_name"]);
    }

    /**
     * Get campaign reports
     * @param  [type] $campaign_id [description]
     * @return [type]              [description]
     */
    public static function get_campaign_reports($campaign_id) {

        $campaign_ids = pp_get_merged_team_campaign_ids($campaign_id);

        $query_args = array(
            'campaign_id' => $campaign_ids,
        );
        $report = charitable_get_table( 'campaign_donations' )->get_donations_report( $query_args );

        // containers
        $donations_from_edd_log = array();
        $payment_ids = array();

        $data = array();
        $fundraisers_details = array();
        $donation_details = array();

        $ticket_details = array();
        $ticket_qty_by_options = array();

        $merchandise_details = array();
        $merchandise_qty_by_options = array();

        $total_amount = array(
            'fundraisers' => 0,
            'donations' => 0,
            'tickets' => 0,
            'merchandises' => 0,
        );

        $total_fundraising = 0;

        foreach ($report as $key => $r) {

            if ( get_post_status ( $r->donation_id ) != 'charitable-completed' ){
                continue;
            }

            // echo "<hr>";

            if(!isset($payment_ids[$r->donation_id])){
                $payment_ids[$r->donation_id] = Charitable_EDD_Payment::get_payment_for_donation( $r->donation_id );
            }

            if(!isset($donations_from_edd_log[$r->donation_id])){
                $donations_from_edd_log[$r->donation_id] = get_post_meta( $r->donation_id, 'donation_from_edd_payment_log', true );
            }

            /**
             * Payment data
             * @var EDD_Payment
             */
            $payment        = new EDD_Payment( $payment_ids[$r->donation_id] );
            $payment_meta   = edd_get_payment_meta( $payment->ID );
            $downloads      = edd_get_payment_meta_cart_details( $payment->ID );
            $fees           = edd_get_payment_fees( $payment->ID, 'item' );

            // debug 
            // $r->original_log = $donations_from_edd_log[$r->donation_id];
            // $r->downloads = $downloads;
            // $r->fees = $fees;


            /**
             * DEFAULT DATA
             * @var [type]
             */
            $r->purchase_detail = sprintf(__('Donation for %s', 'pp-toolkit'), $r->campaign_name );
            $r->date = mysql2date( 'l, F j, Y', $r->post_date );
            $r->time = mysql2date( 'H:i A', $r->post_date );
            $r->shipping = 0;
            $r->ticket_holder = '';
            $r->chapter = (isset($payment_meta['chapter']) && !empty($payment_meta['chapter'])) ? $payment_meta['chapter'] : 'na'; // maybe need on future
            $r->referral = (isset($payment_meta['referral']) && !empty($payment_meta['referral'])) ? $payment_meta['referral'] : 'na';
            $r->payment_gateway = $payment->gateway;

            $edd_log = false;

            /**
             * Get matched edd log
             */
            if(!empty($donations_from_edd_log[$r->donation_id])):
            foreach ($donations_from_edd_log[$r->donation_id] as $key => $log) {

                // check campaign id
                if($log['campaign_id'] != $r->campaign_id){
                    unset($donations_from_edd_log[$r->donation_id][$key]);
                    continue;
                }

                // if found
                if($r->amount == $log['amount']) {
                    $edd_log = $log;
                    unset($donations_from_edd_log[$r->donation_id][$key]);
                    break;
                }
            }
            endif;

            if($log){
                if(isset($log['download_id']) && $downloads){

                    // default item name
                    $download_description = get_the_title( $log['download_id'] );
                    $r->qty = 1;

                    // unique key for grouping
                    $download_unique_key = $log['download_id'];

                    // parse download
                    foreach ($downloads as $key => $d) {
                        if($log['download_id'] != $d['id'] )
                            continue;

                        $options = isset($d['item_number']['options']) ? $d['item_number']['options'] : array();
                        if ( isset( $d['item_number'] ) && isset( $d['item_number']['options'] ) ):
                        $price_options = $d['item_number']['options'];
                        $price_id   = isset( $d['item_number']['options']['price_id'] ) ? $d['item_number']['options']['price_id'] : null;
                        if ( edd_has_variable_prices( $log['download_id'] ) && !is_null( $price_id ) ) {
                            // append unique key
                            $download_unique_key .= '-' . $price_id;

                            // append description
                            $download_description .= ' - ' . edd_get_price_option_name( $log['download_id'], $price_id, $payment->ID );
                        }
                        endif;

                        // ticket holder
                        if (isset($options['tribe-tickets-meta']) 
                            && is_array($options['tribe-tickets-meta']) 
                            && !empty($options['tribe-tickets-meta']))
                        {
                            $_ticket_holder = wp_list_pluck( $options['tribe-tickets-meta'], 'ticket-holder-name' );
                            $r->ticket_holder = implode(', ', $_ticket_holder);
                        }

                        // shipping
                        if($d['fees']):
                        foreach ( $d[ 'fees' ] as $fee_id => $fee ) {
                            if ( false === strpos( $fee_id, 'simple_shipping' ) ) {
                                continue;
                            }

                            $r->shipping = (isset($fee['amount'])) ? $fee['amount'] : 0;
                            break;
                        }
                        endif;

                        $r->purchase_detail = $download_description;
                        $r->qty = $d['quantity'];
                        // $r->amount = $d['subtotal'];
                        break;
                    }

                    // ticket
                    if (has_term('ticket', 'download_category', $log['download_id'] )) {

                        $r->type = 'ticket';

                        $total_amount['tickets'] += $r->amount;

                        // count unique ids
                        if(!isset($ticket_qty_by_options[$download_unique_key])){
                            $ticket_qty_by_options[$download_unique_key] = array(
                                'name' => $download_description,
                                'qty' => $r->qty,
                            );
                        } else {
                            $ticket_qty_by_options[$download_unique_key]['qty'] += $r->qty;
                        }

                        $ticket_details[] = (array) $r;

                    } else {

                        $r->type = 'merchandise';

                        $total_amount['merchandises'] += $r->amount;

                        // count unique ids
                        if(!isset($merchandise_qty_by_options[$download_unique_key])){
                            $merchandise_qty_by_options[$download_unique_key] = array(
                                'name' => $download_description,
                                'qty' => $r->qty,
                            );
                        } else {
                            $merchandise_qty_by_options[$download_unique_key]['qty'] += $r->qty;
                        }

                        $merchandise_details[] = (array) $r;
                    }

                } else {
                    
                    $r->type = 'donation';

                    /**
                     * Display as Mobile donation if donation coming from rest api
                     */
                    if($payment->gateway == 'rest-api'){
                        $r->purchase_detail = sprintf(__('Mobile Donation for %s', 'pp-toolkit'), $r->campaign_name );
                    }

                    $total_amount['donations'] += $r->amount;

                    $donation_details[] = (array) $r;
                }


                // count fundraiser
                if(!isset($fundraisers_details[$r->referral])){
                    $fundraisers_details[$r->referral] = array(
                        'name' => $r->referral,
                        'donations' => 1,
                        'amount' => $r->amount,
                    );
                } else {
                    $fundraisers_details[$r->referral]['donations'] += 1;
                    $fundraisers_details[$r->referral]['amount'] += $r->amount;
                }

                $total_amount['fundraisers'] += $r->amount;
                
            } // endif $log
            
            // count to total fundraising for debug
            $total_fundraising += $r->amount;

        } // endforeach $report


        usort($fundraisers_details, array(__CLASS__, "sort_by_amount"));
        usort($donation_details, array(__CLASS__, "sort_by_amount"));
        usort($ticket_details, array(__CLASS__, "sort_by_last_name"));
        usort($merchandise_details, array(__CLASS__, "sort_by_last_name"));


        $data = array(
            'fundraisers' => array(
                'details' => $fundraisers_details,
                'total_amount' => $total_amount['fundraisers']
            ),
            'donations' => array(
                'details' => $donation_details,
                'total_amount' => $total_amount['donations']
            ),
            'tickets' => array(
                'details' => $ticket_details,
                'total_amount' => $total_amount['tickets'],
                'qty_by_options' => $ticket_qty_by_options,
            ),
            'merchandises' => array(
                'details' => $merchandise_details,
                'total_amount' => $total_amount['merchandises'],
                'qty_by_options' => $merchandise_qty_by_options,
            ),
        );
    
        return $data;
    }

    public function maybe_download_campaign_reports(){

        if (!isset($_GET['download_campaign_report']))
            return;

        if (!isset($_GET['campaign_id']) || !isset($_GET['report_nonce']))
            return;

        if ( ! wp_verify_nonce( $_GET['report_nonce'], 'download_campaign_report-' . $_GET['campaign_id'] ) )
            return;

        $report_type = $_GET['download_campaign_report'];
        $campaign_id = absint( $_GET['campaign_id'] );

        switch ($report_type) {
            case 'fundraisers':
                $this->download_report_fundraisers($campaign_id);
                break;

            case 'donations':
                $this->download_report_donations($campaign_id);
                break;

            case 'tickets':
                $this->download_report_tickets($campaign_id);
                break;

            case 'merchandises':
                $this->download_report_merchandises($campaign_id);
                break;
            
            default:
                $this->download_report_all($campaign_id);
                break;
        }
    }

    private function download_report_fundraisers($campaign_id){

        $items = array();

        $filename = sanitize_file_name( get_the_title( $campaign_id ) . ' - Fundraisers' );
        $columns  = array( 
            'name' => __( 'Name' ), 
            'donations' => __( 'Total Donations' ),
            'amount' => __( 'Total Amount' ), 
        );

        /* Output headers so that the file is downloaded rather than displayed */
        $charset  = get_option( 'blog_charset' );
        header( "Content-Type: text/csv; charset=$charset" );
        header( "Content-Disposition: attachment; filename=$filename.csv" );

        /* Create a file pointer connected to the output stream */
        $output = fopen( 'php://output', 'w' );

        /* Print header row */
        fputcsv( $output, array_values( $columns ) );        

        $reports = self::get_campaign_reports($campaign_id);

        if(isset($reports['fundraisers']) && isset($reports['fundraisers']['details'])){
            $items = $reports['fundraisers']['details'];
        }

        /* And echo the data */
        if(!empty($items)):
        foreach ( $items as $item ) {

            $row  = array( 
                'name' => $item['name'], 
                'donations' => $item['donations'],
                'amount' => edd_format_amount($item['amount'], false)
            );

            fputcsv( $output, $row );
        }
        endif;

        fclose( $output );
        exit;
    }

    private function download_report_donations($campaign_id){
        $items = array();

        $filename = sanitize_file_name( get_the_title( $campaign_id ) . ' - Donations' );
        $columns  = array( 
            'donation_id' => __( 'Donation ID' ), 
            'date' => __( 'Donation Date' ), 
            'time' => __( 'Donation Time' ), 
            'first_name' => __( 'First Name' ), 
            'last_name' => __( 'Last Name' ),
            'email' => __('Email'),
            'amount' => __( 'Donation Amount' ), 
            'purchase_detail' => __( 'Purchase Detail' ), 
            'referral' => __( 'Referred By' ), 
        );       

        $reports = self::get_campaign_reports($campaign_id);

        if(isset($reports['donations']) && isset($reports['donations']['details'])){
            $items = $reports['donations']['details'];
        }

        /* Output headers so that the file is downloaded rather than displayed */
        $charset  = get_option( 'blog_charset' );
        header( "Content-Type: text/csv; charset=$charset" );
        header( "Content-Disposition: attachment; filename=$filename.csv" );

        /* Create a file pointer connected to the output stream */
        $output = fopen( 'php://output', 'w' );

        /* Print header row */
        fputcsv( $output, array_values( $columns ) ); 

        /* And echo the data */
        if(!empty($items)):
        foreach ( $items as $item ) {

            $row  = array(
                'donation_id' => $item['donation_id'], 
                'date' => $item['date'], 
                'time' => $item['time'], 
                'first_name' => $item['first_name'], 
                'last_name' => $item['last_name'], 
                'email' => $item['email'],
                'amount' => edd_format_amount($item['amount'], false), 
                'purchase_detail' => $item['purchase_detail'], 
                'referral' => $item['referral'], 
            );

            fputcsv( $output, $row );
        }
        endif;

        fclose( $output );
        exit;
    }

    private function download_report_tickets($campaign_id){
        $items = array();

        $filename = sanitize_file_name( get_the_title( $campaign_id ) . ' - Tickets' );
        $columns  = array(
            'donation_id' => __( 'Donation ID' ), 
            'date' => __( 'Donation Date' ), 
            'time' => __( 'Donation Time' ), 
            'first_name' => __( 'First Name' ), 
            'last_name' => __( 'Last Name' ),
            'email' => __('Email'),
            'qty' => __( 'Qty' ), 
            'amount' => __( 'Amount' ), 
            'ticket_holder' => __( 'Ticket Holder' ), 
            'purchase_detail' => __( 'Purchase Detail' ), 
            'referral' => __( 'Referred By' ), 
        );       

        $reports = self::get_campaign_reports($campaign_id);

        if(isset($reports['tickets']) && isset($reports['tickets']['details'])){
            $items = $reports['tickets']['details'];
        }

        /* Output headers so that the file is downloaded rather than displayed */
        $charset  = get_option( 'blog_charset' );
        header( "Content-Type: text/csv; charset=$charset" );
        header( "Content-Disposition: attachment; filename=$filename.csv" );

        /* Create a file pointer connected to the output stream */
        $output = fopen( 'php://output', 'w' );

        /* Print header row */
        fputcsv( $output, array_values( $columns ) ); 

        /* And echo the data */
        if(!empty($items)):
        foreach ( $items as $item ) {

            $row  = array(
                'donation_id' => $item['donation_id'], 
                'date' => $item['date'], 
                'time' => $item['time'], 
                'first_name' => $item['first_name'], 
                'last_name' => $item['last_name'], 
                'email' => $item['email'],
                'qty' => $item['qty'], 
                'amount' => edd_format_amount($item['amount'], false), 
                'ticket_holder' => $item['ticket_holder'], 
                'purchase_detail' => $item['purchase_detail'],
                'referral' => $item['referral'],  
            );

            fputcsv( $output, $row );
        }
        endif;

        fclose( $output );
        exit;
    }

    private function download_report_merchandises($campaign_id){
        $items = array();

        $filename = sanitize_file_name( get_the_title( $campaign_id ) . ' - Merchandises' );
        $columns  = array(
            'donation_id' => __( 'Donation ID' ), 
            'date' => __( 'Donation Date' ), 
            'time' => __( 'Donation Time' ), 
            'first_name' => __( 'First Name' ), 
            'last_name' => __( 'Last Name' ),
            'email' => __('Email'),
            'qty' => __( 'Qty' ), 
            'amount' => __( 'Amount' ), 
            'shipping' => __( 'Shipping' ), 
            'purchase_detail' => __( 'Purchase Detail' ), 
            'referral' => __( 'Referred By' ), 
        );       

        $reports = self::get_campaign_reports($campaign_id);

        if(isset($reports['merchandises']) && isset($reports['merchandises']['details'])){
            $items = $reports['merchandises']['details'];
        }

        /* Output headers so that the file is downloaded rather than displayed */
        $charset  = get_option( 'blog_charset' );
        header( "Content-Type: text/csv; charset=$charset" );
        header( "Content-Disposition: attachment; filename=$filename.csv" );

        /* Create a file pointer connected to the output stream */
        $output = fopen( 'php://output', 'w' );

        /* Print header row */
        fputcsv( $output, array_values( $columns ) ); 

        /* And echo the data */
        if(!empty($items)):
        foreach ( $items as $item ) {

            $row  = array( 

                'donation_id' => $item['donation_id'], 
                'date' => $item['date'], 
                'time' => $item['time'], 
                'first_name' => $item['first_name'], 
                'last_name' => $item['last_name'], 
                'email' => $item['email'],
                'qty' => $item['qty'], 
                'amount' => edd_format_amount($item['amount'], false), 
                'shipping' => edd_format_amount($item['shipping'], false), 
                'purchase_detail' => $item['purchase_detail'],
                'referral' => $item['referral'],  
            );

            fputcsv( $output, $row );
        }
        endif;

        fclose( $output );
        exit;
    }

    private function download_report_all($campaign_id){
        $items = array();

        $filename = sanitize_file_name( get_the_title( $campaign_id ) . ' - Reports' );
        $columns  = array(
            'donation_id' => __( 'Donation ID' ), 
            'date' => __( 'Donation Date' ), 
            'time' => __( 'Donation Time' ), 
            'type' => __( 'Donation Type' ), 
            'first_name' => __( 'First Name' ), 
            'last_name' => __( 'Last Name' ),
            'email' => __('Email'),
            'qty' => __( 'Qty' ), 
            'amount' => __( 'Amount' ), 
            'ticket_holder' => __( 'Ticket Holder' ), 
            'shipping' => __( 'Shipping' ), 
            'purchase_detail' => __( 'Purchase Detail' ), 
            'referral' => __( 'Referred By' ), 
        );       

        $reports = self::get_campaign_reports($campaign_id);
        if(isset($reports['fundraisers']))
            unset($reports['fundraisers']);

        /* Output headers so that the file is downloaded rather than displayed */
        $charset  = get_option( 'blog_charset' );
        header( "Content-Type: text/csv; charset=$charset" );
        header( "Content-Disposition: attachment; filename=$filename.csv" );

        /* Create a file pointer connected to the output stream */
        $output = fopen( 'php://output', 'w' );

        /* Print header row */
        fputcsv( $output, array_values( $columns ) ); 

        /* And echo the data */
        if(!empty($reports)):
        foreach ( $reports as $r_type => $report ) {

            if(!isset($report['details']))
                continue;

            foreach ($report['details'] as $item) {
                
                $row  = array(
                    'donation_id' => $item['donation_id'], 
                    'date' => $item['date'], 
                    'time' => $item['time'], 
                    'type' => $item['type'], 
                    'first_name' => $item['first_name'], 
                    'last_name' => $item['last_name'], 
                    'email' => $item['email'],
                    'qty' => isset($item['qty']) ? $item['qty'] : '-', 
                    'amount' => edd_format_amount($item['amount'], false), 
                    'ticket_holder' => isset($item['ticket_holder']) ? $item['ticket_holder'] : '-', 
                    'shipping' => isset($item['shipping']) ? edd_format_amount($item['shipping'], false) : '-', 
                    'purchase_detail' => $item['purchase_detail'],
                    'referral' => $item['referral'],  
                );

                fputcsv( $output, $row );
            }
        }
        endif;

        fclose( $output );
        exit;
    }

    public function includes(){}

}

PP_Reports::init();