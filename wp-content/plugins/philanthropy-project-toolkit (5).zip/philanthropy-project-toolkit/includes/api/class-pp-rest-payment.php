<?php
/**
 * REST API: PP_Rest_Payment class
 *
 * @package PP_Toolkit
 * @subpackage REST_API
 * @since 1.0
 */

/**
 * Core class used to purchase / checkout via the REST API.
 *
 * @since 1.0
 *
 * @see WP_REST_Controller
 */
class PP_Rest_Payment extends WP_REST_Controller {

	/**
	 * Constructor.
	 * @access public
	 */
	public function __construct() {

        $this->namespace = 'philanthropy';
        $this->rest_base = 'payment';
	}

	/**
	 * Registers the routes for the objects of the controller.
	 * @access public
	 *
	 * @see register_rest_route()
	 */
	public function register_routes() {

		register_rest_route( $this->namespace, '/' . $this->rest_base, array(
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'create_item' ),
				'permission_callback' => array( $this, 'create_item_permissions_check' ),
				'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::CREATABLE ),
			),
			'schema' => array( $this, 'get_public_item_schema' ),
		) );
	}

	/**
	 * Checks if a given request has access create payment.
	 * @access public
	 * 
	 * @return true|WP_Error True if the request has access to create payment, WP_Error object otherwise.
	 */
	public function create_item_permissions_check( $request ) {

		// if ( ! is_user_logged_in() ) {
		// 	return new WP_Error( 'rest_cannot_create_payment', __( 'Sorry, you are not allowed to create payment.' ), array( 'status' => rest_authorization_required_code() ) );
		// }

		// if ( ! current_user_can( 'create_users' ) ) {
		// 	return new WP_Error( 'rest_cannot_create_user', __( 'Sorry, you are not allowed to create new users.' ), array( 'status' => rest_authorization_required_code() ) );
		// }

		return true;
	}

	/**
	 * Create payment by for a campaign.
	 * @access public
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 * @return WP_REST_Response|WP_Error Response object on success, or WP_Error object on failure.
	 */
	public function create_item( $request ) {

		// return new WP_Error( 'failed_to_process_payment','dasdasd' , array( 'status' => 400 ) );

		$payment_data = $this->build_payment_data($request);
		$payment_id = $this->process_stripe_payment( $payment_data, $request );

		if ( is_wp_error( $payment_id ) ) {
			return new WP_Error( 'failed_to_process_payment', $payment_id->get_error_message() , array( 'status' => 400 ) );
		}

		$payment = new EDD_Payment( $payment_id );

		$response = array(
			'status' => 'success',
			'payment_id' => $payment_id,
			'total' => $payment->total
		);

		$request->set_param( 'context', 'edit' );

		// $response = $this->prepare_item_for_response( $user, $request );
		$response = rest_ensure_response( $response );

		$response->set_status( 201 );
		// $response->header( 'Location', rest_url( sprintf( '%s/%s/%d', $this->namespace, $this->rest_base, $payment_id ) ) );

		return $response;
	}

	private function build_payment_data($request){
		 
		$email = (isset($request['email'])) ? $request['email'] : null;
		$purchase_key     = strtolower( md5( $email . date( 'Y-m-d H:i:s' ) . uniqid( 'edd', true ) ) );

		$total_price = $request['donation_amount']; // TODO | Sanitize and maybe count with merchandises

		$payment_data = array(
			'price' => $total_price,
			'date' => date( 'Y-m-d H:i:s', current_time( 'timestamp' ) ),
			'user_email' => $email,
			'purchase_key' => $purchase_key,
			'currency' => edd_get_currency(),
			'downloads' => array(),
			'cart_details' => array(),
			'user_info' => array(
				'id' => 0,
				'email' => $email,
				'first_name' => (isset($request['first_name'])) ? $request['first_name'] : '',
				'last_name' => (isset($request['last_name'])) ? $request['last_name'] : '',
				'discount' => 'none',
				'address' => (isset($request['address'])) ? $request['address'] : '',
			),
			// 'status' => 'publish',
		);


		// TODO | Loop
		if(isset($request['merchandise']) && !empty($request['merchandise'])){
			foreach ($request['merchandise'] as $m) {

				$download_id = (isset($m['id'])) ? $m['id'] : 0;
				$quantity = (isset($m['quantity'])) ? $m['quantity'] : 1;
				$price_id = (isset($m['price_id'])) ? $m['price_id'] : 0;

				$price_options = array();

				if( ! edd_has_variable_prices( $download_id ) ) {
					$price = edd_get_download_price( $download_id );
				} else {

					$prices = edd_get_variable_prices( $download_id );

					// Make sure a valid price ID was supplied
					if( ! isset( $prices[ $price_id ] ) ) {
						wp_die( __( 'The requested price ID does not exist.', 'easy-digital-downloads' ), __( 'Error', 'easy-digital-downloads' ), array( 'response' => 404 ) );
					}

					$price_options = array(
						'price_id' => $price_id,
						'amount'   => $prices[ $price_id ]['amount']
					);
					$price  = $prices[ $price_id ]['amount'];
				}


				$payment_data['downloads'][] = array(
					'id' => $download_id,
					'options' => $price_options,
					'quantity' => $quantity
				);

				$payment_data['cart_details'][] = array(
					'name'        => get_the_title( $download_id ),
					'id'          => $download_id,
					'item_number' => array(
						'id'      => $download_id,
						'options' => $price_options
					),
					'tax'         => 0,
					'discount'    => 0,
					'item_price'  => $price,
					'subtotal'    => ( $price * $quantity ),
					'price'       => ( $price * $quantity ),
					'quantity'    => $quantity,
				);
			}
		}

		return $payment_data;
	}

	private function process_stripe_payment($purchase_data, $request){
		global $edd_options;

		if ( edd_is_test_mode() ) {
			$secret_key = trim( $edd_options['test_secret_key'] );
		} else {
			$secret_key = trim( $edd_options['live_secret_key'] );
		}

		if ( empty( $request['stripe_token'] ) ) {
			return new WP_Error( 'missing_stripe_token', __( 'Missing Stripe Token.' ), array( 'status' => 400 ) );
		}

		$card_data = $request['stripe_token'];

		try {

			\Stripe\Stripe::setApiKey( $secret_key );

			if ( method_exists( '\Stripe\Stripe', 'setAppInfo' ) ) {
				\Stripe\Stripe::setAppInfo( 'Easy Digital Downloads - Stripe', EDD_STRIPE_VERSION, esc_url( site_url() ) );
			}

			// setup the payment details
			$payment_data = array(
				'price'        => $purchase_data['price'],
				'date'         => $purchase_data['date'],
				'user_email'   => $purchase_data['user_email'],
				'purchase_key' => $purchase_data['purchase_key'],
				'currency'     => edd_get_currency(),
				'downloads'    => $purchase_data['downloads'],
				'cart_details' => $purchase_data['cart_details'],
				'user_info'    => $purchase_data['user_info'],
				'status'       => (isset( $purchase_data['status'] )) ? $purchase_data['status'] : 'pending',
				'gateway'      => (isset( $purchase_data['gateway'] )) ? $purchase_data['gateway'] : 'rest-api'
			);

			// try to get user ID
			$customer = new EDD_Customer( $purchase_data['user_email'] );
			if( $customer->id > 0 && ! empty( $customer->user_id ) ) {
				$user_id = $customer->user_id;
			} else {
				$user_id = 0;
			}

			// get stripe customer id by email
			$customer_id = edds_get_stripe_customer_id( $purchase_data['user_email'] );

			// try to get from customer meta
			if(empty($customer_id)){
				$customer_id = $customer->get_meta( edd_stripe_get_customer_key(), true );
			}

			$customer_exists = false;

			if ( ! empty( $customer_id ) ) {

				$customer_exists = true;

				try {

					// Retrieve the customer to ensure the customer has not been deleted
					$cu = \Stripe\Customer::retrieve( $customer_id );

					if( isset( $cu->deleted ) && $cu->deleted ) {

						// This customer was deleted
						$customer_exists = false;

					}

				// No customer found
				} catch ( Exception $e ) {

					$customer_exists = false;

				}

			}

			if ( ! $customer_exists ) {

				// Create a customer first so we can retrieve them later for future payments
				$cu = \Stripe\Customer::create( array(
						'description' => $purchase_data['user_email'],
						'email'       => $purchase_data['user_email'],
					)
				);

				$customer_id = is_array( $cu ) ? $cu['id'] : $cu->id;

				$customer_exists = true;

			}


			if ( $customer_exists ) {

				if ( is_array( $card_data ) ) {
					$card_data['object'] = 'card';
				}

				$card    = $cu->sources->create( array( 'source' => $card_data ) );
				$card_id = $card->id;

				// Process a normal one-time charge purchase

				if( ! isset( $edd_options['stripe_preapprove_only'] ) ) {

					if( edds_is_zero_decimal_currency() ) {
						$amount = $purchase_data['price'];
					} else {
						$amount = $purchase_data['price'] * 100;
					}

					$unsupported_characters = array( '<', '>', '"', '\'' );

					$statement_descriptor = apply_filters( 'edds_statement_descriptor', substr( $purchase_summary, 0, 22 ), $purchase_data );

					$statement_descriptor = str_replace( $unsupported_characters, '', $statement_descriptor );

					$args = array(
						'amount'      => $amount,
						'currency'    => edd_get_currency(),
						'customer'    => $customer_id,
						'source'      => $card_id,
						'description' => html_entity_decode( $purchase_summary, ENT_COMPAT, 'UTF-8' ),
						'metadata'    => array(
							'email'   => $purchase_data['user_info']['email']
						),
					);

					if( ! empty( $statement_descriptor ) ) {
						$args[ 'statement_descriptor' ] = $statement_descriptor;
					}

					$charge = \Stripe\Charge::create( apply_filters( 'edds_create_charge_args', $args, $purchase_data ) );
				}

				// attach donation
				if(isset($request['campaign_id']) && isset($request['donation_amount'])){
					Charitable_EDD_Cart::add_donation_fee_to_cart( $request['campaign_id'], $request['donation_amount'] );
				}

				// record the pending payment
				$payment = edd_insert_payment( $payment_data );


				// record to customer meta
				$customer->update_meta( edd_stripe_get_customer_key(), $customer_id);

				if ( !empty($user_id) ) {
					update_user_meta( $user_id, edd_stripe_get_customer_key(), $customer_id );
				}

			} else {

				return new WP_Error( 'failed_to_create_customer', __( 'Customer Creation Failed.' ) );

			}

			if ( $payment && ( ! empty( $customer_id ) || ! empty( $charge ) ) ) {

				$needs_invoiced = false;
				if ( ! empty( $needs_invoiced ) ) {

					try {
						// Create the invoice containing taxes / discounts / fees
						$invoice = \Stripe\Invoice::create( array(
							'customer' => $customer_id, // the customer to apply the fee to
						) );
						$invoice = $invoice->pay();
					} catch ( Exception $e ) {
						// If there is nothing to pay, it just means the invoice item was taken care of with the subscription payment
					}
				}

				if ( isset( $edd_options['stripe_preapprove_only'] ) ) {
					edd_update_payment_status( $payment, 'preapproval' );
					add_post_meta( $payment, '_edds_stripe_customer_id', $customer_id );
				} else {
					edd_update_payment_status( $payment, 'publish' );
				}

				// You should be using Stripe's API here to retrieve the invoice then confirming it's been paid
				if ( ! empty( $charge ) ) {

					edd_insert_payment_note( $payment, 'Stripe Charge ID: ' . $charge->id );

					if( function_exists( 'edd_set_payment_transaction_id' ) ) {

						edd_set_payment_transaction_id( $payment, $charge->id );

					}

				} elseif ( ! empty( $customer_id ) ) {
					edd_insert_payment_note( $payment, 'Stripe Customer ID: ' . $customer_id );
				}

			} else {

				return new WP_Error( 'payment_not_recorded', __( 'Your payment could not be recorded.' ) );
			}

	 	} catch ( \Stripe\Error\Card $e ) {

			$body = $e->getJsonBody();
			$err  = $body['error'];

			edd_record_gateway_error( __( 'Stripe Error', 'edds' ), sprintf( __( 'There was an error while processing a Stripe payment. Payment data: %s', ' edds' ), json_encode( $err ) ), 0 );

			if( isset( $err['message'] ) ) {
				return new WP_Error( 'payment_error', $err['message'] );
			} else {
				return new WP_Error( 'payment_error', __( 'There was an error processing your payment, please ensure you have entered your card number correctly.', 'edds' ) );
			}


		} catch ( \Stripe\Error\ApiConnection $e ) {

			$body = $e->getJsonBody();
			$err  = $body['error'];

			
			edd_record_gateway_error( __( 'Stripe Error', 'edds' ), sprintf( __( 'There was an error processing your payment (Stripe\'s API was down). Error: %s', 'edds' ), json_encode( $err['message'] ) ), 0 );

			return new WP_Error( 'payment_error', __( 'There was an error processing your payment (Stripe\'s API is down), please try again', 'edds' ) );

		} catch ( \Stripe\Error\InvalidRequest $e ) {

			$body = $e->getJsonBody();
			$err  = $body['error'];

			// Bad Request of some sort. Maybe Christoff was here ;)
			if( isset( $err['message'] ) ) {
				return new WP_Error( 'request_error', $err['message'] );
			} else {
				return new WP_Error( 'request_error', __( 'The Stripe API request was invalid, please try again', 'edds' ) );
			}

		} catch ( \Stripe\Error\Api $e ) {

			$body = $e->getJsonBody();
			$err  = $body['error'];

			if( isset( $err['message'] ) ) {
				return new WP_Error( 'request_error', $err['message'] );
			} else {
				return new WP_Error( 'request_error', __( 'The Stripe API request was invalid, please try again', 'edds' ) );
			}

		} catch ( \Stripe\Error\Authentication $e ) {

			$body = $e->getJsonBody();
			$err  = $body['error'];

			// Authentication error. Stripe keys in settings are bad.
			if( isset( $err['message'] ) ) {
				return new WP_Error( 'request_error', $err['message'] );
			} else {
				return new WP_Error( 'api_error', __( 'The API keys entered in settings are incorrect', 'edds' ) );
			}

		} catch ( Exception $e ) {
			// some sort of other error
			$body = $e->getJsonBody();
			$err  = $body['error'];
			if( isset( $err['message'] ) ) {
				return new WP_Error( 'payment_error', $err['message'] );
			} else {
				return new WP_Error( 'api_error', __( 'Something went wrong.', 'edds' ) );
			}

		}

		return $payment;
	}

	/**
	 * Retrieves the payment's schema, conforming to JSON Schema.
	 * @access public
	 *
	 * @return array Item schema data.
	 */
	public function get_item_schema() {
		$schema = array(
			'$schema'    => 'http://json-schema.org/schema#',
			'title'      => 'payment',
			'type'       => 'object',
			'properties' => array(
				'stripe_token'     => array(
					'description' => __( 'Stripe Token' ),
					'type'        => 'string',
					'context'     => array( 'edit' ),
					'required'    => true,
				),
				'campaign_id'     => array(
					'description' => __( 'Campaign ID' ),
					'type'        => 'integer',
					'context'     => array( 'edit' ),
					'required'    => true,
				),
				'donation_amount'     => array(
					'description' => __( 'Donation amount' ),
					'type'        => 'integer',
					'context'     => array( 'edit' ),
					'required'    => true,
				),
				'email'       => array(
					'description' => __( 'The email address for the user.' ),
					'type'        => 'string',
					'format'      => 'email',
					'context'     => array( 'edit' ),
					'required'    => true,
				),
				'first_name'  => array(
					'description' => __( 'First name for the user.' ),
					'type'        => 'string',
					'context'     => array( 'edit' ),
					'arg_options' => array(
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
				'last_name'   => array(
					'description' => __( 'Last name for the user.' ),
					'type'        => 'string',
					'context'     => array( 'edit' ),
					'arg_options' => array(
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
				// 'merchandise'           => array(
				// 	'description' => __( 'Purchased merchandise.' ),
				// 	'type'        => 'array',
					// 'items'       => array(
					// 	'type'    => 'string',
					// ),
					// 'context'     => array( 'edit' ),
				// ),
			),
		);

		return $this->add_additional_fields_schema( $schema );
	}
}
