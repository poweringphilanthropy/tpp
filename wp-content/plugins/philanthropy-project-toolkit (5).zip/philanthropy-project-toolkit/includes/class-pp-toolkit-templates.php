<?php
/**
 * PP_Toolkit_Templates Class.
 * Overrides plugin dependencies template
 *
 * @class       PP_Toolkit_Templates
 * @version     1.0
 * @author lafif <hello@lafif.me>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * PP_Toolkit_Templates class.
 */
class PP_Toolkit_Templates {

    private $charitable_template_overrides = array(
        'shortcodes/submit-campaign.php'
    );

    /**
     * Singleton method
     *
     * @return self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new PP_Toolkit_Templates();
        }

        return $instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->includes();

        add_filter( 'charitable_locate_template', array($this, 'change_charitable_locate_template'), 10, 2 );
    }

    /**
     * overrides charitable template to load from our template
     * @param  [type] $template       [description]
     * @param  [type] $template_names [description]
     * @return [type]                 [description]
     */
    public function change_charitable_locate_template($template, $template_names){
        if(in_array($template_names[0], $this->charitable_template_overrides)){
            $template = PP_Toolkit()->plugin_path().'/templates/charitable/' . $template_names[0];
        }

        return $template;
    }

    public function includes(){

    }

}

PP_Toolkit_Templates::init();





/**
 * Philanthropy_Charitable_Template
 * Custom template path
 * @since       1.0.0
 */
class Philanthropy_Charitable_Template extends Charitable_Template {      

    /**
     * Set theme template path. 
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_theme_template_path() {
        return trailingslashit( apply_filters( 'pp_toolkit_theme_template_path', 'pp_toolkit' ) );
    }

    /**
     * Return the base template path.
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_base_template_path() {
        return PP_Toolkit()->plugin_path().'/templates/charitable/';
    }
}

/**
 * Helper function to load our custom charitable template under /templates/charitable
 * @param  [type] $template_name [description]
 * @param  array  $args          [description]
 * @return [type]                [description]
 */
function pp_toolkit_template( $template_name, array $args = array() ) {
    if ( empty( $args ) ) {
        $template = new Philanthropy_Charitable_Template( $template_name );
    } else {
        $template = new Philanthropy_Charitable_Template( $template_name, false );
        $template->set_view_args( $args );
        $template->render();
    }

    return $template;
}