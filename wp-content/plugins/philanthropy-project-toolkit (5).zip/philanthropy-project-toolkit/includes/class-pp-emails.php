<?php
/**
 * PP_Emails Class.
 *
 * @class       PP_Emails
 * @version     1.0
 * @author lafif <hello@lafif.me>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * PP_Emails class.
 */
class PP_Emails {

    /**
     * Singleton method
     *
     * @return self
     */
    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new PP_Emails();
        }

        return $instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->includes();

        add_action( 'init', array($this, 'remove_hooks'), 11 );
        add_filter('wp_mail_from', array($this, 'change_mail_from'), 11, 1);
        add_filter('wp_mail_from_name', array($this, 'change_mail_from_name'), 11, 1);

        add_filter( 'charitable_email_content_field_value_donation_summary', array($this, 'get_donation_summary'), 11, 3 );
        add_filter( 'edd_email_tags', array($this, 'pp_edd_email_tags'), 10, 1 );

        add_filter( 'charitable_email_content_fields',         array( $this, 'add_campaign_id_fields' ), 10, 2 );
        add_filter( 'charitable_email_preview_content_fields', array( $this, 'add_preview_campaign_id_fields' ), 10, 2 );
        // add_action( 'eddtickets-send-tickets-email', array($this, 'add_staging_url'), 1 );
    }

    /**
     * Fix wrong home_url and get_option('home')
     * on campaign image on ticket email
     */
    public function add_staging_url(){
        update_option( 'staging_url', home_url() );
    }

    public function remove_hooks(){

        // remove default ninja form message "Thank you for filling out this form."
        remove_action( 'ninja_forms_post_process', 'ninja_forms_email_user', 1000 );
    }

    public function change_mail_from($from_email){

        // only change if from wordpress@sitename
        if ( strpos( strtolower($from_email), 'wordpress') !== false ) {
            $from_email = get_option('admin_email');
        }

        return $from_email;
    }

    public function change_mail_from_name($from_name){

        // only change if from wordpress@sitename
        if ( strpos( strtolower($from_name), 'wordpress') !== false ) {
            $from_name = get_bloginfo( 'name' );
        }

        return $from_name;
    }
    
    /**
     * Change email content for Admin: New Donation Notification
     * we need to dsplay all data
     */
    public function get_donation_summary($value, $args, $email){
        $donation = $email->get_donation();
        $donation_id = $donation->get_donation_id();

        $payment_id = Charitable_EDD_Payment::get_payment_for_donation( $donation_id );

        $payment = new EDD_Payment( $payment_id );

        $payment_data  = $payment->get_meta();
        $download_list = '<ul>';
        $cart_items    = $payment->cart_details;
        $cart_fees    = $payment->fees;
        $email         = $payment->email;

        $donation_log = get_post_meta( $donation_id, 'donation_from_edd_payment_log', true );
        
        /**
         * Display Donations
         */
        if ( !empty($cart_fees) ) {

            foreach ($cart_fees as $fee) {
                if ( ! Charitable_EDD_Cart::fee_is_donation( $fee ) )
                    continue;

                $download_list .= '<li>' . sprintf(__('<strong>%s</strong> (%s)', 'pp-toolkit'), $fee['label'], charitable_format_money($fee['amount']) ) . '</li><br>';
            }
        }

        /**
         * Display downloads,
         * assume all downloads with 100% campaign benefactor relationship
         */
        if ( $cart_items ) {
            $show_names = apply_filters( 'edd_email_show_names', true );
            $show_links = apply_filters( 'edd_email_show_links', true );

            foreach ( $cart_items as $item ) {

                if ( edd_use_skus() ) {
                    $sku = edd_get_download_sku( $item['id'] );
                }

                if ( edd_item_quantities_enabled() ) {
                    $quantity = $item['quantity'];
                }

                $price_id = edd_get_cart_item_price_id( $item );
                if ( $show_names ) {

                    $title = '<strong>' . get_the_title( $item['id'] ) . '</strong>';

                    // if ( ! empty( $quantity ) && $quantity > 1 ) {
                    //  $title .= "&nbsp;&ndash;&nbsp;" . __( 'Quantity', 'easy-digital-downloads' ) . ': ' . $quantity;
                    // }

                    if ( ! empty( $sku ) ) {
                        $title .= "&nbsp;&ndash;&nbsp;" . __( 'SKU', 'easy-digital-downloads' ) . ': ' . $sku;
                    }

                    if ( edd_has_variable_prices( $item['id'] ) && isset( $price_id ) ) {
                        $title .= "&nbsp;&ndash;&nbsp;" . edd_get_price_option_name( $item['id'], $price_id, $payment_id );
                    }

                    $download_list .= '<li>' . $item['quantity'] . 'x ' . apply_filters( 'edd_email_receipt_download_title', $title, $item, $price_id, $payment_id ) . ' ('.charitable_format_money($item['price']).')<br/>';
                }

                $files = edd_get_download_files( $item['id'], $price_id );

                if ( ! empty( $files ) ) {

                    foreach ( $files as $filekey => $file ) {

                        if ( $show_links ) {
                            $download_list .= '<div>';
                            $file_url = edd_get_download_file_url( $payment_data['key'], $email, $filekey, $item['id'], $price_id );
                            $download_list .= '<a href="' . esc_url_raw( $file_url ) . '">' . edd_get_file_name( $file ) . '</a>';
                            $download_list .= '</div>';
                        } else {
                            $download_list .= '<div>';
                            $download_list .= edd_get_file_name( $file );
                            $download_list .= '</div>';
                        }

                    }

                } elseif ( edd_is_bundled_product( $item['id'] ) ) {

                    $bundled_products = apply_filters( 'edd_email_tag_bundled_products', edd_get_bundled_products( $item['id'] ), $item, $payment_id, 'download_list' );

                    foreach ( $bundled_products as $bundle_item ) {

                        $download_list .= '<div class="edd_bundled_product"><strong>' . get_the_title( $bundle_item ) . '</strong></div>';

                        $files = edd_get_download_files( $bundle_item );

                        foreach ( $files as $filekey => $file ) {
                            if ( $show_links ) {
                                $download_list .= '<div>';
                                $file_url = edd_get_download_file_url( $payment_data['key'], $email, $filekey, $bundle_item, $price_id );
                                $download_list .= '<a href="' . esc_url( $file_url ) . '">' . edd_get_file_name( $file ) . '</a>';
                                $download_list .= '</div>';
                            } else {
                                $download_list .= '<div>';
                                $download_list .= edd_get_file_name( $file );
                                $download_list .= '</div>';
                            }
                        }
                    }
                }


                // if ( '' != edd_get_product_notes( $item['id'] ) ) {
                //  $download_list .= ' &mdash; <small>' . edd_get_product_notes( $item['id'] ) . '</small>';
                // }


                if ( $show_names ) {
                    $download_list .= '</li><br>';
                }
            }
        }

        if ( ( $fees = edd_get_payment_fees( $payment->ID, 'fee' ) ) ){
            foreach ($fees as $fee) {
                $download_list .= '<li>';
                $download_list .= sprintf(__('<strong>%s</strong> (%s)', 'pp-toolkit'), $fee['label'], charitable_format_money($fee['amount']));
                $download_list .= '</li><br>';
            }
        }


        $download_list .= '</ul>';

        return $download_list;
    }

    /**
     * Change charitable edd default download lists on email
     * @param  [type] $email_tags [description]
     * @return [type]             [description]
     */
    public function pp_edd_email_tags($email_tags){

        if(empty($email_tags) || !is_array($email_tags) || !class_exists('Charitable_EDD_Cart'))
            return $email_tags;

        foreach ($email_tags as $key => $email_tag) {
            if(isset($email_tag['tag']) && ($email_tag['tag'] != 'download_list') )
                continue;

            $email_tags[$key]['function'] = ('text/html' == EDD()->emails->get_content_type()) ? 'pp_edd_email_tag_download_list' : 'pp_edd_email_tag_download_list_plain';
        }

        // echo "<pre>";
        // print_r($email_tags);
        // echo "</pre>";
        // exit();

        return $email_tags;
    }

    public function add_campaign_id_fields( $fields, Charitable_Email $email ) {

        if ( !in_array($email->get_email_id(), array('creator_campaign_submission', 'new_campaign') ) ) {
            return $fields;
        }

        if ( ! in_array( 'campaign', $email->get_object_types() ) ) {
            return $fields;
        }

        $fields['campaign_id'] = array(
            'description'   => __( 'The ID of the campaign', 'charitable' ),
            'callback'      => array( $this, 'get_campaign_id' ),
        );

        return $fields;

    }

    public function add_preview_campaign_id_fields($fields, Charitable_Email $email) {

        if ( !in_array($email->get_email_id(), array('creator_campaign_submission', 'new_campaign') ) ) {
            return $fields;
        }

        if ( ! in_array( 'campaign', $email->get_object_types() ) ) {
            return $fields;
        }

        $fields['campaign_id'] = 1234;
        return $fields;
    }

    public function get_campaign_id($value, $args, Charitable_Email $email) {
        if ( ! $email->has_valid_campaign() ) {
            return '';
        }

        $campaign = $email->get_campaign();

        return $campaign->ID;
    }


    public function includes(){

    }

}

PP_Emails::init();