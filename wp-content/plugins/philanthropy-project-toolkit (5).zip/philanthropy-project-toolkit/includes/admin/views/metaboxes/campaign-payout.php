<?php
global $post;

$payable_name = get_post_meta( $post->ID, '_campaign_payout_payable_name', true );
$email = get_post_meta( $post->ID, '_campaign_payout_email', true );
$first_name = get_post_meta( $post->ID, '_campaign_payout_first_name', true );
$last_name = get_post_meta( $post->ID, '_campaign_payout_last_name', true );
$address = get_post_meta( $post->ID, '_campaign_payout_address', true );
$address2 = get_post_meta( $post->ID, '_campaign_payout_address2', true );
$city = get_post_meta( $post->ID, '_campaign_payout_city', true );
$state = get_post_meta( $post->ID, '_campaign_payout_state', true );
$zipcode = get_post_meta( $post->ID, '_campaign_payout_zipcode', true );
$country = get_post_meta( $post->ID, '_campaign_payout_country', true );
?>
<div class="charitable-metabox">
	<table class="widefat">
		<tbody>
			<tr>
				<th><?php _e('Payable to:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_payable_name" name="payout_payable_name" value="<?php echo $payable_name; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('Email:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_email" name="payout_email" value="<?php echo $email; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('First Name:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_first_name" name="payout_first_name" value="<?php echo $first_name; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('Last Name:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_last_name" name="payout_last_name" value="<?php echo $last_name; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('Address:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_address" name="payout_address" value="<?php echo $address; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('Address2:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_address2" name="payout_address2" value="<?php echo $address2; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('City:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_city" name="payout_city" value="<?php echo $city; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('State:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_state" name="payout_state" value="<?php echo $state; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('Zip Code:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_zipcode" name="payout_zipcode" value="<?php echo $zipcode; ?>" ></td>
			</tr>
			<tr>
				<th><?php _e('Country:', 'pp-toolkit'); ?></th>
				<td><input type="text" id="payout_country" name="payout_country" value="<?php echo $country; ?>" ></td>
			</tr>
		</tbody>
	</table>
</div>