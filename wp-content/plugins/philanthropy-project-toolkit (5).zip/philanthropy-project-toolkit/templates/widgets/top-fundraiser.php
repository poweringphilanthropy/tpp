<?php
/**
 * Display a widget with top fundraisers
 *
 * @since   1.0.0
 */

$widget_title   = apply_filters( 'widget_title', $view_args['title'] );
$fundraisers         = $view_args[ 'fundraisers' ];
$max_display = $view_args[ 'number' ];

$campaign_id = $view_args['campaign_id'];

if ( 'all' == $view_args['campaign_id'] ) {
    $campaign_id = false;
}

if ( 'current' == $view_args['campaign_id'] ) {
    $campaign_id = get_the_ID();
}

/**
 * No need to display on child campaign
 */
$parent_campaign_id = wp_get_post_parent_id( $campaign_id );
if(!empty($parent_campaign_id))
    return;

/* If there are no fundraisers and the widget is configured to hide when empty, return now. */
if ( ! $fundraisers->count() && $view_args['hide_if_no_fundraisers'] ) {
    return;
}

echo $view_args['before_widget'];

if ( ! empty( $widget_title ) ) :
    echo $view_args['before_title'] . $widget_title . $view_args['after_title'];
endif;

if ( $fundraisers->count() ) :
    ?>
    
    <div class="container-donor load-more-table-container">
        <table class="table-donor">
            <tbody>
            <?php 
            $show_more = false;

            $i = 0;
            foreach ( $fundraisers as $fundraiser ) : 

                // echo "<pre>";
                // print_r($fundraiser);
                // echo "</pre>";

                $tr_classes = 'donor-'.$i;
                if($i >= $max_display ){
                    $tr_classes .= ' more';

                    $show_more = true;
                    // close tbody to separate
                    echo '</tbody><tbody class="more-tbody" style="display:none;">';
                }

                ?>
                <tr class="<?php echo $tr_classes; ?>">
                    <td class="donor-amount"><?php echo charitable_get_currency_helper()->get_monetary_amount( $fundraiser->amount ); ?></td>
                    <td class="donor-name"><?php echo pp_get_referrer_name($fundraiser->referral); ?></td>
                </tr>

            <?php
            $i++;
            endforeach;
            ?>
            </tbody>
        </table>

        <?php if($show_more): ?>
        <div class="load-more">
            <a href="javascript:;" class="load-more-button"><?php _e('See All', 'pp-toolkit'); ?></a>
        </div>
        <?php endif; ?>
    </div>

<?php
else : 

    ?>

    <p><?php _e( 'No top fundraiser yet.', 'pp-toolkit' ) ?></p>

    <?php

endif;

echo $view_args['after_widget'];