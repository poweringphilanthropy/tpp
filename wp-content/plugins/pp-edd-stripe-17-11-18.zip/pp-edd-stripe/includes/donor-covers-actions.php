<?php
/**
 * Add additional meta fields to be saved when updating a campaign.
 */
function add_donor_covers_fee_meta_keys( $keys ) {
	array_push( $keys,
		'_campaign_donor_covers_fee'
	);

	return $keys;
}
add_filter( 'charitable_campaign_meta_keys', 'add_donor_covers_fee_meta_keys' );

function add_metabox_donor_covers_fee($fields){

	if(!empty( edd_get_option('donor_covers_fee') )){
		return $fields;
	}

	$fields['section-edd-separator'] = array(
		'view'              => 'metaboxes/field-types/hr',
		'priority'          => 15,
	);

	$fields['pp-donor-covers-fee'] = array(
		'view'              => 'metaboxes/field-types/checkbox',
		'priority'          => 15.1,
		'label'             => __( 'Enable donor covers fee', 'charitable-edd' ),
		'meta_key'          => '_campaign_donor_covers_fee',
		'default'           => 0,
	);

	return $fields;
}

add_filter( 'charitable_campaign_donation_options_fields', 'add_metabox_donor_covers_fee' );


function load_donor_covers_fee_js(){
	wp_register_script( 'pp-donor-covers-fee-js', EDDSTRIPE_PLUGIN_URL . 'assets/js/pp-donor-covers-fee.js', array( 'jquery' ), EDD_STRIPE_VERSION, true );

	if ( edd_is_checkout() ) {
		wp_enqueue_script( 'pp-donor-covers-fee-js' );

		$vars = array();

		wp_localize_script( 'pp-donor-covers-fee-js', 'DONOR_COVERS_FEE_VARS', $vars );
	}
}
add_action( 'wp_enqueue_scripts', 'load_donor_covers_fee_js', 100 );