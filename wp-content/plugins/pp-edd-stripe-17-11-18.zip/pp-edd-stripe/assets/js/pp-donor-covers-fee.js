(function($) {
   var PP_Donor_Covers_Fee = {
      init: function() {
         $(document).on('change', '#donor-covers-fee', this.updateDonorCoversFee);
         $('body').on('edd_gateway_loaded', function(){
            $('#donor-covers-fee').trigger('change');
         });
         
      },
      updateDonorCoversFee: function() {
         $checkbox = $(this);
         // alert($checkbox.attr('data-total'));
         
      },
   };
   PP_Donor_Covers_Fee.init();
})(jQuery);