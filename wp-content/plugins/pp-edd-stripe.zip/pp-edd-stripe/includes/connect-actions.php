<?php  

/**
 * Listen for Stripe events, primarily recurring payments
 *
 * @access      public
 * @since       1.5
 * @return      void
 */

function edds_stripe_connect_listener() {

	if(!isset( $_GET['connect-listener'] )){
		return;
	}

    if ( edd_is_test_mode() ) {
        $secret_key = trim( edd_get_option( 'test_secret_key' ) );
        $client_id = trim( edd_get_option( 'test_client_id' ) );
    } else {
        $secret_key = trim( edd_get_option( 'live_secret_key' ) );
        $client_id = trim( edd_get_option( 'live_client_id' ) );
    }

    \Stripe\Stripe::setApiKey($secret_key);
	\Stripe\Stripe::setClientId($client_id);

	if ( $_GET['connect-listener'] == 'payout-account' ) {

		if (isset($_GET['code'])) {
            // The user was redirected back from the OAuth form with an authorization code.
            $code = $_GET['code'];
            try {
                $resp = \Stripe\OAuth::token(array(
                    'grant_type' => 'authorization_code',
                    'code' => $code,
                ));
            } catch (\Stripe\Error\OAuth\OAuthBase $e) {
                wp_die( $e->getMessage() );
            }


            $stripe_id = $resp->stripe_user_id;
        	edd_update_option('payout_stripe_account', $stripe_id );

            $state = isset($_GET['state']) ? $_GET['state'] : '';
           	if( $state == 'edds-page' ){
            	wp_redirect( admin_url( 'edit.php?post_type=download&page=edd-settings&tab=gateways&section=edd-stripe' ) );
            	exit();
            }

        } elseif (isset($_GET['deauth'])) {

            // Deauthorization request
         //    $accountId = $_GET['deauth'];

         //    try {
	        //     \Stripe\OAuth::deauthorize(array(
	        //         'stripe_user_id' => $accountId,
	        //         'redirect_uri' => 'http://dev.funkmo/g4g/?debug',
	        //     ));
	        // } catch (\Stripe\Error\OAuth\OAuthBase $e) {
	        //     exit("Error: " . $e->getMessage());
	        // }

       		edd_update_option('payout_stripe_account', '' );
	        if( $de && ($state == 'edds-page') ){
            	wp_redirect( admin_url( 'edit.php?post_type=download&page=edd-settings&tab=gateways&section=edd-stripe' ) );
            	exit();
            }

            wp_die( '<p>Success! Account <code>$accountId</code> is disonnected.</p>' );
        } elseif (isset($_GET['error'])) {
            // The user was redirect back from the OAuth form with an error.
            $error = $_GET['error'];
            $error_description = $_GET['error_description'];

            wp_die( $error_description, 'Error: ' . $error );

        } 

	} elseif($_GET['connect-listener'] == 'webhook'){

		if ( method_exists( '\Stripe\Stripe', 'setAppInfo' ) ) {
			\Stripe\Stripe::setAppInfo( 'Easy Digital Downloads - Stripe', EDD_STRIPE_VERSION, esc_url( site_url() ) );
		}

		// retrieve the request's body and parse it as JSON
		$body = @file_get_contents( 'php://input' );
		$event = json_decode( $body );

		// echo "<pre>";
		// print_r( $event);
		// echo "</pre>";
		// exit();

		status_header( 200 );
		
		do_action( 'connect_listener_webhook', $event );

		die( '1' ); // Completed successfully
	}
}
add_action( 'init', 'edds_stripe_connect_listener' );

function edds_add_connected_stripe_amount($purchase_data, $valid_data){

	if(!class_exists('Charitable_EDD_Cart')){
		return $purchase_data;
	}

	$cart      = new Charitable_EDD_Cart( edd_get_cart_contents(), edd_get_cart_fees( 'item' ) );
	$campaigns = $cart->get_benefits_by_campaign();

	if(class_exists('PP_Team_Fundraising')){
		$_campaign_on_cart = PP_Team_Fundraising::pp_get_campaigns_on_cart();
		$campaign_on_cart = array_keys($_campaign_on_cart);
	}

	$stripe_ids = array();
	$campaign_benefited = array();
	foreach ($campaigns as $campaign_id => $value) {

		if(class_exists('PP_Team_Fundraising') && !in_array($campaign_id, $campaign_on_cart)){
			continue;
		}

		// default
		$stripe_id = edd_get_option('payout_stripe_account');
		if(empty($stripe_id)){
			continue;
		}

		$parent_id = wp_get_post_parent_id( $campaign_id );
		$id = !empty($parent_id) ? $parent_id : $campaign_id;

		$campaign_benefited[$id] = get_the_title( $id );

		$dest = get_post_meta( $id, '_campaign_payout_options', true );
		if( ($dest == 'direct') && !empty( get_post_meta( $id, '_campaign_connected_stripe_id', true ) ) ){
			$stripe_id = get_post_meta( $id, '_campaign_connected_stripe_id', true );
		}

		$sum_value = array_sum($value);

		$platform_fee = pp_get_platform_fee($id);
		
		$stripe_ids[$stripe_id] = array(
			'platform_fee' => pp_edds_calculate_fee($platform_fee, $sum_value),
			'total' => $sum_value,
		);
	}

	$purchase_data['campaign_connect_and_fee'] = $stripe_ids;
	$purchase_data['campaign_benefited'] = implode(', ', $campaign_benefited);

	// DEBUG
	// echo implode(', ', $campaign_benefited);
	// echo "<pre>";
	// print_r($campaign_benefited);
	// echo "</pre>";
	// exit();

	return $purchase_data;
}
add_filter( 'edd_purchase_data_before_gateway', 'edds_add_connected_stripe_amount', 10, 2 );