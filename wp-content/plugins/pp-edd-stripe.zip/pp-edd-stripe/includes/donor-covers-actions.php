<?php
/**
 * Add additional meta fields to be saved when updating a campaign.
 */
function add_donor_covers_fee_meta_keys( $keys ) {
	array_push( $keys,
		'_campaign_donor_covers_fee'
	);

	return $keys;
}
add_filter( 'charitable_campaign_meta_keys', 'add_donor_covers_fee_meta_keys' );

function add_metabox_donor_covers_fee($fields){

	if(!empty( edd_get_option('donor_covers_fee') )){
		return $fields;
	}

	$fields['section-edd-separator'] = array(
		'view'              => 'metaboxes/field-types/hr',
		'priority'          => 15,
	);

	$fields['pp-donor-covers-fee'] = array(
		'view'              => 'metaboxes/field-types/checkbox',
		'priority'          => 15.1,
		'label'             => __( 'Enable donor covers fee', 'charitable-edd' ),
		'meta_key'          => '_campaign_donor_covers_fee',
		'default'           => 0,
	);

	return $fields;
}

add_filter( 'charitable_campaign_donation_options_fields', 'add_metabox_donor_covers_fee' );

function display_donor_covers_fee_options(){

	$payment_mode = edd_get_chosen_gateway();

	if(!class_exists('Charitable_EDD_Cart')){
		return;
	}

	if(class_exists('PP_Team_Fundraising')){
		$_campaign_on_cart = PP_Team_Fundraising::pp_get_campaigns_on_cart();
		$campaign_ids = array_keys($_campaign_on_cart);
	} else {
		$cart      = new Charitable_EDD_Cart( edd_get_cart_contents(), edd_get_cart_fees( 'item' ) );
		$campaigns = $cart->get_benefits_by_campaign();
		$campaign_ids = array_keys($campaigns);
	}

	$campaign_title = '';

	if(!$enable_donor_covers_fee && !empty($campaign_ids)):
	foreach ($campaign_ids as $campaign_id) {

		if( pp_is_donor_cover_fee_enabled_for_campaign($campaign_id) ){
			$first_campaign_id = $campaign_id;
			$campaign_title = get_the_title( $campaign_id );
			$enable_donor_covers_fee = true;
			break;
		}
	}
	endif;

	if(empty($campaign_title)){
		$first_campaign_id = current($campaign_ids);
		$campaign_title = get_the_title( $first_campaign_id );
	}

	$platform_fee = pp_get_platform_fee( $first_campaign_id );
	$stripe_percent_fee = pp_get_stripe_percent_fee( $first_campaign_id );

	// var_dump($enable_donor_covers_fee);
	// echo "<pre>";
	// print_r($campaign_ids);
	// echo "</pre>";
	
	if(!$enable_donor_covers_fee || empty($platform_fee)){
		return;
	}

	?>
	<fieldset id="edd_checkout_user_info">
		<div id="switch-covers-fee" class="switch-button">
			<input id="donor-covers-fee" type="checkbox" data-total="<?php echo edd_get_cart_total(); ?>" data-platform-fee="<?php echo $platform_fee; ?>" data-stripe-percent-fee="<?php echo $stripe_percent_fee; ?>" <?php checked($enable_donor_covers_fee); ?>>
			<label for="donor-covers-fee"><?php _e('Cover Fee', 'pp-toolkit'); ?></label>
		</div>
		<p>I'd like to cover the processing fee so that 100% of my donation goes to <?php echo $campaign_title; ?>.</p>
		<p class="hidden" style="display: none;">
			<input type="text" id="covered-platform-fee" name="covered-platform-fee">
			<input type="text" id="covered-stripe-fee" name="covered-stripe-fee">
			<input type="text" id="covered-fee" name="covered-fee">
		</p>
	</fieldset>
	<?php
}
add_action( 'edd_purchase_form_top', 'display_donor_covers_fee_options' );


function load_donor_covers_fee_js(){
	wp_register_script( 'pp-donor-covers-fee-js', EDDSTRIPE_PLUGIN_URL . 'assets/js/pp-donor-covers-fee.js', array( 'jquery' ), EDD_STRIPE_VERSION, true );

	if ( edd_is_checkout() ) {
		wp_enqueue_script( 'pp-donor-covers-fee-js' );

		$vars = array();

		wp_localize_script( 'pp-donor-covers-fee-js', 'DONOR_COVERS_FEE_VARS', $vars );
	}
}
add_action( 'wp_enqueue_scripts', 'load_donor_covers_fee_js', 100 );

function pp_add_covered_fee_amount($purchase_data, $valid_data){

	if(!isset($purchase_data['post_data']['covered-fee'])){
		return $purchase_data;
	}

	$purchase_data['covered_platform_fee'] = floatval($purchase_data['post_data']['covered-platform-fee']);
	$purchase_data['covered_stripe_fee'] = floatval($purchase_data['post_data']['covered-stripe-fee']);
	$purchase_data['covered_fee'] = floatval($purchase_data['post_data']['covered-fee']);

	return $purchase_data;
}
add_filter( 'edd_purchase_data_before_gateway', 'pp_add_covered_fee_amount', 10, 2 );