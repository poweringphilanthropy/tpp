(function($) {
   var PP_Donor_Covers_Fee = {
      init: function() {
         $(document).on('change', '#donor-covers-fee', this.updateDonorCoversFee);
         $('body').on('edd_gateway_loaded', function(){
            $('#donor-covers-fee').trigger('change');
         });
         
      },
      updateDonorCoversFee: function() {

         var donation_val = parseFloat($(this).attr('data-total'));
         var fee_percent = parseFloat($(this).attr('data-platform-fee'));
         var _fee = {
            Percent: parseFloat($(this).attr('data-stripe-percent-fee')),
            Fixed: 0.30
         };

         if( $(this).is(':checked') ){

            var platform_fee = PP_Donor_Covers_Fee.getPlatformFee(donation_val, fee_percent);
            var total_donation_with_fee = parseFloat(platform_fee) + parseFloat(donation_val);
            var stripe_fee = PP_Donor_Covers_Fee.calCulateStripeFee(total_donation_with_fee, _fee );
            
            var covered_fee = parseFloat(platform_fee) + parseFloat(stripe_fee.fee);
            // alert(covered_fee);

            $('#covered-platform-fee').val(platform_fee);
            $('#covered-stripe-fee').val(stripe_fee.fee);
            $('#covered-fee').val(covered_fee);

            var message = 'Donation amount: ' + donation_val + '\n';
            message += 'Platform Fee: ' + platform_fee + '\n';
            message += 'Stripe Fee: ' + stripe_fee.fee + '\n';
            message += 'Total: ' + stripe_fee.total + '\n';
            message += 'Covered Fee: ' + covered_fee + '\n';
            // alert(message);
            
            console.log(message);
         } else {
            $('#covered-platform-fee').val('');
            $('#covered-stripe-fee').val('');
            $('#covered-fee').val('');
         }
      },
      getPlatformFee: function(donation_amount, fee_percent) {
         var platform_fee_amount = ( parseFloat(fee_percent) / 100) * parseFloat(donation_amount);
         return platform_fee_amount.toFixed(2);
      },
      calCulateStripeFee: function(amount, _fee ) {
         var total = (parseFloat(amount) + parseFloat(_fee.Fixed)) / (1 - parseFloat(_fee.Percent) / 100);
         var fee = total - amount;
         return {
            amount: amount,
            fee: fee.toFixed(2),
            total: total.toFixed(2)
         };
      }
   };
   PP_Donor_Covers_Fee.init();
})(jQuery);