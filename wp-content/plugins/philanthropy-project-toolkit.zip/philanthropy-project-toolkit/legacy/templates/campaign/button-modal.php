<?php 
/**
 * Displays the button for heading
 *
 * @author Lafif <[<email address>]>
 * @since   1.0
 */

$campaign = $view_args[ 'campaign' ];

?>
<div class="heading-button-col">
	<a class="heading-button" href="#" data-p_popup-open="<?php echo $view_args[ 'id' ]; ?>"><?php echo $view_args[ 'label' ]; ?></a>
</div>