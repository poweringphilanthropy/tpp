<?php
_deprecated_file( __FILE__, '4.4.2', 'Tribe__Tickets_Plus__Commerce__WPEC__Main' );

/**
 * @deprecated 4.4.2
 */
class Tribe__Tickets_Plus__Commerce__WPEC__Main {
	public function __get( $unused ) {}
	public function __set( $unused_a, $unused_b ) {}
	public function __call( $unused_a, $unused_b ) {}
}