<?php

class Tribe__Tickets_Plus__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'eeb947e3ac1e2711e38cc23ec567c739494a5a99';

}
