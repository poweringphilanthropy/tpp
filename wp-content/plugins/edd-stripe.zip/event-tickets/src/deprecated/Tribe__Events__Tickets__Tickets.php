<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Tickets__Tickets' );


abstract class Tribe__Events__Tickets__Tickets extends Tribe__Tickets__Tickets {}
