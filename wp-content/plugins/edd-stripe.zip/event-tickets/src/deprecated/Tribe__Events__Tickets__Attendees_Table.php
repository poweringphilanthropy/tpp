<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Tickets__Attendees_Table' );

class Tribe__Events__Tickets__Attendees_Table extends Tribe__Tickets__Attendees_Table {}
