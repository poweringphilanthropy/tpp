<?php
_deprecated_file( __FILE__, '4.2', 'Tribe__Tickets__JSON_LD__Order' );


class Tribe__Tickets__Google_Event_Data extends Tribe__Tickets__JSON_LD__Order {}
