<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Customize the finished campaign notice. 
 *
 * @param   string $message
 * @param   Charitable_Campaign $campaign
 * @return  string
 * @since   1.0.3
 */
function pp_charitable_campaign_finished_notice( $message, $campaign ) {
    if ( $campaign->has_goal() && $campaign->has_achieved_goal() ) {
        $message = __( 'This campaign successfully reached its funding goal and ended %s ago', 'pp-toolkit' );
    }
    else {
        $message = __( 'This campaign ended %s ago', 'pp-toolkit' );
    }

    return sprintf( $message, '<span class="time-ago">' . human_time_diff( $campaign->get_end_time() ) . '</span>' );
}   

add_filter( 'charitable_campaign_finished_notice', 'pp_charitable_campaign_finished_notice', 10, 2 );

add_filter( 'charitable_campaign_show_achievement_status_tag', '__return_false' );