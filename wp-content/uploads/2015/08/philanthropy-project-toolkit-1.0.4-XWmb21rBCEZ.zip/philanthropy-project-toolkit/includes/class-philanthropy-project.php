<?php
/**
 * Core plugin class. 
 *
 * @package     Philanthropy Project/Classes/Philanthropy_Project
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Philanthropy_Project' ) ) : 

/**
 * Philanthropy_Project
 *
 * @since       1.0.0
 */
class Philanthropy_Project {

    /**
     * @var string
     */
    const VERSION = '1.0.4';

    /**
     * @var string  A date in the format: YYYYMMDD
     */
    const DB_VERSION = '20150423';  

    /**
     * @var Philanthropy_Project
     */
    private static $instance = null;

    /**
     * The root file of the plugin. 
     * 
     * @var     string
     * @access  private
     */
    private $plugin_file; 

    /**
     * The root directory of the plugin.  
     *
     * @var     string
     * @access  private
     */
    private $directory_path;

    /**
     * The root directory of the plugin as a URL.  
     *
     * @var     string
     * @access  private
     */
    private $directory_url;

    /**
     * Create class instance. 
     * 
     * @return  void
     * @since   1.0.0
     */
    public function __construct( $plugin_file ) {        
        $this->plugin_file      = $plugin_file;
        $this->directory_path   = plugin_dir_path( $plugin_file );
        $this->directory_url    = plugin_dir_url( $plugin_file );
        
        add_action( 'charitable_start', array( $this, 'start' ), 10 );
    }

    /**
     * Returns the original instance of this class. 
     * 
     * @return  Charitable
     * @since   1.0.0
     */
    public static function get_instance() {
        return self::$instance;
    }

    /**
     * Start the plugin functionality. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function start() {

        /* If we've already started (i.e. run this function once before), do not pass go. */
        if ( $this->started() ) {
            return;
        }

        /* Set static instance */
        self::$instance = $this;

        $this->load_dependencies();

        $this->attach_hooks_and_filters();

        /* Hook in here to do something when the plugin is first loaded */
        do_action('philanthropy_project_start', $this);
    }

    /**
     * Include necessary files.
     * 
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function load_dependencies() {
        require_once( $this->get_path( 'includes' ) . 'class-pp-charitable-campaign-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-merchandise-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-event-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-ticket-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-template.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-widget-campaign-events.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-core-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-atcf-migration-functions.php' );        
        require_once( $this->get_path( 'includes' ) . 'pp-edd-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-charitable-form-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-admin-metaboxes-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-shortcode-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-tribe-events-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-donor-photo-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-account-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-template-functions.php' );
    }

    /**
     * Set up hook and filter callback functions.
     * 
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function attach_hooks_and_filters() {
        /* Action Hooks */       
        add_action( 'philanthropy_project_start', array( 'PP_Charitable_Campaign_Form', 'start' ) );
        add_action( 'charitable_campaign_submission_save', array( 'PP_Merchandise_Form', 'save_merchandise' ), 10, 3 );
        add_action( 'charitable_campaign_submission_save', array( 'PP_Event_Form', 'save_event' ), 10, 3 );
        add_action( 'widgets_init', array( $this, 'register_widget' ) );
        add_action( 'init', array( $this, 'maybe_download_event_attendees_list' ) );
        add_action( 'edd_payment_receipt_after_table', array( $this, 'merchandise_and_events_tables_receipt' ) );
        // add_action( 'charitable_edd_donation_form', array( $this, 'override_downloads_template' ) );
        // add_action( 'charitable_edd_donation_form_downloads', array( $this, 'select_downloads_template' ) );

        add_action( 'charitable_user_event_summary_before', 'pp_charitable_my_tribe_events_render_event_thumbnail', 10, 2 );
        add_action( 'charitable_user_event_summary', 'pp_charitable_my_tribe_events_render_event_summary', 10, 2 );
        add_action( 'charitable_user_event_summary_after', 'pp_charitable_my_tribe_events_render_event_actions', 10, 2 );       
        add_action( 'charitable_user_product_summary_before', 'pp_charitable_my_edd_products_render_product_thumbnail', 10, 2 );
        add_action( 'charitable_user_product_summary', 'pp_charitable_my_edd_products_render_product_summary', 10, 2 );
        add_action( 'charitable_user_product_summary_after', 'pp_charitable_my_edd_products_render_product_actions', 10, 2 );               

        /* Filters */
        add_filter( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_filter( 'charitable_is_page_registration_page', array( $this, 'is_registration_page' ) );
        add_filter( 'charitable_donors_widget_donor_query_args', array( $this, 'filter_donors_widget_query_args' ) );
        
        /* Shortcodes */
        add_shortcode( 'pp_edd_product_form', 'pp_edd_product_form_shortcode' );
        add_shortcode( 'charitable_my_edd_products', 'pp_charitable_my_edd_products_shortcode' );
        add_shortcode( 'charitable_my_tribe_events', 'pp_charitable_my_tribe_events_shortcode' );

        /* Undo hooks */
        if ( function_exists( 'charitable_edd' ) ) {
            remove_action( 'edd_checkout_table_footer_last', array( charitable_edd()->get_object( 'Charitable_EDD_Checkout' ), 'donation_amount_notice_checkout' ) );
            remove_action( 'edd_payment_receipt_after_table',  array( charitable_edd()->get_object( 'Charitable_EDD_Payment' ), 'products_table_receipt' ) );
        }        
    }

    /**
     * Returns whether we are currently in the start phase of the plugin. 
     *
     * @return  bool
     * @access  public
     * @since   1.0.0
     */
    public function is_start() {
        return current_filter() == 'philanthropy_project_start';
    }

    /**
     * Returns whether the plugin has already started.
     * 
     * @return  bool
     * @access  public
     * @since   1.0.0
     */
    public function started() {
        return did_action( 'philanthropy_project_start' ) || current_filter() == 'philanthropy_project_start';
    }

    /**
     * Returns the plugin's version number. 
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_version() {
        return self::VERSION;
    }

    /**
     * Returns plugin paths. 
     *
     * @param   string $path            // If empty, returns the path to the plugin.
     * @param   bool $absolute_path     // If true, returns the file system path. If false, returns it as a URL.
     * @return  string
     * @since   1.0.0
     */
    public function get_path($type = '', $absolute_path = true ) {      
        $base = $absolute_path ? $this->directory_path : $this->directory_url;

        switch( $type ) {
            case 'includes' : 
                $path = $base . 'includes/';
                break;

            case 'admin' :
                $path = $base . 'includes/admin/';
                break;

            case 'templates' : 
                $path = $base . 'templates/';
                break;

            case 'assets' : 
                $path = $base . 'assets/';
                break;              

            case 'directory' : 
                $path = $base;
                break;

            default :
                $path = $this->plugin_file;
        }

        return $path;
    }

    /**
     * Download event attendees.  
     *
     * @return  boolean 
     * @access  public
     * @since   1.0.0
     */
    public function maybe_download_event_attendees_list() {        
        if ( ! isset( $_GET[ 'download_attendees' ] ) ) {
            return false;
        }

        if ( ! isset( $_GET[ 'event_id' ] ) ) {
            return false;
        }

        $event_id = $_GET[ 'event_id' ];
       
        return pp_download_event_attendees( $event_id );
    }

    /**
     * Load our custom merchandise and events tables on the payment receipt page. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function merchandise_and_events_tables_receipt() {
        new PP_Toolkit_Template( 'payment-receipt/products.php' );
    }

    /**
     * Use our own custom template to display the download selections. 
     *
     * @param   Charitable_EDD_Donation_Form $form
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function override_downloads_template( Charitable_EDD_Donation_Form $form ) {
        remove_action( 'charitable_edd_donation_form_before_downloads', array( $form, 'enter_downloads_section_header' ) );
        remove_action( 'charitable_edd_donation_form_downloads', array( $form, 'select_downloads' ) );        
    }

    /**
     * Display our downloads selection template. 
     *
     * @param   Charitable_EDD_Donation_Form $form
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function select_downloads_template( Charitable_EDD_Donation_Form $form ) {
        $template = new PP_Toolkit_Template( 'donation-form/select-downloads.php', false );
        $template->set_view_args( $form->get_view_args() );
        $template->render();
    }

    /**
     * Register the Campaign Events widget.
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function register_widget() {
        register_widget( 'PP_Widget_Campaign_Events' );
    }

    /**
     * Load custom scripts.  
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function enqueue_scripts() {
        if ( charitable_is_page( 'registration_page' ) ) {
            wp_register_script( 'pp-registration-handler', $this->get_path( 'assets', false ) . 'js/registration-handler.js', array( 'jquery-ui-datepicker' ), '1.0.0', true );
            wp_enqueue_script( 'pp-registration-handler' );
        }

        /* This script is registered here, but enqueued by the form class to ensure that it's only loaded when we're looking at the form. */
        wp_register_script( 'pp-product-submission', $this->get_path( 'assets', false ) . 'js/product-submission.js', array( 'jquery-ui-datepicker', 'jquery' ), '1.0.0', true );
        $localized_vars = array(
            'price_name_label'      => __( 'Name', 'pp-toolkit' ),
            'price_amount_label'    => __( 'Price', 'pp-toolkit' )
        );
        wp_localize_script( 'pp-product-submission', 'PP_PRODUCT_SUBMISSION', $localized_vars );        

        wp_register_style( 'pp-product-submission-css', $this->get_path( 'assets', false ) . 'css/product-submission.css' );

        if ( charitable_is_page( 'campaign_submission_page' ) ) {
            wp_enqueue_script( 'pp-product-submission' );
            wp_enqueue_style( 'pp-product-submission-css' );
        }
    }

    /**
     * Checks whether the current request is for the campaign editing page. 
     *
     * This is used when you call charitable_is_page( 'registration_page' ). 
     * In general, you should use charitable_is_page() instead since it will
     * take into account any filtering by plugins/themes.
     *
     * @see     charitable_is_page
     * @return  boolean
     * @since   1.0.0
     */
    public function is_registration_page( $r= false ) {
        return charitable_is_page( 'login_page' );
    }

    /**
     * Fetch all donors for a donation, including duplicate donations. 
     *
     * @param   mixed[] $args
     * @return  mixed[]
     * @access  public
     * @since   1.0.0
     */
    public function filter_donors_widget_query_args( $args ) {
        $args[ 'distinct' ] = false;
        return $args;
    }    
}

endif; // End class_exists check