<?php

function pp_front_end_login_fail($username){
    $referrer = $_SERVER['HTTP_REFERER'];
    
    if ( !empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin') ) {
        $redirect_url = site_url('/login/') . '?error=failed';
        wp_safe_redirect($redirect_url); 
    }
    
}

add_action('wp_login_failed', 'pp_front_end_login_fail'); 

function pp_catch_empty_user( $username, $pwd ) {
    $referrer = $_SERVER['HTTP_REFERER'];
    
    if ( !empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin') ) {

      if ( empty( $username ) ) {
            $redirect_url = site_url('/login/') . '?error=username';
            wp_safe_redirect($redirect_url); 
            exit();
      }
    
      if ( empty( $pwd ) ) {
            $redirect_url = site_url('/login/') . '?error=password';
            wp_safe_redirect($redirect_url); 
            exit();
      }
                
    }
}

add_action( 'wp_authenticate', 'pp_catch_empty_user', 1, 2 );

function pp_custom_login_lostpassword_url() {
    return site_url('/recover-password/');
}

add_filter("lostpassword_url", "pp_custom_login_lostpassword_url");

function pp_remove_admin_bar() {
    if ( !current_user_can('administrator') && !is_admin() ) {
        show_admin_bar(false);
    }
}

add_action('after_setup_theme', 'pp_remove_admin_bar');