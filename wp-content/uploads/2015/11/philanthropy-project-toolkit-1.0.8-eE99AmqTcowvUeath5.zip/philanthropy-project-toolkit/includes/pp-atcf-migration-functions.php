<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Copy additional fields when migrating from ATCF to Charitable.
 *
 * @param   array   $meta
 * @param   int     $download_id
 * @return  array
 */
function pp_charitable_atcf_migrate_campaign_meta( $meta, $download_id ) {
    $meta[ '_campaign_philanthropy_project' ]   = get_post_meta( $download_id, 'campaign_philanthropy_project', true );
    $meta[ '_campaign_group_campaign' ]         = get_post_meta( $download_id, 'campaign_group_campaign', true );
    return $meta;
}

add_filter( 'charitable_atcf_migration_campaign_meta', 'pp_charitable_atcf_migrate_campaign_meta', 10, 2 );

