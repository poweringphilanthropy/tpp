<?php
/**
 * Display a widget with donors, either for a specific campaign or sitewide.
 *
 * @author  Studio 164a
 * @since   1.0.0
 */

$widget_title   = apply_filters( 'widget_title', $view_args['title'] );
$donors         = $view_args[ 'donors' ];

/* If there are no donors and the widget is configured to hide when empty, return now. */
if ( ! $donors->count() && $view_args[ 'hide_if_no_donors' ] ) {
    return;
}

echo $view_args['before_widget'];

if ( ! empty( $widget_title ) ) :
    echo $view_args['before_title'] . $widget_title . $view_args['after_title'];
endif;

if ( $donors->count() ) : 
    ?>
    
    <ul class="donors-list">

        <?php foreach ( $donors as $donor ) : 
        
            $payment_id = Charitable_EDD_Payment::get_payment_for_donation( $donor->donation_id );
            $user_info = edd_get_payment_meta_user_info( $payment_id );

            $name = sprintf( '%s %s', 
                isset( $user_info[ 'first_name' ] ) ? $user_info[ 'first_name' ] : '', 
                isset( $user_info[ 'last_name' ] ) ? $user_info[ 'last_name' ] : '' 
            );

            if ( empty( trim( $name ) ) ) {
                $name = $donor->get_name();
            }
            ?>

            <li class="donor">  

                <?php
                $user_thumbnail = pp_get_donor_user_thumbnail( $donor, $payment_id );

                echo strlen( $user_thumbnail ) ? $user_thumbnail : $donor->get_avatar();                
                
                if ( $view_args[ 'show_name'] ) : ?>

                    <h6 class="donor-name"><?php echo $name ?></h6>

                <?php 

                endif;

                if ( $view_args[ 'show_location' ] ) : ?>

                    <span clss="donor-location"><?php echo $donor->get_location() ?></span>

                <?php 

                endif;

                if ( $view_args[ 'show_amount' ] ) : ?>

                    <span clss="donor-donation-amount"><?php echo charitable_get_currency_helper()->get_monetary_amount( $donor->get_amount() ) ?></span>

                <?php endif ?>

            </li>

        <?php endforeach ?>

    </ul>

<?php
else : 

    ?>

    <p><?php _e( 'No donors yet. Be the first!', 'charitable' ) ?></p>

    <?php

endif;

echo $view_args['after_widget'];