<?php
/**
 * The class that is responsible for augmenting the campaign submission form, adding the 
 * avatar field and saving it correctly on form save.
 *
 * @package     Charitable Simple Updates/Classes/Charitable_Simple_Updates_Campaign_Form
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Simple_Updates_Campaign_Form' ) ) : 

/**
 * Charitable_Simple_Updates_Campaign_Form
 *
 * @since       1.0.0
 */
class Charitable_Simple_Updates_Campaign_Form {

    /**
     * Create object instance.  
     *
     * @return  Charitable_Simple_Updates_Campaign_Form
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function start( Charitable_Simple_Updates $charitable_ua ) {
        if ( ! $charitable_ua->is_start() ) {
            return;
        }

        return new Charitable_Simple_Updates_Campaign_Form();
    }

    /**
     * Create class object.
     * 
     * @access  protected
     * @since   1.0.0
     */
    protected function __construct() {
        add_filter( 'charitable_user_fields',           array( $this, 'add_avatar_field' ), 10, 2 );
        add_filter( 'charitable_profile_update_values', array( $this, 'save_avatar' ), 10, 3 );
    }

    /**
     * Add avatar section to user profile form. 
     *
     * @param   array[]                     $fields
     * @param   Charitable_Campaign_Form     $form
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_avatar_field( $fields, $form ) {
        $fields[ 'avatar' ] = apply_filters( 'charitable_simple_updates_field_args', array(
            'label'     => __( 'Your Profile Photo', 'charitable' ),
            'type'      => 'picture',
            'value'     => $form->get_user()->get_avatar_src( 100 ),
            'priority'  => 14, 
            'fullwidth' => true
        ) );

        return $fields;
    }

    /**
     * Upload avatar and add file fields to the submitted fields. 
     *
     * @param   array       $submitted
     * @param   array[]     $fields
     * @param   Charitable_Campaign_Form     $form
     * @return  array 
     * @access  public
     * @since   1.0.0
     */
    public function save_avatar( $submitted, $fields, $form ) {

        if ( isset( $_FILES ) && isset( $_FILES[ 'avatar' ] ) ) {

            $file = $form->upload_file( 'avatar' );

            if ( ! is_wp_error( $file ) ) {

                $submitted[ 'avatar' ] = $file;

                /* Delete the previously upload avatar. */
                $old_avatar = get_user_meta( $form->get_user()->ID, 'avatar', true );

                if ( ! empty( $old_avatar ) && is_array( $old_avatar ) && isset( $old_avatar[ 'file' ] ) ) {

                    unlink( $old_avatar[ 'file' ] );

                }

            }
            else {
                /** 
                 * @todo Handle image upload error.
                 */
            }
        }

        return $submitted;
    }   
}

endif; // End class_exists check