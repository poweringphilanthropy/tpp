<?php
/**
 * The class that is responsible for augmenting the campaign submission form, adding the 
 * updates field when editing the campaign.
 *
 * @package     Charitable Simple Updates/Classes/Charitable_Simple_Updates_Campaign_Form
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Simple_Updates_Campaign_Form' ) ) : 

/**
 * Charitable_Simple_Updates_Campaign_Form
 *
 * @since       1.0.0
 */
class Charitable_Simple_Updates_Campaign_Form {

    /**
     * Create object instance.  
     *
     * @return  Charitable_Simple_Updates_Campaign_Form
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function start( Charitable_Simple_Updates $charitable_su ) {
        if ( ! $charitable_su->is_start() ) {
            return;
        }

        return new Charitable_Simple_Updates_Campaign_Form();
    }

    /**
     * Create class object.
     * 
     * @access  protected
     * @since   1.0.0
     */
    protected function __construct() {
        
    }
}

endif; // End class_exists check