<?php
/**
 * The class that is responsible for augmenting the campaign submission form, adding the 
 * updates field when editing the campaign.
 *
 * @package     Charitable Simple Updates/Classes/Charitable_Simple_Updates_Campaign_Form
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Simple_Updates_Campaign_Form' ) ) : 

/**
 * Charitable_Simple_Updates_Campaign_Form
 *
 * @since       1.0.0
 */
class Charitable_Simple_Updates_Campaign_Form {

    /**
     * Create object instance.  
     *
     * @return  Charitable_Simple_Updates_Campaign_Form
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function start( Charitable_Simple_Updates $charitable_su ) {
        if ( ! $charitable_su->is_start() ) {
            return;
        }

        return new Charitable_Simple_Updates_Campaign_Form();
    }

    /**
     * Create class object.
     * 
     * @access  protected
     * @since   1.0.0
     */
    protected function __construct() {
        add_filter( 'charitable_campaign_submission_campaign_fields', array( $this, 'add_updates_field' ), 10, 2 );
    }

    /**
     * Add an updates field to the campaign submission form.  
     *
     * @param   array[] $fields
     * @param   Charitable_Ambassadors_Campaign_Form $form
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_updates_field( $fields, Charitable_Ambassadors_Campaign_Form $form ) {
        $fields[ 'updates' ] = array(
            'label'         => __( 'Updates', 'charitable-simple-updates' ), 
            'type'          => 'editor', 
            'priority'      => 14.1, 
            'required'      => false, 
            'fullwidth'     => true, 
            'update_only'   => true,
            'value'         => $form->get_campaign_value( 'updates' ), 
            'data_type'     => 'meta'
        );

        return $fields;
    }
}

endif; // End class_exists check