<?php
/**
 * Class that models the new donation email.
 *
 * @version     1.0.0
 * @package     Charitable/Classes/Charitable_Ambassadors_Email_New_Campaign
 * @author      Eric Daams
 * @copyright   Copyright (c) 2015, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Ambassadors_Email_New_Campaign' ) ) : 

/**
 * New Donation Email 
 *
 * @since       1.0.0
 */
class Charitable_Ambassadors_Email_New_Campaign extends Charitable_Email {

    /**
     * @var     string
     */
    CONST ID = 'new_campaign';

    /**
     * @var     string[] Array of supported object types (campaigns, donations, donors, etc).
     * @access  protected
     * @since   1.0.0
     */
    protected $object_types = array( 'campaign' );

    /**
     * Instantiate the email class, defining its key values.
     *
     * @param   mixed[]  $objects
     * @access  public
     * @since   1.0.0
     */
    public function __construct( $objects = array() ) {
        parent::__construct( $objects );
        $this->name = apply_filters( 'charitable_email_new_campaign_name', __( 'New Campaign Notification', 'charitable-ambassadors' ) );        
    }

    /**
     * Returns the current email's ID.  
     *
     * @return  string
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function get_email_id() {
        return self::ID;
    }

    /**
     * Return the default recipient for the email.
     *
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_default_recipient() {
        return get_option( 'admin_email' );
    }

    /**
     * Return the default subject line for the email.
     *
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_default_subject() {
        return __( 'A new campaign has been submitted', 'charitable-ambassadors' );   
    }

    /**
     * Return the default headline for the email.
     *
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_default_headline() {
        return apply_filters( 'charitable_email_new_campaign_default_headline', __( 'New Campaign', 'charitable-ambassadors' ), $this );    
    }

    /**
     * Return the default body for the email.
     *
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_default_body() {
        ob_start();
?>
        <p>[charitable_email show=campaign_creator] has just made a donation!</p>
        <p>Summary:<br />
        [charitable_email show=donation_summary]</p>
<?php
        $body = ob_get_clean();

        return apply_filters( 'charitable_email_new_campaign_default_body', $body, $this );
    }    
}

endif; // End class_exists check