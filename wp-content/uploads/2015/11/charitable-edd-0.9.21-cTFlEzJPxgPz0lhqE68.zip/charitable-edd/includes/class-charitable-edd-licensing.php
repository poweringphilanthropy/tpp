<?php
/**
 * Class responsible for handling licensing of the plugin.
 *
 * @package     Charitable EDD/Classes/Charitable_EDD_Licensing
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_EDD_Licensing' ) ) : 

/**
 * Charitable_EDD_Licensing
 *
 * @since       1.0.0
 */
class Charitable_EDD_Licensing {

    /**
     * Create object instance on plugin load.  
     *
     * @param   Charitable_EDD      $charitable_edd 
     * @return  void
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function charitable_edd_start( Charitable_EDD $charitable_edd ) {
        if ( ! $charitable_edd->is_start() ) {
            return;
        }

        $charitable_edd->register_object( new Charitable_EDD_Licensing() );
    }

    /**
     * Create class object.
     * 
     * @access  private
     * @since   1.0.0
     */
    private function __construct() {   
    }

}

endif;