<?php
/**
 * Class responsible for adding Charitable EDD settings in admin area.
 *
 * @package		Charitable EDD/Classes/Charitable_EDD_Admin
 * @version 	1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2015, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_EDD_Admin' ) ) : 

/**
 * Charitable_EDD_Admin
 *
 * @since 		1.0.0
 */
class Charitable_EDD_Admin {

	/**
	 * Charitable_EDD object. 
	 *
	 * @var 	Charitable_EDD
	 * @access  private
	 */
	private $charitable_edd;

	/**
	 * Instantiate the class, but only during the start phase.
	 * 
	 * @param 	Charitable_EDD 		$charitable_edd
	 * @return 	void
	 * @static 
	 * @access 	public
	 * @since 	1.0.0
	 */
	public static function start( Charitable_EDD $charitable_edd ) {
		if ( $charitable_edd->started() ) {
			return;
		}

		new Charitable_EDD_Admin( $charitable_edd );
	}

	/**
	 * Set up the class. 
	 * 
	 * Note that the only way to instantiate an object is with the charitable_start method, 
	 * which can only be called during the start phase. In other words, don't try 
	 * to instantiate this object. 
	 *
	 * @param 	Charitable_EDD 		$charitable_edd
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function __construct( Charitable_EDD $charitable_edd ) {
		$this->load_dependencies();
		$this->attach_hooks_and_filters();
	}

	/**
	 * Load required files. 
	 *
	 * @return 	void
	 * @access  private
	 * @since 	1.0.0
	 */
	private function load_dependencies() {
		require_once( 'charitable-edd-core-admin-functions.php' );
	}

	/**
	 * Set up hooks and filters. 
	 *
	 * @return 	void
	 * @access  private
	 * @since 	1.0.0
	 */
	private function attach_hooks_and_filters() {
		add_filter( 'charitable_campaign_meta_boxes', array( $this, 'register_campaign_meta_box' ) );
		add_action( 'charitable_campaign_benefactor_form_extension_fields', array( $this, 'benefactor_form_fields' ), 10, 2 );
		add_action( 'charitable_benefactor_data', array( $this, 'sanitize_benefactor_data' ) );
	}

	/**
	 * Register campaign meta box table. 
	 *
	 * @param 	array 		$meta_boxes
	 * @return 	array
	 * @access  public
	 * @since 	1.0.0
	 */
	public function register_campaign_meta_box( $meta_boxes ) {
		$meta_boxes[] = array(
			'id'				=> 'campaign-edd-benefactors', 
			'title'				=> __( 'EDD Connect', 'charitable-edd' ), 
			'context'			=> 'campaign-advanced', 
			'priority'			=> 'high', 
			'view'				=> 'metaboxes/campaign-benefactors', 
			'extension'			=> 'charitable-edd'
		);

		return $meta_boxes;
	}

	/**
	 * Add EDD specific settings to capaign benefactors metabox. 
	 *
	 * @param 	Charitable_Benefactor 	$benefactor
	 * @param 	string 					$extension
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function benefactor_form_fields( $benefactor, $extension ) {
		if ( 'charitable-edd' != $extension ) {
			return;
		}

		charitable_edd_admin_view( 'metaboxes/campaign-benefactor-settings', array( 'benefactor' => $benefactor ) );
	}

	/** 
	 * Sanitize benefactor data.
	 *
	 * @param 	array 			$data
	 * @return 	array
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function sanitize_benefactor_data( $data ) {
		if ( isset( $data['edd'] ) ) {
			
			echo '<pre>'; var_dump( $data ); echo '</pre>';

			if ( 'global' == $data['edd'] ) {
				$data['benefactor'] = array(
					'edd_is_global_contribution' 	=> 1, 
					'edd_download_id'				=> 0, 
					'edd_download_category_id'		=> 0
				);
			}
			elseif ( false !== $data['edd'] ) {
				list( $type, $id ) = explode( '-', $data['edd'] );

				if ( 'download' == $type ) {
					$data['benefactor']['edd_download_id'] = $id;
				}
				elseif ( 'category' == $type ) {
					$data['benefactor']['edd_download_category_id'] = $id; 
				}
			}

			unset( $data['edd'] ); 
		}

		// echo '<pre>'; var_dump( $data ); echo '</pre>';		
		
		return $data;
	}
}

endif; // End class_exists check