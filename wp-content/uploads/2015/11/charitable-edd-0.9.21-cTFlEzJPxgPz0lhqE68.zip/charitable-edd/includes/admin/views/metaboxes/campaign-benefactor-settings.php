<?php 
/**
 * Renders the EDD part of the campaign benefactors form.
 *
 * @since 		1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2015, Studio 164a 
 */

$benefactor = isset( $view_args[ 'benefactor' ] ) ? $view_args[ 'benefactor' ] : null;

if ( is_null( $benefactor ) ) {
	$args = array(
		'id_base'							=> 'campaign_benefactor_0', 
		'name_base'							=> '_campaign_benefactor[0]', 
		'edd_download_id' 					=> '',
		'edd_download_category_id'			=> '',
		'edd_is_global_contribution'		=> 1
	);
}
else {
	$args = array(
		'id_base' 							=> 'campaign_benefactor_' . $benefactor->campaign_benefactor_id,
		'name_base' 						=> '_campaign_benefactor[' . $benefactor->campaign_benefactor_id . ']', 
		'edd_download_id' 					=> $benefactor->edd_download_id,
		'edd_download_category_id'			=> $benefactor->edd_download_category_id,
		'edd_is_global_contribution'		=> $benefactor->edd_is_global_contribution
	);	
}

$downloads 				= get_posts( array( 'post_type' => 'download', 'posts_per_page' => -1, 'post_status' => array( 'draft', 'pending', 'publish' ) ) );
$download_categories 	= get_terms( 'download_category', array( 'hide_empty' => false, 'fields' => 'id=>name' ) );
?>	
<p><label for="<?php echo $args['id_base'] ?>_edd"><?php _e( 'Connected Easy Digital Downloads products', 'charitable-edd' ) ?></label></p>
<select id="<?php echo $args['id_base'] ?>_edd" name="<?php echo $args['name_base'] ?>[edd]">
	<option value="global" <?php selected( $args['edd_is_global_contribution'] ) ?>><?php _e( 'Every Download', 'charitable-edd' ) ?></option>
	<?php 
	if ( count( $download_categories ) ) : 
		?>	
		<optgroup label="<?php _e( 'Download Categories', 'charitable-edd' ) ?>">
			<?php foreach ( $download_categories as $category_id => $name ) : ?>
				<option value="category-<?php echo $category_id ?>" <?php selected( $category_id, $args['edd_download_category_id'] ) ?>><?php echo $name ?></option>
			<?php endforeach ?>
		</optgroup>
		<?php 
	endif;

	if ( count( $downloads ) ) : 
		?>
		<optgroup label="<?php _e( 'Downloads', 'charitable-edd' ) ?>">
			<?php foreach ( $downloads as $download ) : ?>
				<option value="download-<?php echo $download->ID ?>" <?php selected( $download->ID, $args['edd_download_id'] ) ?>><?php echo $download->post_title ?></option>
			<?php endforeach ?>
		</optgroup>
		<?php 
	endif;
	?>
</select>