<?php

define( 'PHILANTHROPY_PROJECT_CAMPAIGN_ID', 4574 );

add_filter( 'oembed_ttl', function() {
	return 1; 
});
add_filter( 'embed_cache_oembed_types', function() {
	return array();
});

add_filter( 'edd_log_test_payment_stats', '__return_true' );

/**
 * Prepare child theme. 
 *
 * This enqueues the child theme's style.css file after first loading
 * the main theme's stylesheet.
 *
 * @return  void
 * @since   1.0.0
 */
function reach_child_load_styles() {    
	wp_dequeue_style( 'reach-style' );
    wp_register_style( 'franklin-palette', get_stylesheet_directory_uri() . "/palette.css", array('reach-base'), reach_get_theme()->get_theme_version() );	
    wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/custom.css", array( 'franklin-palette' ), reach_get_theme()->get_theme_version() );
    // wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/css/main.css", array( 'franklin-palette' ), reach_get_theme()->get_theme_version() );
    wp_enqueue_style( 'reach-child-styles' );

    wp_enqueue_script( 'philanthropy-project-scripts', get_stylesheet_directory_uri() . "/media/js/custom.js" );
}

add_action( 'wp_enqueue_scripts', 'reach_child_load_styles', 100 );

/**
 * Set up child theme
 */
function franklin_child_after_setup_theme() {
	register_sidebar( array(
		'id'              => 'sidebar_get_inspired',
		'name'            => __( 'Get inspired sidebar', 'reach' ),
		'description'     => __( 'The get inspired sidebar.', 'reach' ),
		'before_widget'   => '<aside id="%1$s" class="widget cf %2$s">',
		'after_widget'    => '</aside>',
		'before_title'    => '<div class="title-wrapper"><h4 class="widget-title">',
		'after_title'     => '</h4></div>'
	));

    register_sidebar( array(
        'id'              => 'sidebar_tpp_campaign',            
        'name'            => __( 'Philanthropy Project Campaign - sidebar', 'reach' ),
        'description'     => __( 'The sidebar on The Philanthropy Project campaign.', 'reach' ),
        'before_widget'   => '<aside id="%1$s" class="widget cf %2$s">',
        'after_widget'    => '</aside>',
        'before_title'    => '<div class="title-wrapper"><h4 class="widget-title">',
        'after_title'     => '</h4></div>'
    ));

    register_sidebar( array(
        'id'            => 'tpp_campaign_after_content',            
        'name'          => __( 'Philanthropy Project Campaign Campaign - below content', 'reach' ),
        'description'   => __( 'Displayed below the Philanthropy Project campaign\'s content, but above the comment section.', 'reach' ),
        'before_widget' => '<aside id="%1$s" class="widget block content-block cf %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<div class="title-wrapper"><h3 class="widget-title">',
        'after_title'   => '</h3></div>'
    ));        
}

add_action('after_setup_theme', 'franklin_child_after_setup_theme');

/**
 * Add special body class to TPP campaign page. 
 *
 * @param   string[] $classes
 * @return  string[]
 * @since   1.1.1
 */
function tpp_custom_campaign_body_class( $classes ) {
    if ( PHILANTHROPY_PROJECT_CAMPAIGN_ID == get_the_ID() ) {
        $classes[] = 'tpp-campaign';
    }

    return $classes;
}

add_filter( 'body_class', 'tpp_custom_campaign_body_class' );

/**
 * Remove the TPP campaign from the archive query.
 *
 * @param   WP_Query $wp_query
 * @return  void
 * @since   1.1.1
 */
function tpp_remove_campaign_from_archives( $query ) {
    if ( is_admin() ) {
        return;
    }

    if ( $query->is_main_query() && is_post_type_archive( 'campaign' ) ) {
        $query->set( 'post__not_in', array( PHILANTHROPY_PROJECT_CAMPAIGN_ID ) );
    }
}

add_action( 'pre_get_posts', 'tpp_remove_campaign_from_archives' );

/**
 * Remove comment form allowed tags text.
 *
 * @param   array $defaults
 * @return  array
 */
function remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

add_filter( 'comment_form_defaults', 'remove_comment_form_allowed_tags' );

/**
 * Display donate button or link in the campaign summary.
 *
 * @param   Charitable_Campaign $campaign
 * @return  boolean     True if the template was displayed. False otherwise.
 * @since   1.1.1
 */
function charitable_template_donate_button( $campaign ) {
    if ( ! $campaign->has_goal() ) {
        return false;
    }

    if ( $campaign->has_ended() ) {
        return false;
    }

    $campaign->donate_button_template();

    return true;
}

/**
 * Insert Impact Goal where stats would normally goal for campaigns without a 
 * fundraising target. 
 *
 * @param   Charitable_Campaign $campaign
 * @return  void
 * @since   1.1.1
 */
function pp_add_impact_goal_before_countdown( Charitable_Campaign $campaign ) {
    if ( $campaign->has_goal() ) {
        return;
    }

    reach_template_campaign_impact_summary( $campaign );

    remove_action( 'charitable_campaign_summary_after', 'reach_template_campaign_impact_summary', 8 );
}

add_action( 'charitable_campaign_summary', 'pp_add_impact_goal_before_countdown', 2 );