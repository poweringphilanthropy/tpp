<?php 
/*
 Template name: Featured Campaigns
 */

get_header();	

get_template_part( 'partials/banner', 'page' ); 
?>			
<?php //get_template_part( 'partials/featured-image' ); ?>
<div class="layout-wrapper">
	<main class="site-main content-area" role="main">
		<?php 
		if ( have_posts() ) :
			while ( have_posts() ) :
				the_post() ?>						
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'home-content' ) ?>>
					<?php the_content() ?>
				</article>
			<?php 
			endwhile; 
		endif; 
		?>
		<div class="campaigns-grid-wrapper">
			<?php charitable_template_campaign_loop( Charitable_Campaigns::query(), 3 ) ?>
		</div>
	</main><!-- .site-main -->	
	<?php get_sidebar( 'get-inspired' ) ?>					
</div><!-- .layout-wrapper -->
<?php

get_footer();
