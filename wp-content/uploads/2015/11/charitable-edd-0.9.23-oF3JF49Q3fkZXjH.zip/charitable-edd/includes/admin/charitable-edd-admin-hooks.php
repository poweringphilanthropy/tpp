<?php 
/**
 * Charitable EDD Admin Hooks
 *
 * Action/filter hooks used to set up the admin.
 *
 * @package     Charitable EDD/Functions/Admin
 * @version     1.0.0
 * @author      Eric Daams 
 * @copyright   Copyright (c) 2015, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Add the EDD settings to the donation options metabox.
 *
 * @see     Charitable_EDD_Admin::add_edd_meta_fields
 */
add_filter( 'charitable_campaign_donation_options_fields', array( Charitable_EDD_Admin::get_instance(), 'add_edd_metabox_fields' ) );

/**
 * Save the additional EDD settings.
 *
 * @see     Charitable_EDD_Admin::add_meta_keys
 */
add_filter( 'charitable_campaign_meta_keys', array( Charitable_EDD_Admin::get_instance(), 'add_meta_keys' ) );

/**
 * Sanitize the checkbox value of the "show contribution options" field.
 *
 * @see     Charitable_Campaign::sanitize_checkbox
 */
add_filter( 'charitable_sanitize_campaign_meta_campaign_campaign_edd_show_contribution_options', array( 'Charitable_Campaign', 'sanitize_checkbox' ) );

/**
 * Set up benefactor form fields.
 *
 * @see     Charitable_EDD_Admin::benefactor_form_fields
 */
add_action( 'charitable_campaign_benefactor_form_extension_fields', array( Charitable_EDD_Admin::get_instance(), 'benefactor_form_fields' ), 10, 3 );

/**
 * Sanitize benefactor data before saving.
 *
 * @see     Charitable_EDD_Admin::sanitize_benefactor_data
 */
add_action( 'charitable_benefactor_data', array( Charitable_EDD_Admin::get_instance(), 'sanitize_benefactor_data' ) );

/**
 * Add EDD settings to the General tab in Charitable settings.
 *
 * @see     Charitable_EDD_Admin::add_general_settings
 */
add_filter( 'charitable_settings_tab_fields_general', array( Charitable_EDD_Admin::get_instance(), 'add_general_settings' ) );               

/**
 * Add EDD settings to the General tab in Charitable settings.
 *
 * @see     Charitable_EDD_Admin::add_payment_gateway_settings
 */
add_filter( 'charitable_settings_tab_fields_gateways', array( Charitable_EDD_Admin::get_instance(), 'add_payment_gateway_settings' ) );               

