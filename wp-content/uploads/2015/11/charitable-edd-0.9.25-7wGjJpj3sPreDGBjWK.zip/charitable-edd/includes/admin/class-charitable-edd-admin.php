<?php
/**
 * Class responsible for adding Charitable EDD settings in admin area.
 *
 * @package		Charitable EDD/Classes/Charitable_EDD_Admin
 * @version 	1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2015, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_EDD_Admin' ) ) : 

/**
 * Charitable_EDD_Admin
 *
 * @since 		1.0.0
 */
class Charitable_EDD_Admin {

    /**
     * @var     Charitable_EDD_Admin
     * @access  private
     * @static
     * @since   1.0.0
     */
    private static $instance = null;

    /**
     * Create class object. Private constructor. 
     * 
     * @access  private
     * @since   1.0.0
     */
    private function __construct() {
    	require_once( 'charitable-edd-core-admin-functions.php' );
    }

    /**
     * Create and return the class object.
     *
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function get_instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new Charitable_EDD_Admin();            
        }

        return self::$instance;
    }

	/**
	 * Register campaign meta box table. 
	 *
	 * @param 	array 		$meta_boxes
	 * @return 	array
	 * @access  public
	 * @since 	1.0.0
	 */
	public function register_campaign_meta_box( $meta_boxes ) {
		$meta_boxes[] = array(
			'id'				=> 'campaign-edd-benefactors', 
			'title'				=> __( 'EDD Connect', 'charitable-edd' ), 
			'context'			=> 'campaign-advanced', 
			'priority'			=> 'high', 
			'view'				=> 'metaboxes/campaign-benefactors', 
			'extension'			=> 'charitable-edd'
		);

		return $meta_boxes;
	}

    /**
     * Add EDD settings fields into the campaign's donation options metabox. 
     *
     * @global  WP_Post $post
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_edd_metabox_fields( $fields ) {
        global $post;

        $fields[ 'section-edd-separator' ] = array(
            'view'              => 'metaboxes/field-types/hr',
            'priority'          => 20
        );

        $fields[ 'section-edd-heading' ] = array(
            'view'              => 'metaboxes/field-types/heading',
            'priority'          => 22, 
            'title'             => __( 'Easy Digital Downloads - Contributions from Purchases', 'charitable-edd' )
        );        

        $fields[ 'campaign-edd-benefactors' ] = array(
            'label'             => __( 'EDD Connect', 'charitable-edd' ), 
            'view'              => 'metaboxes/campaign-benefactors', 
            'extension'         => 'charitable-edd', 
            'priority'          => 24
        );

        if ( charitable_get_table( 'edd_benefactors' )->get_campaign_benefactors( $post->ID ) ) {

            $fields[ 'edd-show-contribution-options' ] = array(
                'view'              => 'metaboxes/field-types/checkbox',
                'priority'          => 26,
                'label'             => __( 'Show product contributing options in donation form', 'charitable-edd' ), 
                'meta_key'          => '_campaign_edd_show_contribution_options', 
                'default'           => 0
            );

            $fields[ 'edd-contribution-options-title' ] = array(
                'view'              => 'metaboxes/field-types/text',
                'priority'          => 28,
                'label'             => __( 'Contributions options header', 'charitable-edd' ), 
                'meta_key'          => '_campaign_edd_contribution_options_title', 
                'default'           => __( 'Other ways to contribute', 'charitable-edd' )
            );

            $fields[ 'edd-contribution-options-explanation' ] = array(
                'view'              => 'metaboxes/field-types/textarea',
                'priority'          => 30,
                'label'             => __( 'Contributions options explanation', 'charitable-edd' ), 
                'meta_key'          => '_campaign_edd_contribution_options_explanation', 
                'default'           => __( 'When you purchase one of these products, a contribution will be made to this fundraising campaign.', 'charitable-edd' )
            );        

        }

        return $fields;
    }

	/**
	 * Add EDD specific settings to capaign benefactors metabox. 
	 *
	 * @param 	Charitable_Benefactor $benefactor
	 * @param 	string $extension
     * @param   int $index
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function benefactor_form_fields( $benefactor, $extension, $index ) {
		if ( 'charitable-edd' != $extension ) {
			return;
		}

		charitable_edd_admin_view( 'metaboxes/campaign-benefactor-settings', array( 'benefactor' => $benefactor, 'index' => $index ) );
	}

	/** 
	 * Sanitize benefactor data.
	 *
	 * @param 	array 			$data
	 * @return 	array
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function sanitize_benefactor_data( $data ) {
		if ( isset( $data['edd'] ) ) {
			
			if ( 'global' == $data['edd'] ) {
				$data['benefactor'] = array(
					'edd_is_global_contribution' 	=> 1, 
					'edd_download_id'				=> 0, 
					'edd_download_category_id'		=> 0
				);
			}
			elseif ( false !== $data['edd'] ) {
				list( $type, $id ) = explode( '-', $data['edd'] );

				if ( 'download' == $type ) {
					$data['benefactor']['edd_download_id'] = $id;
				}
				elseif ( 'category' == $type ) {
					$data['benefactor']['edd_download_category_id'] = $id; 
				}
			}

			unset( $data['edd'] ); 
		}
		
		return $data;
	}

    /**
     * Add additional meta fields to be saved when updating a campaign. 
     *
     * @return  string[]
     * @access  public
     * @since   1.0.0
     */
    public function add_meta_keys( $keys ) {
        array_push( $keys, 
            '_campaign_edd_show_contribution_options', 
            '_campaign_edd_contribution_options_title', 
            '_campaign_edd_contribution_options_explanation'
        );

        return $keys;
    }

    /**
     * Add settings to the General tab in Charitable settings area. 
     *
     * @param   array[] $fields
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_general_settings( $fields ) {
        if ( ! charitable_is_settings_view( 'general' ) ) {
            return $fields;
        }

        $extra_fields = array(
            'section_edd' => array(
                'title'     => __( 'Easy Digital Downloads', 'charitable-edd' ),
                'type'      => 'heading',
                'priority'  => 60
            ), 
            'show_product_contribution_note' => array(
                'title'     => __( 'Show Contribution Amount on Downloads', 'charitable-edd' ), 
                'type'      => 'checkbox',
                'priority'  => 62, 
                'help'      => __( 'Show how much each download contributes to fundraising campaigns.', 'charitable-edd' )
            )
        );

        $fields = array_merge( $fields, $extra_fields );

        return $fields;
    }

    /**
     * Add settings to the Payment Gateways tab in Charitable settings area. 
     *
     * @param   array[] $fields
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_payment_gateway_settings( $fields ) {
        if ( ! charitable_is_settings_view( 'gateways' ) ) {
            return $fields;
        }

        unset( $fields[ 'section_gateways' ], $fields[ 'gateways' ], $fields[ 'test_mode' ] );

        $fields[ 'edd_gateway_notice' ] = array(
            'type'          => 'content',
            'content'       => sprintf( esc_html__( 'You\'re currently using Easy Digital Downloads Connect. All donations are made through the Easy Digital Downloads checkout. You can manage your payment gateways in the %1$sEasy Digital Downloads settings area%2$s.', 'charitable-edd' ),
                '<a href="' . admin_url( 'edit.php?post_type=download&page=edd-settings&tab=gateways' ) . '">', 
                '</a>' 
            ),
            'priority'      => 2
        );

        return $fields;
    }

    /**
     * Display the export box in the EDD exports tab. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function export_box() {
        charitable_edd_admin_view( 'export-box' );
    }

    /**
     * Registers the batch exporter. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function register_exporter() {        
        add_action( 'edd_batch_export_class_include', array( self::$instance, 'include_exporter' ), 10, 1 );
    } 

    /**
     * Loads the customers batch process if needed
     *
     * @param   string $class   The class being requested to run for the batch export
     * @return  void
     * @access  public
     * @since   1.0.0 
     */
    public function include_exporter( $class ) {    
        if ( 'Charitable_EDD_Batch_Export_Campaign_Payments' === $class ) {
            require_once 'class-charitable-edd-batch-export-campaign-payments.php';
        }
    }
}

endif; // End class_exists check