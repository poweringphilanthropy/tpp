<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/** 
 * Register the custom meta box. 
 */
function pp_register_meta_box() {
    add_meta_box(
        'campaign_info_meta_box',
        esc_html__( 'Campaign Info'),
        'pp_campaign_info_meta_box',
        'campaign',
        'side',
        'default'
      );

    add_meta_box(
        'campaign_impact_target_box',
        esc_html__( 'Impact Target'),
        'pp_campaign_impact_target_box'
      );

    add_meta_box(
        'campaign_volunteers_need_box',
        esc_html__( 'Volunteer\'s Need'),
        'pp_campaign_volunteers_need_box'
    );

    add_meta_box(
        'campaign_event_meta_box',
        esc_html__( 'Campaign Event'),
        'pp_campaign_event_meta_box',
        'campaign',
        'side',
        'default'
    );

}

add_action( 'add_meta_boxes', 'pp_register_meta_box' );    
// add_action( 'save_post', array( $this, 'save_post' ), 10, 2);



function my_enqueue($hook) {

    wp_enqueue_script( 'my_custom_script', plugin_dir_url( __FILE__ ) . '../assets/js/custom.js' );
}
add_action( 'admin_enqueue_scripts', 'my_enqueue' );


function pp_campaign_impact_target_box(){

    global $post;

    $campaign                   = new Charitable_Campaign( $post );
    $content             = ( get_post_meta( $campaign->ID, '_campaign_impact_goal', true ) );

		wp_editor( $content, 'impact_target_textarea', $settings = array() );
	}

function pp_campaign_volunteers_need_box(){
	
global $post;



$title 					= isset( $view_args['label'] ) 		? $view_args['label'] 	: '';

   $campaign  = charitable_get_current_campaign();
$needs 	= $campaign->volunteers;


?>

<div id="charitable-campaign-volunteers-need-metabox-wrap" class="charitable-metabox-wrap">

	<table id="charitable-campaign-volunteers-need" class="widefat">

		<thead>

			<tr>

				<th class="amount-col"><?php _e( 'Need', 'charitable' ) ?></th>

			</tr>

		</thead>		

		<tbody>

			<?php 

			if ( $needs ) : 



				foreach ( $needs as $i => $need ) : 




					$description = is_array( $need ) ? $need[ 'need' ] : ''; 

					

					?>

					<tr data-index="<?php echo $i ?>" class="volunteers-need repeatable-field">

						<td class="amount-col"><input 

							type="text" 

							id="campaign_volunteers_<?php echo $i ?>" 

							name="volunteers[<?php echo $i ?>][need]" 

							value="<?php echo $description; ?>" 

							placeholder="<?php _e( 'Need', 'charitable' ) ?>" 
                            
                            style="width:100%"/>

						</td>

					</tr>

					<?php 



				endforeach;



			else : 



			?>

			<tr class="no-suggested-amounts">

				<td colspan="2"><?php _e( 'No Need for volunteers.', 'charitable' ) ?></td>

			</tr>

			<?php 



			endif;



			?>

		</tbody>

		<tfoot>

			<tr>

				<td colspan="2"><a id="add-row" class="button" href="#" data-charitable-add-row="volunteers-admin"><?php _e( 'Add Need', 'charitable' ) ?></a></td>

			</tr>

		</tfoot>

	</table>	

</div> 
<?php
	}


/**
 * The meta box output.
 */
function pp_campaign_info_meta_box() {
    global $post;

    $campaign                   = new Charitable_Campaign( $post );
    $philanthrophy_challange    = ( get_post_meta( $campaign->ID, '_campaign_philanthropy_challenge', true ) );
    $group_campaign             = ( get_post_meta( $campaign->ID, '_campaign_group_campaign', true ) );
    ?>
    <p>
        <label for="campaign-philanthropy-challenge">
            <input type="checkbox" id="campaign-philanthropy-challenge" name="_campaign_philanthropy_challenge" <?php if ( '1' ==  $philanthrophy_challange ) { echo 'checked'; } ?> disabled="disabled" />30 day Philanthropy Challenge
        </label>
    </p>
    <p>
        <label for="campaign-group-campaign">
            <input type="checkbox" id="campaign-group-campaign" name="_campaign_group_campaign" <?php if ( '1' ==  $group_campaign ) { echo 'checked'; } ?> disabled="disabled" />Group campaign?
        </label>
    </p>
    <?php 
}

/**
 * The event meta box.
 */
function pp_campaign_event_meta_box() {
    global $post;

    $events = get_post_meta( $post->ID, '_campaign_events', true );

    if ( ! is_array( $events ) || empty( $events ) ) {
        printf( '<p>%s</p>', __( 'There are no campaigns events.', 'pp-toolkit' ) ); 
    }
    ?>
    <ul>
    <?php foreach ( $events as $event_id ) : ?>

        <li><a href="<?php echo get_the_permalink( $event_id ) ?>"><?php echo get_the_title( $event_id ) ?></a></li>

    <?php endforeach ?>
    </ul>
    <?php
}


    /**
    * Save meta for the campaign. 
     * 
     * @param   int         $post_id    Post ID.
     * @param   WP_Post     $post       Post object.
     * @return  void
     * @access  public 
     * @since   1.0.0
     */

  function save_post( $post_id, WP_Post $post ) {

        if ( $this->meta_box_helper->user_can_save( $post ) ) {

                    

            $meta_keys = apply_filters( 'charitable_campaign_meta_keys', array(

                '_campaign_impact_goal', 

                'volunteers', 



            ) );            



            $submitted = $_POST;



            foreach ( $meta_keys as $key ) {



                $value = isset( $submitted[ $key ] ) ? $submitted[ $key ] : false;



                $value = apply_filters( 'charitable_sanitize_campaign_meta', $value, $key, $submitted );



                update_post_meta( $post_id, $key, $value );



            }



            /* Hook for plugins to do something else with the posted data */

            do_action( 'charitable_campaign_save', $post );

        }

    }   

