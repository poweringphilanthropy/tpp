<?php
/**
 * Core plugin class. 
 *
 * @package     Philanthropy Project/Classes/Philanthropy_Project
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Philanthropy_Project' ) ) : 

/**
 * Philanthropy_Project
 *
 * @since       1.0.0
 */
class Philanthropy_Project {

    /**
     * @var string
     */
    const VERSION = '1.0.9';

    /**
     * @var string  A date in the format: YYYYMMDD
     */
    const DB_VERSION = '20150423';  

    /**
     * @var Philanthropy_Project
     */
    private static $instance = null;

    /**
     * The root file of the plugin. 
     * 
     * @var     string
     * @access  private
     */
    private $plugin_file; 

    /**
     * The root directory of the plugin.  
     *
     * @var     string
     * @access  private
     */
    private $directory_path;

    /**
     * The root directory of the plugin as a URL.  
     *
     * @var     string
     * @access  private
     */
    private $directory_url;

    /**
     * Create class instance. 
     * 
     * @return  void
     * @since   1.0.0
     */
    public function __construct( $plugin_file ) {        
        $this->plugin_file      = $plugin_file;
        $this->directory_path   = plugin_dir_path( $plugin_file );
        $this->directory_url    = plugin_dir_url( $plugin_file );
        
        add_action( 'charitable_start', array( $this, 'start' ), 10 );
    }

    /**
     * Returns the original instance of this class. 
     * 
     * @return  Charitable
     * @since   1.0.0
     */
    public static function get_instance() {
        return self::$instance;
    }

    /**
     * Start the plugin functionality. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function start() {

        /* If we've already started (i.e. run this function once before), do not pass go. */
        if ( $this->started() ) {
            return;
        }

        /* Set static instance */
        self::$instance = $this;

        $this->load_dependencies();

        $this->attach_hooks_and_filters();

        /* Hook in here to do something when the plugin is first loaded */
        do_action('philanthropy_project_start', $this);
    }

    /**
     * Include necessary files.
     * 
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function load_dependencies() {
        require_once( $this->get_path( 'includes' ) . 'class-pp-charitable-campaign-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-merchandise-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-event-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-ticket-form.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-template.php' );
        require_once( $this->get_path( 'includes' ) . 'class-pp-widget-campaign-events.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-core-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-atcf-migration-functions.php' );        
        require_once( $this->get_path( 'includes' ) . 'pp-edd-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-charitable-form-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-admin-metaboxes-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-shortcode-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-tribe-events-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-donor-photo-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-account-functions.php' );
        require_once( $this->get_path( 'includes' ) . 'pp-template-functions.php' );
    }

    /**
     * Set up hook and filter callback functions.
     * 
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function attach_hooks_and_filters() {
        /* Action Hooks */       
        add_action( 'philanthropy_project_start', array( 'PP_Charitable_Campaign_Form', 'start' ) );
        add_action( 'charitable_campaign_submission_save', array( 'PP_Merchandise_Form', 'save_merchandise' ), 10, 3 );
        add_action( 'charitable_campaign_submission_save', array( 'PP_Event_Form', 'save_event' ), 10, 3 );
        add_action( 'widgets_init', array( $this, 'register_widget' ) );
        add_action( 'init', array( $this, 'maybe_download_event_attendees_list' ) );
        add_action( 'edd_payment_receipt_after_table', array( $this, 'merchandise_and_events_tables_receipt' ) );
        // add_action( 'charitable_edd_donation_form', array( $this, 'override_downloads_template' ) );
        // add_action( 'charitable_edd_donation_form_downloads', array( $this, 'select_downloads_template' ) );

        add_action( 'charitable_user_event_summary_before', 'pp_charitable_my_tribe_events_render_event_thumbnail', 10, 2 );
        add_action( 'charitable_user_event_summary', 'pp_charitable_my_tribe_events_render_event_summary', 10, 2 );
        add_action( 'charitable_user_event_summary_after', 'pp_charitable_my_tribe_events_render_event_actions', 10, 2 );       
        add_action( 'charitable_user_product_summary_before', 'pp_charitable_my_edd_products_render_product_thumbnail', 10, 2 );
        add_action( 'charitable_user_product_summary', 'pp_charitable_my_edd_products_render_product_summary', 10, 2 );
        add_action( 'charitable_user_product_summary_after', 'pp_charitable_my_edd_products_render_product_actions', 10, 2 );     
        
        /* Impact target field */
        add_action( 'charitable_campaign_summary_after', 'reach_template_campaign_impact', 8 );
                  
        /* Filters */
        add_filter( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_filter( 'charitable_is_page_registration_page', array( $this, 'is_registration_page' ) );
        add_filter( 'charitable_donors_widget_donor_query_args', array( $this, 'filter_donors_widget_query_args' ) );
        
        /* Shortcodes */
        add_shortcode( 'pp_edd_product_form', 'pp_edd_product_form_shortcode' );
        add_shortcode( 'charitable_my_edd_products', 'pp_charitable_my_edd_products_shortcode' );
        add_shortcode( 'charitable_my_tribe_events', 'pp_charitable_my_tribe_events_shortcode' );

        /* Undo hooks */
        if ( function_exists( 'charitable_edd' ) ) {
            remove_action( 'edd_checkout_table_footer_last', array( charitable_edd()->get_object( 'Charitable_EDD_Checkout' ), 'donation_amount_notice_checkout' ) );
            remove_action( 'edd_payment_receipt_after_table',  array( charitable_edd()->get_object( 'Charitable_EDD_Payment' ), 'products_table_receipt' ) );
        }        
    }

    /**
     * Returns whether we are currently in the start phase of the plugin. 
     *
     * @return  bool
     * @access  public
     * @since   1.0.0
     */
    public function is_start() {
        return current_filter() == 'philanthropy_project_start';
    }

    /**
     * Returns whether the plugin has already started.
     * 
     * @return  bool
     * @access  public
     * @since   1.0.0
     */
    public function started() {
        return did_action( 'philanthropy_project_start' ) || current_filter() == 'philanthropy_project_start';
    }

    /**
     * Returns the plugin's version number. 
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_version() {
        return self::VERSION;
    }

    /**
     * Returns plugin paths. 
     *
     * @param   string $path            // If empty, returns the path to the plugin.
     * @param   bool $absolute_path     // If true, returns the file system path. If false, returns it as a URL.
     * @return  string
     * @since   1.0.0
     */
    public function get_path($type = '', $absolute_path = true ) {      
        $base = $absolute_path ? $this->directory_path : $this->directory_url;

        switch( $type ) {
            case 'includes' : 
                $path = $base . 'includes/';
                break;

            case 'admin' :
                $path = $base . 'includes/admin/';
                break;

            case 'templates' : 
                $path = $base . 'templates/';
                break;

            case 'assets' : 
                $path = $base . 'assets/';
                break;              

            case 'directory' : 
                $path = $base;
                break;

            default :
                $path = $this->plugin_file;
        }

        return $path;
    }

    /**
     * Download event attendees.  
     *
     * @return  boolean 
     * @access  public
     * @since   1.0.0
     */
    public function maybe_download_event_attendees_list() {        
        if ( ! isset( $_GET[ 'download_attendees' ] ) ) {
            return false;
        }

        if ( ! isset( $_GET[ 'event_id' ] ) ) {
            return false;
        }

        $event_id = $_GET[ 'event_id' ];
       
        return pp_download_event_attendees( $event_id );
    }

    /**
     * Load our custom merchandise and events tables on the payment receipt page. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function merchandise_and_events_tables_receipt() {
        new PP_Toolkit_Template( 'payment-receipt/products.php' );
    }

    /**
     * Use our own custom template to display the download selections. 
     *
     * @param   Charitable_EDD_Donation_Form $form
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function override_downloads_template( Charitable_EDD_Donation_Form $form ) {
        remove_action( 'charitable_edd_donation_form_before_downloads', array( $form, 'enter_downloads_section_header' ) );
        remove_action( 'charitable_edd_donation_form_downloads', array( $form, 'select_downloads' ) );        
    }

    /**
     * Display our downloads selection template. 
     *
     * @param   Charitable_EDD_Donation_Form $form
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function select_downloads_template( Charitable_EDD_Donation_Form $form ) {
        $template = new PP_Toolkit_Template( 'donation-form/select-downloads.php', false );
        $template->set_view_args( $form->get_view_args() );
        $template->render();
    }

    /**
     * Register the Campaign Events widget.
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function register_widget() {
        register_widget( 'PP_Widget_Campaign_Events' );
    }


    /**
     * Load custom scripts.  
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function enqueue_scripts() {
        if ( charitable_is_page( 'registration_page' ) ) {
            wp_register_script( 'pp-registration-handler', $this->get_path( 'assets', false ) . 'js/registration-handler.js', array( 'jquery-ui-datepicker' ), '1.0.0', true );
            wp_enqueue_script( 'pp-registration-handler' );
        }

        /* This script is registered here, but enqueued by the form class to ensure that it's only loaded when we're looking at the form. */
        wp_register_script( 'pp-product-submission', $this->get_path( 'assets', false ) . 'js/product-submission.js', array( 'jquery-ui-datepicker', 'jquery' ), '1.0.0', true );
        $localized_vars = array(
            'price_name_label'      => __( 'Name', 'pp-toolkit' ),
            'price_amount_label'    => __( 'Price', 'pp-toolkit' ),
            'volunteers_need_label'    => __( 'Task Description', 'pp-toolkit' )
        );
        wp_localize_script( 'pp-product-submission', 'PP_PRODUCT_SUBMISSION', $localized_vars );        

        wp_register_style( 'pp-product-submission-css', $this->get_path( 'assets', false ) . 'css/product-submission.css' );
        wp_register_style( 'pp-custom-css', $this->get_path( 'assets', false ) . 'css/custom.css' );
        wp_enqueue_style( 'pp-custom-css' );


        if ( charitable_is_page( 'campaign_submission_page' ) ) {
            wp_enqueue_script( 'pp-product-submission' );
            wp_enqueue_style( 'pp-product-submission-css' );
            
        }
    }


    /**
     * Checks whether the current request is for the campaign editing page. 
     *
     * This is used when you call charitable_is_page( 'registration_page' ). 
     * In general, you should use charitable_is_page() instead since it will
     * take into account any filtering by plugins/themes.
     *
     * @see     charitable_is_page
     * @return  boolean
     * @since   1.0.0
     */
    public function is_registration_page( $r= false ) {
        return charitable_is_page( 'login_page' );
    }

    /**
     * Fetch all donors for a donation, including duplicate donations. 
     *
     * @param   mixed[] $args
     * @return  mixed[]
     * @access  public
     * @since   1.0.0
     */
    public function filter_donors_widget_query_args( $args ) {
        $args[ 'distinct' ] = false;
        return $args;
    }    
}

endif; // End class_exists check


// Creating the widget 
class wpb_widget extends WP_Widget {

function __construct() {
parent::__construct(
// Base ID of your widget
'wpb_widget', 

// Widget name will appear in UI
__('Volunteer\'s Need', 'wpb_widget_domain'), 

// Widget description
array( 'description' => __( 'to view Volunteer\'s Needs', 'wpb_widget_domain' ), ) 
);
}

// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
    $campaign = charitable_get_current_campaign();
    $needs=$campaign->volunteers;
    if($needs==NULL){
        return false;
        }
    else{   
    
$title = apply_filters( 'widget_title', $instance['title'] );
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

            ?>
<section id="block-iobyproject-ioby-project-volunteer" class="block block-iobyproject">
    <p>Please consider signing up to help with any of the following projects: </p>
    <?php
        
        foreach($needs as $i=> $need){  
    
     ?>
<div class="content" style="font-style:normal;font-size:13px;padding-top:10px;">
    <p><?php echo $need['need']; ?></p>
</div> <!-- /.content -->
<?php } ?>

<div class="">
<?php if($need!=''){ ?>
<div class="charitable-form-field charitable-submit-field">
        <input class="button button-primary btnVolunteer" id="btn" type="button" name="Volunteer" value="Volunteer">
    </div>
<?php } ?>
</div>
</section>
<div class="overlay" id="lean_overlay" style="display: none; opacity: 0.5;"></div>
<div id="target" style="display: none; position: fixed; opacity: 1; z-index: 100000; left: 50%; margin-left: -234px; top: 30px;" class="modal target">
    <a id="hide" class="modal-close hide"></a>
  
        <?php echo do_shortcode('[contact-form-7 id="3836" title="Contact"]'); ?>
</div>
<script type="text/javascript">
var button = document.getElementById('btn'); 
var hide = document.getElementById('hide');
var overlay = document.getElementById('lean_overlay');

document.getElementById('youremail').value='<?php echo get_the_author_meta( 'user_email', $campaign->post_author ); ?>';
document.getElementById('campaign_title').value='<?php echo get_the_title(); ?>';
document.getElementById('campaign_url').value='<?php echo get_post_permalink(); ?>';

button.onclick = hide.onclick = function() {
    var div = document.getElementById('target');
    if (div.style.display !== 'none') {
        div.style.display = 'none';
    }
    else {
        div.style.display = 'block';
    }
    overlay.style.display = 'block'
};
 hide.onclick = overlay.onclick = function() {
    var div = document.getElementById('target');
        div.style.display = 'none';
        overlay.style.display = 'none'
};

document.getElementById('needs').innerHTML = '<?php foreach($needs as $i=> $need){?><span class="wpcf7-list-item first"><label><input type="checkbox" name="needs[]" value="<?php echo $need['need'];?>">&nbsp;<span class="wpcf7-list-item-label"><?php echo $need['need'];?></span></label></span><?php } ?>';
</script>
            <?php



echo $args['after_widget'];
    }
}

    
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
function form( $instance ) {
//Set up some default widget settings.
$defaults = array( 'title' => __('VOLUNTEERS & COLLABORATORS', 'example') );
$instance = wp_parse_args( (array) $instance, $defaults );
?> 
<p>
    <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'example'); ?></label>
    <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
</p>    
<?php
    } 

} // Class wpb_widget ends here

// Register and load the widget
function wpb_load_widget() {
    register_widget( 'wpb_widget' );
}
add_action( 'widgets_init', 'wpb_load_widget' );






        

// Creating the widget 
class wpb_fp_widget extends WP_Widget {

function __construct() {
parent::__construct(
// Base ID of your widget
'wpb_fp_widget', 

// Widget name will appear in UI
__('Follow Up question', 'wpb_widget_domain'), 

// Widget description
array( 'description' => __( 'to view follow up questions', 'wpb_widget_domain' ), ) 
);
}

// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
    $url = site_url().$_SERVER['REQUEST_URI'];
    $campaign = charitable_get_current_campaign();
    $subs = Ninja_Forms()->subs()->get( array('form_id'   => 11, 'user_id'   => get_the_author_meta( 'ID' )) );
if($subs==NULL){
    return false;
}
else{
$title = apply_filters( 'widget_title', $instance['title'] );
// before and after widget arguments are defined by themes

echo $args['before_widget'];
if ( ! empty( $title ) )
echo "<div class='title-wrapper'><h3 class='widget-title'>" . $title . "</h3></div>";
        
    echo '<div class="title-wrapper"><h2 class="block-title">Campaign Reflections</h2></div>';

    $num = array(
    17 => 'First Name',
    18 => 'Last Name',
    19 => 'Email Address',
    20 => 'Campaign URL',
    24 => 'What was a highlight of this experience for you?',
    25 => 'What was a significant moment for you during this experience, and what about that moment matters?',
    26 => 'What will you remember about this experience 5 years from now?',
    27 => 'What did you learn from this experience?',
    28 => 'What did you accomplish?',
    29 => 'What\'s next for you in the world of philanthropy?',
    58 => 'Did you incur any campaign-related costs for which you require reimbursement? If so, please describe each expense in detail:',
    59 => 'If you raised money for your own cause (and not a registered 501(c)3 organization during your campaign), please describe in detail proof that the money raised during your campaign (or the goods or services purchased with this money) was actually delivered to the designated beneficiary upon completion of your campaign:',
    32 => 'Rating',
    30 => 'Please tell us about your experience running a campaign on The Philanthropy Project: Which features or aspects of the platform were most helpful? Is there anything we can improve?',
    33 => ' Is there anything else you\'d like to share with us about this experience?',
    61 => 'documentation (receipts, emails, etc) for each campaign-related expense for which you require reimbursement:',
    60 => 'Please upload any pictures or videos that illustrate your experience with running this campaign:',
    72  => 'What surprised you during your campaign?',
    73  => 'Upload a photo that expresses something meaningful about this experience (caption optional):',
    75  =>  'What would be your theme song from this experience? If you write an original song, provide a link to a recording or video!',
    76  => 'What question do you wish someone would ask you about this experience?'
    );
    
global $wpdb;
$table_name = $wpdb->prefix . "options";
$retrieve_data = $wpdb->get_results( "SELECT option_value FROM $table_name where option_name='siteurl'" );
$site_url =  $retrieve_data[0]->option_value;

$subs = Ninja_Forms()->subs()->get( array('form_id'   => 11, 'user_id'   => get_the_author_meta( 'ID' )) );
foreach($subs as $i => $key){
    $url = site_url().$_SERVER['REQUEST_URI'];
    $url2 = $key->fields[20];

    if (strpos($url2,'staging3.') !== false) {
    $url2 = str_replace('staging3.','',$url2);
}
    
    
    
    if ($url == $url2 )
    {
    if(count($key->fields[60])!=''){        
        echo '<p class="qus">'.$num[60].'</p>';
        
        
       foreach($key->fields[60] as $media){
		$filename = $media['user_file_name'];   
	    $image_extensions_allowed = array('jpg', 'jpeg', 'png', 'gif','bmp');
        $video_extensions_allowed = array("webm", "mp4", "ogv" , "3gp");
        $file_parts = pathinfo($filename);
            if(in_array($file_parts['extension'],$image_extensions_allowed)){
                echo '<a href="'.$media['file_url'].'"><img src="'.site_url()."/wp-content/plugins/philanthropy-project-toolkit/assets/timthumb.php?src=".$media['file_url'].'&h=100&w=100"></a>';
                }
            if(in_array($file_parts['extension'],$video_extensions_allowed)){
                echo '<video width="400" controls>
  <source src="'.$media['file_url'].'" type="'.$file_parts['extension'].'">
  Your browser does not support HTML5 video.
</video>
';
                }               
        echo '<br><br>';

		   }
    }


    if($key->fields[24]!=''){       
        echo '<p class="qus">'.$num[24].'</p>';
        echo '<p class="ans">'.$key->fields[24].'</p><br>';
    }
        
    if($key->fields[25]!=''){       
        echo '<p class="qus">'.$num[25].'</p>';
        echo '<p class="ans">'.$key->fields[25].'</p><br>';}

    if($key->fields[72]!=''){       
        echo '<p class="qus">'.$num[72].'</p>';
        echo '<p class="ans">'.$key->fields[72].'</p><br>';}

    if($key->fields[73]!=''){       
        echo '<p class="qus">'.$num[73].'</p>';
        foreach($key->fields[73] as $media ){

        $filename = $media['user_file_name'];
        $image_extensions_allowed = array('jpg', 'jpeg', 'png', 'gif','bmp');
        $file_parts = pathinfo($filename);
            if(in_array($file_parts['extension'],$image_extensions_allowed)){
                echo '<a href="'.$media['file_url'].'"><img src="'.site_url()."/wp-content/plugins/philanthropy-project-toolkit/assets/timthumb.php?src=".$media['file_url'].'&h=100&w=100"></a>';
                }
            
        echo '<br><br>';			
			}

    }
        
    if($key->fields[75]!=''){       
        echo '<p class="qus">'.$num[75].'</p>';
        echo '<p class="ans">'.$key->fields[75].'</p><br>';}
        
    if($key->fields[26]!=''){       
        echo '<p class="qus">'.$num[26].'</p>';
        echo '<p class="ans">'.$key->fields[26].'</p><br>';}
        
    if($key->fields[27]!=''){       
        echo '<p class="qus">'.$num[27].'</p>';
        echo '<p class="ans">'.$key->fields[27].'</p><br>';}
        
    if($key->fields[28]!=''){       
        echo '<p class="qus">'.$num[28].'</p>';
        echo '<p class="ans">'.$key->fields[28].'</p><br>';}
        
    if($key->fields[76]!=''){       
        echo '<p class="qus">'.$num[76].'</p>';
        echo '<p class="ans">'.$key->fields[76].'</p><br>';}
        
    if($key->fields[29]!=''){       
        echo '<p class="qus">'.$num[29].'</p>';
        echo '<p class="ans">'.$key->fields[29].'</p><br>';}
    }
    
echo '<div></div>';
echo $args['after_widget'];
}
}
}

    
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
} // Class wpb_widget ends here

// Register and load the widget
function wpb_fp_load_widget() {
    register_widget( 'wpb_fp_widget' );
}
add_action( 'widgets_init', 'wpb_fp_load_widget' );

function reach_template_campaign_impact(Charitable_Campaign $campaign)
         {
         
         reach_template_campaign_impact_summary( $campaign );
        
         }
         
if ( ! function_exists( 'reach_template_campaign_impact_summary' ) ) : 
    /**
     * Display the campaign featured image. 
     *
     * @param   Charitable_Campaign $campaign
     * @return  void
     * @since   1.0.0
     */
    function reach_template_campaign_impact_summary( Charitable_Campaign $campaign ) {
    
    
        //charitable_template( 'campaign/featured-image.php', array( 'campaign' => $campaign ) );
        
        $campaign = charitable_get_current_campaign();

        echo '<div class="campaign-image impact-goal-field" style="overflow: visible;line-height:20px;font-size:18px;margin:0px">';
        echo '<div style="font-size:24px" class="compaign-target-head">Impact Target</div><br>';
         echo $campaign->impact_goal; echo '</div>';
    }
    endif;