<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Callback for the 'pp_edd_product_form' shortcode.
 *
 * @param   array   $atts
 * @return  string
 * @since   1.0.0
 */
function pp_edd_product_form_shortcode( $atts ) {
    $args = shortcode_atts( array(), $atts, 'pp_edd_product_form' );     

    /* If the user is logged out, redirect to login/registration page. */
    if ( ! is_user_logged_in() ) {

        $url = charitable_get_permalink( 'login_page' );
        $url = esc_url_raw( add_query_arg( array( 'redirect_to' => charitable_get_current_url() ), $url ) );

        wp_safe_redirect( $url );

        exit();
    }

    /* If the user has not created any campaigns yet, do not display the form to them. */
    $user = new Charitable_User( wp_get_current_user() );
    
    if ( ! $user->has_current_campaigns() ) {
        $template_name = 'shortcodes/product-form/no-campaigns.php';
    }
    else {
        $template_name = 'shortcodes/product-form.php';
    } 


    ob_start();

    $template = new PP_Toolkit_Template( 'shortcodes/product-form.php', false );
    $template->set_view_args( array( 
        'form' => new PP_EDD_Product_Form( $args ) 
    ) );
    $template->render();

    return apply_filters( 'pp_edd_product_form_shortcode', ob_get_clean() );        
}

/**
 * Callback for the charitable_my_edd_products shortcode.
 * 
 * @param   array   $atts
 * @return  string
 * @since   1.0.0
 */
function pp_charitable_my_edd_products_shortcode( $atts ) {
    $args = shortcode_atts( array(), $atts, 'charitable_my_edd_products' );       

    /* If the user is logged out, redirect to login/registration page. */
    if ( ! is_user_logged_in() ) {

        $url = charitable_get_permalink( 'login_page' );
        $url = esc_url_raw( add_query_arg( array( 'redirect_to' => charitable_get_current_url() ), $url ) );

        wp_safe_redirect( $url );

        exit();
    } 

    ob_start();

    $template = new PP_Toolkit_Template( 'shortcodes/my-products.php', false );
    $template->set_view_args( $args );
    $template->render();

    return apply_filters( 'charitable_my_edd_products_shortcode', ob_get_clean() );
}

/**
 * Callback for the charitable_my_tribe_events shortcode.
 * 
 * @param   array   $atts
 * @return  string
 * @since   1.0.0
 */
function pp_charitable_my_tribe_events_shortcode( $atts ) {
    $args = shortcode_atts( array(), $atts, 'charitable_my_tribe_events' );       

    /* If the user is logged out, redirect to login/registration page. */
    if ( ! is_user_logged_in() ) {

        $url = charitable_get_permalink( 'login_page' );
        $url = esc_url_raw( add_query_arg( array( 'redirect_to' => charitable_get_current_url() ), $url ) );

        wp_safe_redirect( $url );

        exit();
    } 

    ob_start();

    $template = new PP_Toolkit_Template( 'shortcodes/my-events.php', false );
    $template->set_view_args( $args );
    $template->render();

    return apply_filters( 'charitable_my_tribe_events_shortcode', ob_get_clean() );
}

/**
 * Display the event thumbnail template. 
 *
 * @param   WP_Post         $event
 * @param   Charitable_User $user
 * @return  void
 * @since   1.0.0
 */
function pp_charitable_my_tribe_events_render_event_thumbnail( $event, $user ) {
    $template = new PP_Toolkit_Template( 'shortcodes/my-events/event-thumbnail.php', false );
    $template->set_view_args( array( 
        'event' => $event, 
        'user' => $user 
    ) );
    $template->render();
}

/**
 * Display the event summary template. 
 *
 * @param   WP_Post         $event
 * @param   Charitable_User $user
 * @return  void
 * @since   1.0.0
 */
function pp_charitable_my_tribe_events_render_event_summary( $event, $user ) {
    $template = new PP_Toolkit_Template( 'shortcodes/my-events/event-summary.php', false );
    $template->set_view_args( array( 
        'event' => $event, 
        'user' => $user 
    ) );
    $template->render();
}

/**
 * Display the event actions template. 
 *
 * @param   WP_Post             $event
 * @param   Charitable_User     $user
 * @return  void
 * @since   1.0.0
 */
function pp_charitable_my_tribe_events_render_event_actions( $event, $user ) {
    $template = new PP_Toolkit_Template( 'shortcodes/my-events/event-actions.php', false );
    $template->set_view_args( array( 
        'event' => $event, 
        'user' => $user 
    ) );
    $template->render();
}

/**
 * Display the product thumbnail template. 
 *
 * @param   WP_Post         $product
 * @param   Charitable_User $user
 * @return  void
 * @since   1.0.0
 */
function pp_charitable_my_edd_products_render_product_thumbnail( $product, $user ) {
    $template = new PP_Toolkit_Template( 'shortcodes/my-products/product-thumbnail.php', false );
    $template->set_view_args( array( 
        'product' => $product, 
        'user' => $user 
    ) );
    $template->render();
}

/**
 * Display the product summary template. 
 *
 * @param   WP_Post         $product
 * @param   Charitable_User $user
 * @return  void
 * @since   1.0.0
 */
function pp_charitable_my_edd_products_render_product_summary( $product, $user ) {
    $template = new PP_Toolkit_Template( 'shortcodes/my-products/product-summary.php', false );
    $template->set_view_args( array( 
        'product' => $product, 
        'user' => $user 
    ) );
    $template->render();
}

/**
 * Display the product actions template. 
 *
 * @param   WP_Post             $product
 * @param   Charitable_User     $user
 * @return  void
 * @since   1.0.0
 */
function pp_charitable_my_edd_products_render_product_actions( $product, $user ) {
    $template = new PP_Toolkit_Template( 'shortcodes/my-products/product-actions.php', false );
    $template->set_view_args( array( 
        'product' => $product, 
        'user' => $user 
    ) );
    $template->render();
}