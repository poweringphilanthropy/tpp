<?php
/**
 * Class that is responsible for augmenting the main Charitable Campaign Form with additional fields.
 *
 * @package     Philanthropy Project/Classes/PP_Charitable_Campaign_Form
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'PP_Charitable_Campaign_Form' ) ) : 

/**
 * PP_Charitable_Campaign_Form
 *
 * @since       1.0.0
 */
class PP_Charitable_Campaign_Form {

    /**
     * The one and only way to create an object instance. 
     *
     * @param   Philanthropy_Project        $pp
     * @return  PP_Charitable_Campaign_Form
     * @access  public
     * @static
     * @since   1.0.0
     */
	 
    public static function start( Philanthropy_Project $pp ) {
        if ( ! $pp->is_start() ) {
            return;
        }

        charitable()->register_object( new PP_Charitable_Campaign_Form() );
    }

    /**
     * Private constructor.
     * 
     * @access  protected
     * @since   1.0.0
     */
    protected function __construct() {    
        $this->attach_hooks_and_filters();          
    }

    /**
     * Set up callback methods for actions & filters. 
     *
     * @return  void
     * @access  protected
     * @since   1.0.0
     */
    protected function attach_hooks_and_filters() {
        add_action( 'wp_ajax_add_merchandise_form', array( $this, 'render_merchandise_form' ) );
        add_action( 'wp_ajax_add_event_form', array( $this, 'render_event_form' ) );
        add_action( 'wp_ajax_add_ticket_form', array( $this, 'render_ticket_form' ) );
        add_filter( 'charitable_campaign_submission_campaign_fields', array( $this, 'customise_campaign_fields' ), 10, 2 );
        add_filter( 'charitable_campaign_submission_user_fields', array( $this, 'customise_user_fields' ), 10, 2 );
        // add_filter( 'charitable_campaign_submission_payment_fields', array( $this, 'customise_payment_fields' ), 10, 2 );
        add_filter( 'charitable_campaign_submission_fields', array( $this, 'addon_section' ), 10, 3 );
        add_filter( 'charitable_campaign_submission_core_data', array( $this, 'campaign_core_date' ), 10, 3 );    
		    
    }

    /**
     * Return the current user's Charitable_User object.  
     *
     * @return  Charitable_User
     * @access  public
     * @since   1.0.0
     */
    public function get_user() {
        if ( ! isset( $this->user ) ) {
            $this->user = new Charitable_User( wp_get_current_user() );
        }

        return $this->user;
    }

    /**
     * Return the current campaign's Charitable_Campaign object.  
     *
     * @return  Charitable_Campaign|false
     * @access  public
     * @since   1.0.0
     */
    public function get_campaign() {    
        if ( ! isset( $this->campaign ) ) {
            $campaign_id = get_query_var( 'campaign_id', false );
            $this->campaign = $campaign_id ? new Charitable_Campaign( $campaign_id ) : false;
        }

        return $this->campaign;
    }

    /**
     * Return any products that have been created that are linked to this campaign as "benefactors". 
     *
     * @return  array       Empty array if no merchandise. 
     * @access  public
     * @since   1.0.0
     */
    public function get_merchandise() {
        if ( isset( $_POST[ 'merchandise' ] ) ) {
            $merchandise = array();

            foreach ( $_POST[ 'merchandise' ] as $submitted ) {
                $merchandise[] = array( 'POST' => $submitted );
            } 
            
            return $merchandise;
        }

        if ( false === $this->get_campaign() ) {
            return array();
        }        

        $merchandise = array();        

        $downloads = charitable()->get_db_table( 'edd_benefactors' )->get_single_download_campaign_benefactors( $this->get_campaign()->ID );
        $download_ids = wp_list_pluck( $downloads, 'edd_download_id' );        

        foreach ( $download_ids as $key => $download_id ) {
            if ( has_term( 'Merchandise', 'download_category', $download_id ) ) {
                $merchandise[ $download_id ] = $downloads[ $key ];
            }
        }

        return $merchandise;
    }

    /**
     * Return any events that have been created that are linked to this campaign. 
     *
     * @return  array       Empty array if no events. 
     * @access  public
     * @since   1.0.0
     */
    public function get_events() {
        if ( isset( $_POST[ 'event' ] ) ) {
            $events = array();

            foreach ( $_POST[ 'event' ] as $submitted ) {
                $events[] = array( 'POST' => $submitted );
            } 
            
            return $events;
        }

        if ( false === $this->get_campaign() ) {
            return array();
        }        

        $events = get_post_meta( $this->get_campaign()->ID, '_campaign_events', true );

        if ( ! is_array ( $events ) ) {
            $events = array( $events );
        }
        
        return $events;
    }

    /**
     * Return the value for a particular field. 
     *
     * @param   string  $key
     * @return  mixed
     * @access  public
     * @since   1.0.0
     */
    public function get_field_value( $key ) {
        if ( isset( $_POST[ $key ] ) ) {
            return $_POST[ $key ];    
        }

        $value = "";

        switch ( $key ) {
            case 'post_date' : 
                if ( $this->get_campaign() ) {
                    $value = date( 'm/d/Y', strtotime( $this->get_campaign()->post_date ) );
                }
                break;  

            case 'end_date' : 
                if ( $this->get_campaign() ) {
                    $value = date( 'm/d/Y', strtotime( $this->get_campaign()->get( 'end_date' ) ) );
                }
                break;
			
			 case 'impact_goal' : 
                if ( $this->get_campaign() ) {
                    $value = $this->get_campaign()->get( 'impact_goal' );
                }
                break;

			 case 'volunteers' : 
                if ( $this->get_campaign() ) {
                    $value = $this->get_campaign()->get( 'volunteers' );
                }
                break;
				
        }

        return $value;
    }

    /**
     * Returns the array of fields that are displayed at first (not the form fields).
     *
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function get_parent_fields() {
        $fields = apply_filters( 'pp_product_submission_parent_fields', array(
            'explanation' => array(                
                'type'          => 'paragraph',
                'content'       => __( 'On the Philanthropy Project, you can also sell <strong>merchandise</strong> and <strong>event tickets</strong> to raise money for your campaign goal.', 'pp-toolkit' ),
                'priority'      => 52
            ),
            'merchandise' => array(
                'type'          => 'merchandise',
                'priority'      => 54, 
                'value'         => $this->get_merchandise()
            ), 
            'event' => array(
                'type'          => 'event',  
                'priority'      => 56, 
                'value'         => $this->get_events()
            ),
		
        ), $this );
    
        uasort( $fields, 'charitable_priority_sort' );

        return $fields;
    }

    /**
     * Add custom fields to the campaign form and customise some of the existing ones.
     *
     * @param   array[]     $fields
     * @param   Charitable_FES_Campaign_Form    $form
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function customise_campaign_fields( $fields, $form ) {
        unset( $fields[ 'length' ] );

        $fields[ 'goal' ][ 'required' ] = true;
        $fields[ 'goal' ][ 'fullwidth' ] = true;
        $fields[ 'image' ][ 'required' ] = true;
        $fields[ 'video' ][ 'label' ] = __( 'Featured Video', 'pp-toolkit' );
		$fields['campaign_category'][ 'fullwidth' ] = true;

		
		$fields[ 'impact_goal' ] = array(
            'label'         => __( 'Impact Target', 'pp-toolkit' ), 
            'type'          => 'textarea',
            'priority'      => 8, 
            'required'      => true,             
            'value'         => $this->get_field_value( 'impact_goal' ), 
            'data_type'     => 'meta',
            'editable'      => true,
			'fullwidth'		=> true,
			'placeholder'	=>'For Example: # of lives your campaign will touch, # of volunteer hours associated with your campaign, # of items collected and donated as part of your campaign, or amount of awareness raised during your campaign.'
        );

        $fields[ 'post_date' ] = array(
            'label'         => __( 'Start Date', 'pp-toolkit' ), 
            'type'          => 'datepicker',
            'priority'      => 9, 
            'required'      => true, 
            'value'         => $this->get_field_value( 'post_date' ), 
            'data_type'     => 'meta',
            'editable'      => false            
        );

        $fields[ 'end_date' ] = array(
            'label'         => __( 'End Date', 'pp-toolkit' ), 
            'type'          => 'datepicker',
            'priority'      => 9.2, 
            'required'      => true,             
            'value'         => $this->get_field_value( 'end_date' ), 
            'data_type'     => 'meta',
            'editable'      => false
        );

       return $fields;
    }

    /**
     * Customises the user fields. 
     *
     * @param   array[]     $fields
     * @param   Charitable_FES_Campaign_Form    $form
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function customise_user_fields( $fields, $form ) {
        $fields[ 'organisation' ][ 'label' ] = __( 'Organization', 'pp-toolkit' );
        return $fields;
    }

    /**
     * Add custom fields to the payment form.
     *
     * @param   array[]     $fields
     * @param   Charitable_FES_Campaign_Form    $form
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function customise_payment_fields( $fields, $form ) {
        $fields = array(
            'funds_recipient' => array(
                'label'         => __( 'Will proceeds be distributed to an existing Non-Profit or directly to the Campaign Creator for further distribution (proceeds must be for a charitable, education or scientific purpose)?', 'pp-toolkit' ),
                'type'          => 'select',
                'options'       => array(
                    'non-profit'    => __( 'Existing Non-Profit', 'pp-toolkit' ),
                    'direct'        => __( 'Directly to Campaign Creator', 'pp-toolkit' )
                ), 
                'required'      => false, 
                'priority'      => 2, 
                'fullwidth'     => true,
                'default'       => 'non-profit', 
                'value'         => $form->get_campaign_value( 'funds_recipient' ), 
                'data_type'     => 'meta'
            ),
            'recipient_organization' => array(
                'label'         => __( 'Enter the name of the non-profit organization', 'pp-toolkit' ), 
                'type'          => 'text',
                'required'      => false,
                'priority'      => 4,
                'fullwidth'     => true,
                'class'         => 'toggle-non-profit',
                'value'         => $form->get_campaign_value( 'recipient_organization' ),
                'data_type'     => 'meta'
            ),
            'recipient_name' => array(
                'label'         => __( 'Recipient Name', 'pp-toolkit' ),
                'type'          => 'text',
                'required'      => false,
                'priority'      => 6,
                'class'         => 'toggle-direct',
                'value'         => $form->get_campaign_value( 'recipient_name' ),
                'data_type'     => 'meta'
            ),
            'recipient_paypal' => array(
                'label'         => __( 'Recipient PayPal Address', 'pp-toolkit' ),
                'type'          => 'email',
                'required'      => false,
                'priority'      => 8,
                'class'         => 'toggle-direct',
                'value'         => $form->get_campaign_value( 'recipient_paypal' ),
                'data_type'     => 'meta'
            ),
            'recipient_address' => array(
                'label'         => __( 'Recipient Address', 'pp-toolkit' ),
                'type'          => 'textarea',
                'required'      => false,
                'fullwidth'     => true,
                'priority'      => 10,
                'class'         => 'toggle-direct',
                'value'         => $form->get_campaign_value( 'recipient_address' ),
                'data_type'     => 'meta'
            ), 
            'purpose_of_regrant' => array(
                'label'         => __( 'Who will be the beneficiary of the money, goods or services made available by the regrant?', 'pp-toolkit' ), 
                'type'          => 'text',
                'required'      => false,
                'fullwidth'     => true,
                'priority'      => 12,
                'class'         => 'toggle-direct',
                'value'         => $form->get_campaign_value( 'purpose_of_regrant' ),
                'data_type'     => 'meta'
            ),
            'beneficiary_selection_manner' => array(
                'label'         => __( 'In what manner was the beneficiary selected?', 'pp-toolkit' ),
                'type'          => 'textarea',
                'required'      => false,
                'fullwidth'     => true,
                'priority'      => 14,
                'class'         => 'toggle-direct', 
                'value'         => $form->get_campaign_value( 'beneficiary_selection_manner' ),
                'data_type'     => 'meta'
            ),
            'relationship_clause' => array(
                'label'         => __( 'The campaign creator(s) and recipient of regrant do not have a relationship with the beneficiary(s).', 'pp-toolkit' ),
                'type'          => 'checkbox',
                'required'      => false,
                'editable'      => true,
                'priority'      => 16, 
                'class'         => 'toggle-direct',
                'fullwidth'     => true,
                'default'       => 0,
                'checked'       => $form->get_campaign_value( 'relationship_clause' ),
                'data_type'     => 'meta'
            ),
            'purpose_clause' => array(
                'label'         => __( 'The recipient is aware that the regrant should be used exclusively for "charitable, scientific or educational purposes".', 'pp-toolkit' ),
                'type'          => 'checkbox',
                'required'      => false,
                'editable'      => true,
                'priority'      => 18, 
                'class'         => 'toggle-direct',
                'fullwidth'     => true,
                'default'       => 0,
                'checked'       => $form->get_campaign_value( 'purpose_clause' ),
                'data_type'     => 'meta'
            ),
            'documentation_clause' => array(
                'label'         => __( 'The recipient will make its best efforts to uploads supporting documentation (receipts and other information support) that verify the use of proceeds. If supporting documentation is not provided no future use of the Philanthropy Project will be available to the campaign creator / recipient.', 'pp-toolkit' ),
                'type'          => 'checkbox',
                'required'      => false,
                'editable'      => true,
                'priority'      => 20, 
                'class'         => 'toggle-direct',
                'fullwidth'     => true,
                'default'       => 0,
                'checked'       => $form->get_campaign_value( 'documentation_clause' ),
                'data_type'     => 'meta'
            )
        );

        return $fields;
    }

    /**
     * Add the EDD product and event sections to the campaign form. 
     *
     * @param   array   $sections
     * @param   Charitable_FES_Campaign_Form $form
     * @return  array
     * @access  public
     * @since   1.0.0
     */
    public function addon_section( $sections, $form ) {
        $sections[ 'merchandise_fields' ] = array(
            'legend'        => __( 'Merchandise', 'pp-toolkit' ), 
            'type'          => 'fieldset', 
            'priority'      => 50,
            'page'          => 'campaign_details',
            'fields'        => array(
                'explanation' => array(                
                    'type'          => 'paragraph',
                    'content'       => __( 'You can sell <strong>merchandise</strong> to raise money for your campaign goal.', 'pp-toolkit' ),
                    'priority'      => 32
                ),
                'merchandise' => array(
                    'type'          => 'merchandise',
                    'priority'      => 34, 
                    'value'         => $this->get_merchandise()
                )
            )            
        );

        $sections[ 'event_fields' ] = array(
            'legend'        => __( 'Events', 'pp-toolkit' ), 
            'type'          => 'fieldset',
            'priority'      => 55,
            'page'          => 'campaign_details',
            'fields'        => array(
                'explanation' => array(                
                    'type'          => 'paragraph',
                    'content'       => __( 'You can create <strong>events</strong> and sell tickets to raise money for your campaign goal.', 'pp-toolkit' ),
                    'priority'      => 42
                ),
                'event' => array(
                    'type'          => 'event',  
                    'priority'      => 44, 
                    'value'         => $this->get_events()
                )
            )            
        );
		
        $sections[ 'volunteers_need' ] = array(
            'legend'        => __( 'VOLUNTEERS & COLLABORATORS', 'pp-toolkit' ), 
            'type'          => 'fieldset',
            'priority'      => 56,
            'page'          => 'campaign_details',
            'fields'        => array(
                'explanation' => array(                
                    'type'          => 'paragraph',
                    'content'       => __( 'You can recruit and organize participants to help with specific task through out your campaign. You receive emails from interested participants.', 'pp-toolkit' ),
                    'priority'      => 50
                ),
                'volunteers' => array(
                    'type'          => 'volunteers',  
                    'priority'      => 50, 
                    'value'         => $this->get_field_value( 'volunteers' ), 
                )
            )            
        );

        return $sections;
    }
	
	

    /**
     * Filter core campaign data before saving. 
     *
     * @param   array   $values
     * @param   int     $user_id
     * @param   array   $submitted
     * @return  array
     * @access  public
     * @since   1.0.0
     */
    public function campaign_core_date( $values, $user_id, $submitted ) {
        if ( isset( $submitted[ 'post_date' ] ) ) {
            $values[ 'post_date' ] = date('Y-m-d 00:00:00', strtotime( $submitted[ 'post_date' ] ) );
            $values[ 'edit_date' ] = $values[ 'post_date' ];
            $values[ 'post_date_gmt' ] = get_gmt_from_date( $values[ 'post_date' ] );
        }

        return $values;
    }


    /**
     * Display the merchandise form. This is called by an AJAX action. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function render_merchandise_form() {
        /* Run a security check first to ensure we initiated this action. */
        check_ajax_referer( 'pp-merchandise-form', 'nonce' );

        $template = new PP_Toolkit_Template( 'form-fields/merchandise-form.php', false );
        $template->set_view_args( array(
            'form'      => new PP_Merchandise_Form(),
            'index'     => $_POST[ 'index' ]
        ) );
        $template->render();

        wp_die();
    }

    /**
     * Display the event form. This is called by an AJAX action. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function render_event_form() {
        /* Run a security check first to ensure we initiated this action. */
        check_ajax_referer( 'pp-event-form', 'nonce' );

        $template = new PP_Toolkit_Template( 'form-fields/event-form.php', false );
        $template->set_view_args( array(
            'form'      => new PP_Event_Form(),
            'index'     => $_POST[ 'index' ]
        ) );
        $template->render();

        wp_die();
    } 

    /**
     * Display the ticket form. This is called by an AJAX action. 
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function render_ticket_form() {
        /* Run a security check first to ensure we initiated this action. */
        check_ajax_referer( 'pp-ticket-form', 'nonce' );

        $template = new PP_Toolkit_Template( 'form-fields/ticket-form.php', false );
        $template->set_view_args( array(
            'form'      => new PP_Ticket_Form( $_POST[ 'namespace' ], $_POST[ 'event_id' ] ),
            'index'     => $_POST[ 'index' ]
        ) );
        $template->render();

        wp_die();
    }         
}

endif; // End class_exists check