<?php
/**
 * The template used to display the variable prices field.
 *
 * @author  Studio 164a
 * @since   1.0.0
 * @version 1.0.0
 */

if ( ! isset( $view_args[ 'form' ] ) || ! isset( $view_args[ 'field' ] ) ) {
    return;
}

$form       = $view_args[ 'form' ];
$field      = $view_args[ 'field' ];
$key        = $form->get_form_identifier();
$value      = isset( $field[ 'value' ] ) && is_array( $field[ 'value' ] ) ? $field[ 'value' ] : array();
?>
<table class="pp-edd-variable-prices charitable-campaign-form-table charitable-repeatable-form-field-table variable-pricing hidden"> 
    <tbody>
        <?php 
        foreach ( $value as $i => $price ) : 

            ?>          
            <tr class="variable-price repeatable-field" data-index="<?php echo $i ?>">
                <td>
                    <div class="repeatable-field-wrapper">
                        <div class="charitable-form-field odd">
                            <label for="<?php printf( 'merchandise_%s_variable_prices_%d_name', $key, $i ) ?>"><?php _e( 'Name', 'pp-toolkit' ) ?></label>
                            <input 
                                type="text" 
                                id="<?php printf( 'merchandise_%s_variable_prices_%d_name', $key, $i ) ?>" 
                                name="<?php printf( 'merchandise[%s][variable_prices][%d][name]', $key, $i ) ?>" 
                                value="<?php echo $price['name'] ?>" />
                        </div>
                        <div class="charitable-form-field even">
                            <label for="<?php printf( 'merchandise_%s_variable_prices_%d_amount', $key, $i ) ?>"><?php _e( 'Price', 'pp-toolkit' ) ?></label>
                            <input 
                                type="number" 
                                id="<?php printf( 'merchandise_%s_variable_prices_%d_amount', $key, $i ) ?>" 
                                name="<?php printf( 'merchandise[%s][variable_prices][%d][amount]', $key, $i ) ?>"
                                value="<?php echo $price['amount'] ?>", 
                                min="0"
                                step="0.01" />                       
                        </div>
                        <button class="remove" data-charitable-remove-row="<?php echo $i ?>">x</button>
                    </div>
                </td>
            </tr>       
            <?php 

        endforeach;
        ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3"><a class="add-row" href="#" data-charitable-add-row="variable-price" data-form-identifier="<?php echo $key ?>"><?php _e( 'Add new price', 'pp-toolkit' ) ?></a></td>
        </tr>
    </tfoot>
</table>