( function($){

    var get_next_table_index = function( $table ) {
        var $rows = $table.find( '[data-index]' ), 
            index = 0;

        if ( $rows.length ) {
            index = parseInt( $rows.last().data( 'index' ), 10 ) + 1;
        }

        return index;
    };

    var add_volunteers_need_row = function() {
        var $table = $( '#charitable-campaign-volunteers-need tbody' ),
            index = function() {
                var $rows = $table.find( '[data-index]' ), 
                    index = 0;

                if ( $rows.length ) {
                    index = parseInt( $rows.last().data( 'index' ), 10 ) + 1;
                }

                return index;
            }(),
            row = '<tr class="volunteers-need repeatable-field" data-index="' + index + '">'
                + '<td>'
                + '<div class="repeatable-field-wrapper">'
                + '<div class="charitable-form-field odd" style="width: 100%;">'
                + '<label for=suggested_donations_' + index + '>' + PP_PRODUCT_SUBMISSION.volunteers_need_label + '</label>'
                + '<input type="text" id="suggested_donations_' + index + '" name="volunteers[' + index + '][need]" />'
                + '</div>'
				
                + '<button data-charitable-remove-row="' + index + '" class="remove">x</button>'
                + '</div>'
                + '</td>'
                + '</tr>';                

        $table.find( '.no-suggested-amounts' ).hide();
        $table.append( row );
    };  

	var add_volunteers_need_admin_row = function() {

		var $table = $( '#charitable-campaign-volunteers-need tbody' ),

			index = function() {

				var $rows = $table.find( '[data-index]' ), 

					index = 0;



				if ( $rows.length ) {

					index = parseInt( $rows.last().data( 'index' ), 10 ) + 1;

				}



				return index;

			}(),

			row = '<tr data-index="' + index + '">'

				+ '<td><input type="text" id="campaign_suggested_donations_' + index + '" name="volunteers[' + index + '][need]" placeholder="' + CHARITABLE.volunteers_need_placeholder + '" />'

				+ '</tr>';



		$table.find( '.no-suggested-amounts' ).hide();

		$table.append( row );

	};	


    var add_variable_price_row = function( $el ) {
        var $tbody = $el.parents( '.pp-edd-variable-prices' ).find( 'tbody' ),
            index = get_next_table_index( $tbody ),
            identifier = $el.data( 'form-identifier' ),
            row = '<tr class="variable-price repeatable-field" data-index="' + index + '">'
                + '<td>'
                + '<div class="repeatable-field-wrapper">'
                + '<div class="charitable-form-field odd">'
                + '<label for="merchandise_' + identifier + '_variable_prices_' + index + '_name">' + PP_PRODUCT_SUBMISSION.price_name_label + '</label>'                
                + '<input type="text" id="merchandise_' + identifier + '_variable_prices_' + index + '_name" name="merchandise[' + identifier + '][variable_prices][' + index + '][name]" />'
                + '</div>'
                + '<div class="charitable-form-field even">'
                + '<label for="merchandise_' + identifier + '_variable_prices_' + index + '_amount">' + PP_PRODUCT_SUBMISSION.price_amount_label + '</label>'
                + '<input type="text" id="merchandise_' + identifier + '_variable_prices_' + index + '_amount" name="merchandise[' + identifier + '][variable_prices][' + index + '][amount]" />'
                + '</div>'
                + '<button data-charitable-remove-row="' + index + '" class="remove">x</button>'
                + '</div>'
                + '</td>'
                + '</tr>';                

        $tbody.append( row );

        console.trace();
    };  

    var remove_table_row = function( index, $button ) {
        var $table = $button.parents( 'table' ).first(), 
            $row = $table.find( 'tr[data-index=' + index + ']' );

        $row.remove();
    };

    var toggle_price_fields = function( $el ) {
        var variable_pricing_on = $el.is( ':checked' );
        
        $el.parent().nextAll( '.variable-pricing' ).toggleClass( 'hidden', ! variable_pricing_on );
        $el.parent().nextAll( '.standard-pricing' ).toggleClass( 'hidden', variable_pricing_on );
    }; 

    var add_merchandise_form_row = function( $el ) {
        var $table = $( '#pp-merchandise' ),            
            index = get_next_table_index( $table ),            
            data = {
                'action'    : 'add_merchandise_form', 
                'index'     : index, 
                'nonce'     : $el.data( 'nonce' )
            };

        $table.addClass( 'loading' );

        $.post( CHARITABLE_VARS.ajaxurl, data, function( response ) {
            $table.removeClass( 'loading' );
            $table.find( 'tbody .loading-row' ).before( response );
        });
    };

    var add_event_form_row = function( $el ) {
        var $table = $( '#pp-event' ),            
            index = get_next_table_index( $table ),            
            data = {
                'action'    : 'add_event_form', 
                'index'     : index, 
                'nonce'     : $el.data( 'nonce' )
            };

        $table.addClass( 'loading' );

        $.post( CHARITABLE_VARS.ajaxurl, data, function( response ) {
            $table.removeClass( 'loading' );

            $table.find( '> tbody > .loading-row' ).before( response );
        });
    };

    var setup_event_handlers = function() {
        $( '#pp-event' )
        .on( 'change', 'input[name=all_day]', function() {
            var is_checked = $( this ).is( ':checked' );

            $( '#charitable_field_start_date_time, #charitable_field_end_date_time' ).find( '.at-time, select' ).toggleClass( 'hidden', is_checked );
        })
        .on( 'change', '.datepicker_start_date_time', function() {
            var $end_date = $(this).parents( 'fieldset' ).find( '.datepicker_end_date_time' );

            // Set the min date to the start date.
            $end_date.datepicker( 'option', 'minDate', $(this).val() );
            
            // Set the end date min date and default date in two cases:
            // 1. No end date set yet
            // 2. The end date is set, but it's before the start date
            if ( null === $end_date.datepicker( 'getDate' ) 
                || $(this).datepicker( 'getDate' ) > $end_date.datepicker( 'getDate' ) ) { 

                // The first call to datepicker() is to initialize the datepicker first. 
                $end_date.datepicker().datepicker( 'setDate', $(this).val() );
            }        
        });
    };  

    var add_ticket_form_row = function( $el ) {
        var $table = $el.parents( '.pp-tickets' ),
            index = get_next_table_index( $table ),            
            data = {                
                'action'    : 'add_ticket_form', 
                'event_id'  : $el.data( 'event-id' ),
                'namespace' : $el.data( 'namespace' ),
                'index'     : index, 
                'nonce'     : $el.data( 'nonce' )
            };

        $table.addClass( 'loading' );

        $.post( CHARITABLE_VARS.ajaxurl, data, function( response ) {
            $table.removeClass( 'loading' );
            $table.find( 'tbody' ).append( response );
        });
    };

    var toggle_payment_details = function( $el ) {
        var selected = $el.val(), 
            $container = $( '#charitable_field_funds_recipient' );

        if ( 'non-profit' === selected ) {
            $container.siblings( '.toggle-non-profit' ).removeClass( 'hidden' );
            $container.siblings( '.toggle-direct' ).addClass( 'hidden' );
        }
        else {
            $container.siblings( '.toggle-non-profit' ).addClass( 'hidden' );
            $container.siblings( '.toggle-direct' ).removeClass( 'hidden' );
        }
    };

    $(document).ready( function(){
        // Set up price fields 
        $( '.toggle-variable-pricing input[type=checkbox]' ).each( function() {
            toggle_price_fields( $( this ) );
        });

        $( 'body' ).on( 'change', '.toggle-variable-pricing input[type=checkbox]', function() {
            toggle_price_fields( $(this ) );
        });

        // Set up payment fields
        $( '[name=funds_recipient]' ).on( 'change', function() {
            toggle_payment_details( $(this) );
        })
        .trigger( 'change' );

        // Add form rows dynamically
        $( 'body' )
        .on( 'click', '[data-charitable-add-row]', function( event ) {
            var type = $( this ).data( 'charitable-add-row' );

            switch ( type ) {
                case 'variable-price' : 
                    add_variable_price_row( $( this ) );
                    break;

                case 'merchandise-form' : 
                    add_merchandise_form_row( $( this ) );
                    break;

                case 'event-form' : 
                    add_event_form_row( $( this ) );
                    break;

                case 'ticket-form' : 
                    add_ticket_form_row( $( this ) );
                    break;

                case 'volunteers-need' : 
                    add_volunteers_need_row( $( this ) );
                    break;            

                case 'volunteers-admin' : 
                    add_volunteers_need_admin_row( $( this ) );
                    break;            
					
					}

            event.preventDefault();
        })
        // Remove form rows
        .on( 'click', '[data-charitable-remove-row]', function() {
        
            var index = $( this ).data( 'charitable-remove-row' );
            
            remove_table_row( index, $(this) );

            event.preventDefault();
        });

        // Set up datepicker dynamically
        $( 'body' ).on( 'focus', '.datepicker', function() {
            if ( false === $( this ).hasClass( 'hasDatepicker' ) ) {
                $( this ).datepicker();
            }        
        });

        // Set the max & min dates of post_date and end_date fields.
        $( 'input[name=post_date]' ).on( 'change', function(){
            var max_length = 365,
                min_length = 7,
                start_date = new Date( $(this).val() ),
                elapsed = ( start_date.getTime() - Date.now() ) / ( 1000 * 60 * 60 * 24 ), 
                min_end = Math.ceil( elapsed + min_length ), 
                max_end = Math.ceil( elapsed + max_length ),
                $end_date_field = $( 'input[name=end_date]' );

            if ( false === $end_date_field.hasClass( 'hasDatepicker' ) ) {
                $end_date_field.datepicker();   
            }

            $end_date_field
                .datepicker( "option", "minDate", min_end )
                .datepicker( "option", "maxDate", max_end );
        }); 

        $( 'input[name=end_date]' ).on( 'change', function(){
            var max_length = 365,
                min_length = 7,
                start_date = new Date( $(this).val() ),
                elapsed = ( start_date.getTime() - Date.now() ) / ( 1000 * 60 * 60 * 24 ), 
                min_start = Math.ceil( elapsed - max_length ), 
                max_start = Math.ceil( elapsed - min_length ),
                $start_date_field = $( 'input[name=post_date]' );

            if ( false === $start_date_field.hasClass( 'hasDatepicker' ) ) {
                $start_date_field.datepicker();   
            }

            $start_date_field
                .datepicker( "option", "minDate", min_start )
                .datepicker( "option", "maxDate", max_start );
        }); 

        // Set up handlers for event form
        setup_event_handlers();
    });

})( jQuery );