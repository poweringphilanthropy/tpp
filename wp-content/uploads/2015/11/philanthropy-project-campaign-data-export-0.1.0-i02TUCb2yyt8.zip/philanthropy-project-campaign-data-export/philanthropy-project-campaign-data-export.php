<?php
/**
 * Plugin Name:         Philanthropy Project - Campaign Data Export
 * Plugin URI:          https://wpcharitable.com
 * Description:         Adds additional data to the campaign data export. 
 * Version:             0.1.0
 * Author:              WP Charitable
 * Author URI:          https://wpcharitable.com
 * Requires at least:   4.1
 * Tested up to:        4.3
 *
 * Text Domain:         ppcde
 * Domain Path:         /languages/
 *
 * @package             Philanthropy Project Campaign Data Export
 * @category            Core
 * @author              Studio164a
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Load plugin functionality, but only if Charitable and Charitable_WePay_Payout are found and activated.
 *
 * @return  void
 * @since   1.0.0
 */
function ppcde_load() {    
    /* Check for Charitable */
    if ( ! class_exists( 'Charitable' ) ) {

        if ( ! class_exists( 'Charitable_Extension_Activation' ) ) {

            require_once 'includes/class-charitable-extension-activation.php';

        }

        $activation = new Charitable_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
        $activation = $activation->run();

        return;
    } 

    add_action( 'charitable_start', 'ppcde_start' );
}

add_action( 'plugins_loaded', 'ppcde_load', 1 );

/**
 * Bootstrap the plugin functionality.
 *
 * @return  void
 * @since   0.1.0
 */
function ppcde_start() {
    add_filter( 'charitable_export_donations_columns', 'ppcde_add_export_columns' );
    add_filter( 'charitable_export_data_key_value', 'ppcde_add_export_data', 10, 3 );
}

/** 
 * Add additional columns to the data export. 
 *
 * @param   array $columns
 * @return  array
 * @since   0.1.0
 */
function ppcde_add_export_columns( $columns ) {
    $columns[ 'donor_address' ] = __( 'Donor Address', 'ppcde' );
    $columns[ 'purchase_details' ] = __( 'Donation Details', 'ppcde' );
    $columns[ 'shipping' ] = __( 'Shipping Fee', 'ppcde' );
    return $columns;
}

/** 
 * Add data for the new fields to the data export. 
 *
 * @param   mixed   $value
 * @param   string  $key
 * @param   array   $data
 * @return  mixed
 * @since   0.1.0
 */
function ppcde_add_export_data( $value, $key, $data ) {
    static $matched_items = array();
    static $row_has_shipping = false;

    switch ( $key ) {
        case 'donor_address' : 
            $donation = charitable_get_donation( $data[ 'donation_id' ] );
            
            $address = $donation->get_donor()->get_address();

            $value = str_replace( '<br/>', PHP_EOL, $address );
            
            break;

        case 'purchase_details' :

            $donation_log = get_post_meta( $data[ 'donation_id' ], 'donation_from_edd_payment_log', true );

            foreach ( $donation_log as $idx => $campaign_donation ) {
                /* If we have already listed this donation ID, skip */
                if ( isset( $matched_items[ $data[ 'donation_id' ] ][ $idx ] ) ) {
                    continue;
                }

                /* If the campaign_id in the donation log entry does not match the current campaign donation record, skip */
                if ( $campaign_donation[ 'campaign_id' ] != $data[ 'campaign_id' ] ) {
                    continue;
                }

                /* If the amount does not match, skip */
                if ( $campaign_donation[ 'amount' ] != $data[ 'amount' ] ) {
                    continue;
                }

                /* At this point, we know it matches. Check if it's a fee */
                if ( $campaign_donation[ 'edd_fee' ] ) {

                    $value = __( 'Donation', 'ppcde' );

                }
                /* If not, work through the purchased downloads and find the matching one. */
                else {
                    $payment_id = Charitable_EDD_Payment::get_payment_for_donation( $data[ 'donation_id' ] );

                    foreach ( edd_get_payment_meta_cart_details( $payment_id ) as $download ) {

                        /* The download ID must match */
                        if ( $download[ 'id' ] != $campaign_donation[ 'download_id' ] ) {
                            continue;
                        }

                        /* The amount for this particular download must also match */
                        if ( $download[ 'subtotal' ] != $data[ 'amount' ] ) {
                            continue;
                        }

                        /* If we get here, we have a match. */
                        $value = sprintf( '%s x %d', strip_tags( $download[ 'name' ] ), $download[ 'quantity' ] );

                        /* Check for shipping fees associated with this download */
                        if ( empty( $download[ 'fees' ] ) ) {
                            break;
                        }
                        
                        foreach ( $download[ 'fees' ] as $fee_id => $fee ) {
                            if ( false === strpos( $fee_id, 'simple_shipping' ) ) {
                                continue;
                            }

                            /* This row has shipping, so store the $fee in our static variable */
                            $row_has_shipping = $fee;
                            break;
                        }

                        break;
                    }
                }

                $matched_items[ $data[ 'donation_id' ] ][ $idx ] = $value;
            }

            break;

        case 'shipping' : 

            /* If this row is showing a product purchase and the product purchase had shipping fees, 
               $row_has_shipping will be an array */
            if ( ! $row_has_shipping ) {
                $value = '0';
            }

            $value = isset( $row_has_shipping[ 'amount' ] ) ? $row_has_shipping[ 'amount' ] : '0';

            /* Reset to false */
            $row_has_shipping = false;

            break;
    }   
    
    return $value; 
}




