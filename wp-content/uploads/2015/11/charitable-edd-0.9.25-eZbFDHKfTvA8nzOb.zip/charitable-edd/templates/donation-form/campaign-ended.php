<?php
/**
 * Display notice that campaign has ended. Donation cannot proceed. 
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 */

$campaign 			= $view_args[ 'campaign' ];
$form 				= $view_args[ 'form' ];
?>