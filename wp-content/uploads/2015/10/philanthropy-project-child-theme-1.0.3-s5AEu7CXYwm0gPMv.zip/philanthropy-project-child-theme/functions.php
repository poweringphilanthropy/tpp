<?php

add_filter( 'oembed_ttl', function() {
	return 1; 
});
add_filter( 'embed_cache_oembed_types', function() {
	return array();
});

add_filter( 'edd_log_test_payment_stats', '__return_true' );

/**
 * Prepare child theme. 
 *
 * This enqueues the child theme's style.css file after first loading
 * the main theme's stylesheet.
 *
 * @return  void
 * @since   1.0.0
 */
function reach_child_load_styles() {    
	wp_enqueue_script( 'philanthropy-project-scripts', get_stylesheet_directory_uri() . "/media/js/custom.js" );
    wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/custom.css", array( 'reach-style' ), reach_get_theme()->get_theme_version() );
    wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/css/main.css", array( 'reach-style' ), reach_get_theme()->get_theme_version() );
    wp_enqueue_style( 'reach-child-styles' );
}

add_action( 'wp_enqueue_scripts', 'reach_child_load_styles', 100 );

/**
 * Set up child theme
 */
function franklin_child_after_setup_theme() {
	register_sidebar( array(
		'id' => 'sidebar_get_inspired',
		'name' => __( 'Get inspired sidebar', 'reach' ),
		'description' => __( 'The get inspired sidebar.', 'reach' ),
		'before_widget' => '<aside id="%1$s" class="widget cf %2$s">',
		'after_widget' => '</aside>',
		'before_title' => '<div class="title-wrapper"><h4 class="widget-title">',
		'after_title' => '</h4></div>'
	));
}

add_action('after_setup_theme', 'franklin_child_after_setup_theme');

function remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

add_filter( 'comment_form_defaults', 'remove_comment_form_allowed_tags' );