<?php
/**
 * Class responsible for defining the "campaign recipient" part of the campaign form.
 *
 * @package     Charitable Ambassadors/Classes/Charitable_Ambassadors_Campaign_Recipient_Form
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Ambassadors_Campaign_Recipient_Form' ) ) : 

/**
 * Charitable_Ambassadors_Campaign_Recipient_Form
 *
 * @since       1.0.0
 */
class Charitable_Ambassadors_Campaign_Recipient_Form {

    /**
     * Instantiate the class, but only during the start phase.
     * 
     * @return  void
     * @static 
     * @access  public
     * @since   1.0.0
     */
    public static function start() {        
        if ( 'init' != current_filter() ) {
            return;
        }

        if ( self::add_recipients_page() ) {
            new Charitable_Ambassadors_Campaign_Recipient_Form();
        }        
    }

    /**
     * Returns whether a recipients page is necessary. 
     *
     * @return  boolean
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function add_recipients_page() {
        $recipient_types = charitable_get_option( 'campaign_recipients', array() );

        if ( empty( $recipient_types ) ) {
            return false;
        }

        if ( count( $recipient_types ) > 1 ) {
            return true;
        }

        $recipient_type = charitable_get_recipient_type( $recipient_types[ 0 ] );

        return isset( $recipient_type[ 'searchable' ] ) && $recipient_type[ 'searchable' ];
    } 

    /**
     * Set up the class. 
     * 
     * Note that the only way to instantiate an object is with the charitable_ambassadors_start method, 
     * which can only be called during the start phase. In other words, don't try 
     * to instantiate this object. 
     *
     * @access  private
     * @since   1.0.0
     */
    private function __construct() {
        $this->attach_hooks_and_filters();
    }

    /**
     * Sets up callback methods for certain hooks. This is responsible for hooking 
     * additional template files to hooks inside the main shortcode templates.
     *
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function attach_hooks_and_filters() {        
        add_filter( 'charitable_campaign_submission_pages', array( $this, 'add_recipient_details_page' ) );
        add_filter( 'charitable_campaign_submission_fields', array( $this, 'add_recipient_type_fields' ) );

        add_filter( 'charitable_recipient_type_fields', array( $this, 'add_recipient_type_search' ), 10, 3 );
        add_action( 'charitable_campaign_submission_save_page_recipient_details', array( $this, 'save_recipient_details' ) );

        /* You can use this hook to obtain the class instance and remove any of the callbacks created .*/
        do_action( 'charitable_ambassadors_campaign_recipient_form_start', $this );
    }

    /**
     * Add the recipient details page to the form. 
     *
     * @return  array
     * @access  public
     * @since   1.0.0
     */
    public function add_recipient_details_page( $pages ) {
        $pages[] = array(
            'page' => 'recipient_details',
            'priority' => 1            
        );

        return $pages;
    }

    /**
     * Returns the recipient details fields. 
     *
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_recipient_type_fields( $fields ) {
        $fields[ 'recipient_fields' ] = array(
            'legend'        => __( 'Who Are You Raising Money For?', 'charitable-ambassadors' ),
            'type'          => 'fieldset',
            'fields'        => $this->get_recipient_fields(),
            'priority'      => 0,
            'page'          => 'recipient_details'
        );

        return $fields;
    }

    /**
     * Returns the fields specific to a particular recipient type. 
     *
     * @param   string  $recipient_type
     * @param   array   $recipient_types
     * @return  array
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function get_individual_recipient_type_fields( $recipient_type, $recipient_types = array() ) {
        if ( empty( $recipient_types ) ) {
            $recipient_types = charitable_get_recipient_types();
        }

        $fields = apply_filters( 'charitable_recipient_type_fields', array(), $recipient_type, $recipient_types[ $recipient_type ] );

        uasort( $fields, 'charitable_priority_sort' );
        
        return $fields;
    }

    /**
     * Add search field to a recipient type.
     *
     * @param   array   $fields
     * @param   string  $recipient_type
     * @param   array   $recipient_type_args
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_recipient_type_search( $fields, $recipient_type, $recipient_type_args ) {        
        if ( ! $recipient_type_args[ 'searchable' ] ) {
            return $fields;
        }

        $recipient_type_args[ 'recipient_type_key' ] = $recipient_type;

        $fields[ 'recipient_type_' . $recipient_type . '_select' ] = array(
            'type' => 'recipient-type-search',
            'recipient_type' => $recipient_type_args,
            'priority' => 1
        );

        return $fields;
    }

    /**
     * Save the campaign recipient details. 
     *
     * @param   Charitable_Ambassadors_Campaign_Form $form
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function save_recipient_details( Charitable_Ambassadors_Campaign_Form $form ) {
        /* If required fields are missing, stop. */
        if ( ! $form->check_required_fields( $form->get_merged_fields( 'recipient_details' ) ) ) {
            return;
        }

        add_filter( 'charitable_campaign_submission_form_args', array( $this, 'set_campaign_submission_page' ) );
        add_filter( 'charitable_ambassadors_campaign_form_hidden_fields', array( $this, 'add_hidden_recipient_type_fields' ) );

        do_action( 'charitable_ambassadors_campaign_form_recipient_selection_save', $form );
    }

    /**
     * Set the campaign submission page to 1. 
     *
     * @param   mixed[] $args
     * @return  mixed[]
     * @access  public
     * @since   1.0.0
     */
    public function set_campaign_submission_page( $args ) {
        $args[ 'recipient_type' ] = $_POST[ 'recipient' ];
        $args[ 'page' ] = 1;
        return $args;
    }

    /**
     * Adds the recipient fields as  the recipient details fields. 
     *
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_hidden_recipient_type_fields( $fields ) {
        $possible_keys = array_keys( $this->get_recipient_fields() );

        $recipient_types = charitable_get_recipient_types();

        foreach ( $recipient_types as $recipient_type => $recipient_type_args ) {

            $recipient_type_fields = self::get_individual_recipient_type_fields( $recipient_type, $recipient_types );
            $possible_keys = array_merge( $possible_keys, array_keys( $recipient_type_fields ) );

        }     
    
        foreach ( $possible_keys as $key ) {
            if ( ! isset( $_POST[ $key ] ) ) {
                continue;
            }

            $fields[ $key ] = $_POST[ $key ];
        }

        return $fields;
    }

    /**
     * Return the recipient fields. 
     *
     * @return  array[]
     * @access  private
     * @since   1.0.0
     */
    private function get_recipient_fields() {
        $recipient_fields = apply_filters( 'charitable_campaign_submission_recipient_fields', array(
            'recipient' => array(
                'type'          => 'recipient-types',
                'priority'      => 42,
                'data_type'     => 'meta'
            )
        ), $this );

        uasort( $recipient_fields, 'charitable_priority_sort' );

        return $recipient_fields;
    }
}

endif; // End class_exists check