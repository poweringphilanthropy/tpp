( function($) {

    $(document).ready( function() {        
        $( '.charitable-campaign-recipient-search .select2' ).each( function(){
            var $el = $(this);

            $el.select2({
                ajax: {
                    url: CHARITABLE_VARS.ajaxurl,
                    method: 'POST',
                    dataType: 'json',
                    delay: 250,
                    quietMillis: 100,
                    data: function (params) {
                        return {
                            q: params.term,                        
                            action: 'charitable_recipient_search',
                            recipient_type: $el.data( 'recipient-type' )
                        };
                    },
                    success: function( response ) {
                        console.log( response );
                    },
                    processResults: function (data) {
                        return {
                            results: $.map( data, function( item ) {
                                return {
                                    id : item.id,
                                    text : item.text
                                }
                            })
                        };
                    },
                    cache: true
                },
                minimumInputLength : 3, 
                templateSelection : function( result ) {
                    return result.text;
                }, 
                templateResult : function( result ) {
                    return result.text;
                }
            });
        });        
    });

})( jQuery );