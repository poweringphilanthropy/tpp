<?php
/**
 * Class responsible for defining the "personal cause" recipient type. 
 *
 * @package     Charitable Ambassadors/Classes/Charitable_Ambassadors_Personal_Cause
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Ambassadors_Personal_Cause' ) ) : 

/**
 * Charitable_Ambassadors_Personal_Cause
 *
 * @since       1.0.0
 */
class Charitable_Ambassadors_Personal_Cause {

    /**
     * Instantiate the class, but only during the start phase.
     * 
     * @param   Charitable_Ambassadors $charitable_ambassadors
     * @return  void
     * @static 
     * @access  public
     * @since   1.0.0
     */
    public static function start( Charitable_Ambassadors $charitable_ambassadors ) {
        if ( ! $charitable_ambassadors->is_start() ) {
            return;
        }

        $charitable_ambassadors->register_object( new Charitable_Ambassadors_Personal_Cause( $charitable_ambassadors ) );
    }

    /**
     * Set up the class. 
     * 
     * Note that the only way to instantiate an object is with the charitable_start method, 
     * which can only be called during the start phase. In other words, don't try 
     * to instantiate this object. 
     *
     * @access  private
     * @since   1.0.0
     */
    private function __construct() {
        $this->attach_hooks_and_filters();        
    }

    /**
     * Sets up callback methods for certain hooks. This is responsible for hooking 
     * additional template files to hooks inside the main shortcode templates.
     *
     * @return  void
     * @access  private
     * @since   1.0.0
     */
    private function attach_hooks_and_filters() {
        add_action( 'init', array( $this, 'register_recipient_type' ) );
        add_filter( 'charitable_campaign_submission_fields', array( $this, 'add_payment_details_fields' ), 10, 2 );

        /* You can use this hook to obtain the class instance and remove any of the callbacks created .*/
        do_action( 'charitable_ambassadors_personal_cause_start', $this );
    }
    
    /**
     * Register the 'personal' campaign recipient type.
     *
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function register_recipient_type() {
        $args = apply_filters( 'charitable_ambassadors_personal_recipient_type', array(         
            'label' => __( 'Your Cause', 'charitable-ambassadors' ),
            'description' => __( 'You are raising money for a personal cause. You will receive the donations.', 'charitable-ambassadors' ),
            'admin_label' => __( 'Personal Causes', 'charitable-ambassadors' ),
            'admin_description' => __( 'Campaign creators raise money for their own cause. They will receive donations.', 'charitable-ambassadors' )
        ) );

        charitable_register_recipient_type( 'personal', $args );            
    }

    /**
     * Add payment details fields to the campaign form. 
     *
     * @param   array[] $fields
     * @param   Charitable_Ambassadors_Campaign_Form $form
     * @return  array[]
     * @access  public
     * @since   1.0.0
     */
    public function add_payment_details_fields( $fields, $form ) {
        if ( $form->get_recipient_type() != 'personal' ) {
            return $fields;
        }

        $fields[ 'payment_fields' ] = array(
            'legend'        => __( 'Payment Details', 'charitable-ambassadors' ),
            'type'          => 'fieldset',
            'fields'        => $this->get_payment_fields( $form ),
            'priority'      => 80,
            'page'          => 'campaign_details'
        );

        return $fields;
    }

    /**
     * Payment fields.  
     *
     * @param   Charitable_Ambassadors_Campaign_Form $form
     * @return  array[]
     * @access  private
     * @since   1.0.0
     */
    private function get_payment_fields( Charitable_Ambassadors_Campaign_Form $form ) {
        $payment_fields = apply_filters( 'charitable_campaign_submission_payment_fields', array(
            'paypal' => array(
                'label'         => __( 'Your PayPal Account', 'charitable-ambassadors' ), 
                'description'   => __( 'When the campaign is finished, you will be paid with your PayPal account.', 'charitable-ambassadors' ), 
                'type'          => 'email',
                'priority'      => 42, 
                'value'         => $form->get_user()->paypal, 
                'data_type'     => 'user'
            )
        ), $form, $this );

        uasort( $payment_fields, 'charitable_priority_sort' );

        return $payment_fields;
    }    
}

endif; // End class_exists check