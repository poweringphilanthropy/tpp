<?php 
/**
 * Template name: User Dashboard
 *
 * @package 	Reach
 */

get_template_part( 'user-dashboard' );