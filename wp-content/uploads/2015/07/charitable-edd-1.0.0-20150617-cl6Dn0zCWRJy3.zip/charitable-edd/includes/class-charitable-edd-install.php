<?php
/**
 * Charitable EDD Install class.
 * 
 * The responsibility of this class is to manage the events that need to happen 
 * when the plugin is activated.
 *
 * @package		Charitable EDD/Classes/Charitable_EDD_Install
 * @copyright 	Copyright (c) 2014, Eric Daams	
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @version 	1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Charitable_EDD_Install' ) ) : 

/**
 * Charitable_EDD_Install
 *
 * @since 		1.0.0
 */
class Charitable_EDD_Install {

	/**
	 * Activate the plugin. 
	 *
	 * @return  void
	 * @access  public
	 * @static
	 * @since   1.0.0
	 */
	public static function activate() {
		add_action( 'charitable_activate_addon', array( 'Charitable_EDD_Install', 'create_tables' ), 20 );
		do_action( 'charitable_activate_addon', 'charitable-benefactors' );
	}

	/**
	 * Create database tables. 
	 *
	 * @return 	void
	 * @access 	public
	 * @static
	 * @since 	1.0.0
	 */
	public static function create_tables() {	
		require_once( charitable()->get_path( 'includes' ) . 'db/abstract-class-charitable-db.php' );
		require_once( 'db/class-charitable-edd-benefactors-db.php' );
		$table = new Charitable_EDD_Benefactors_DB();
		$table->create_table();
	}
}

endif;