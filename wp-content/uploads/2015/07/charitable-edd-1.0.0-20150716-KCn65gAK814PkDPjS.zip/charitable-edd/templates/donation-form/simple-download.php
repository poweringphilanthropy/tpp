<?php
/**
 * Display a download that the donor can purchase which will
 * make a donation to the campaign.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 */

$download_id = $view_args[ 'download_id' ];

?>
<div class="charitable-edd-connected-download simple-download">
	<div class="charitable-edd-connected-download-description">

		<?php if ( apply_filters( 'charitable_edd_donation_form_show_thumbnail', true ) ) : 

			echo get_the_post_thumbnail( $download_id, 'post-thumbnail' );
				
		endif;

		if ( apply_filters( 'charitable_edd_donation_form_show_title', true ) ) : ?>

			<h5 class="download-title"><?php echo get_the_title( $download_id ) ?></h5>

		<?php 
		endif;

		if ( apply_filters( 'charitable_edd_donation_form_show_excerpt', true ) ) :

			echo apply_filters( 'the_excerpt', get_post_field( 'post_content', $download_id ) );

		endif;
		?>	
	</div><!--.charitable-edd-connected-download-description-->
	<input type="checkbox" 
		class="charitable-edd-download-select" 
		name="downloads[<?php echo $download_id ?>]" 
		value="<?php echo $download_id ?>" 
		data-price="<?php echo edd_get_download_price( $download_id ) ?>" 
		<?php checked( edd_item_in_cart( $download_id ) ) ?>
	/>
	<span class="edd-price-option-price" itemprop="price">
		<?php edd_price( $download_id ) ?>
		<span class="currency"><?php echo edd_get_currency() ?></span>
	</span>	
</div><!--.charitable-edd-connected-download-->