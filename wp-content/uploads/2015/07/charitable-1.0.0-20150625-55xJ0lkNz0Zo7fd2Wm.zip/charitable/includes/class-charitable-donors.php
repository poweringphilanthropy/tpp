<?php
/**
 * The class responsible for querying donors.
 *
 * @package     Charitable/Classes/Charitable_Donors_Query
 * @version     1.0.0
 * @author      Eric Daams
 * @copyright   Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_Donors_Query' ) ) : 

/**
 * Charitable_Donors_Query
 *
 * @since       1.0.0
 */
class Charitable_Donors_Query {

    /**
     * User-defined arguments. 
     *
     * @var     array
     * @access  protected
     */
    protected $args;    

    /**
     * Create new query object. 
     *
     * @access  public
     * @since   1.0.0
     */
    public function __construct( $args = array() ) {
        add_filter( 'charitable_donor_query_sanitize_argument', array( $this, 'sanitize_argument' ), 5, 2 );

        $this->parse_args( $args );
    }

    /**
     * Sets query arguments by parsing passed arguments with defaults.
     *
     * @param   array   $args
     * @return  array
     * @access  protected
     * @since   1.0.0
     */
    protected function parse_args( $args = array() ) {
        $defaults = apply_filters( 'charitable_donor_query_default_args', array(            
            'status'    => array( 'charitable-completed', 'charitable-preapproved' ), 
            'orderby'   => 'date',
            'order'     => 'DESC',
            'number'    => 20,
            'paged'     => 1, 
            'fields'    => array( 'ID', 'donations' )
        ) );

        $args = wp_parse_args( $args, $defaults );

        foreach ( $args as $key => $value ) {
            $this->set( $key, $value );
        }
    }

    /**
     * Return the query argument value for the given key. 
     *
     * @param   string  $key
     * @return  mixed|null  Returns null if the argument is not found.  
     * @access  public
     * @since   1.0.0
     */
    public function get( $key ) {
        return isset( $this->args[ $key ] ) ? $this->args[ $key ] : null;
    }

    /**
     * Set the query argument for the given key. 
     * 
     * @param   string  $key
     * @param   mixed   $value
     * @return  void
     * @access  public
     * @since   1.0.0
     */
    public function set( $key, $value ) {
        $this->args[ $key ] = apply_filters( 'charitable_donor_query_sanitize_argument', $value, $key );
    }

    /**
     * Sanitize argument value when setting.  
     *
     * @param   mixed   $value
     * @param   string  $key     
     * @return  mixed
     * @access  public
     * @since   1.0.0
     */
    public function sanitize_argument( $value, $key ) {
        switch ( )
    }

    /**
     * Return list of donor IDs together with the number of donations they have made.
     *
     * @global  WPDB    $wpdb
     * @param   array   $args
     * @return  object[]        
     * @access  public
     * @static
     * @since   1.0.0
     */
    public static function get_donors( $args = array() ) {
        global $wpdb;

        $defaults = apply_filters( 'charitable_donor_query_default_args', array(            
            'status'    => array( 'charitable-completed', 'charitable-preapproved' ), 
            'orderby'   => 'date',
            'order'     => 'DESC',
            'number'    => 20,
            'paged'     => 1, 
            'fields'    => array( 'ID', 'donations' )
        ) );

        $args = wp_parse_args( $args, $defaults );

        $status = implode( ',', $args[ 'status' ] );
        $fields_clause = $this->get_fields_clause( $args[ 'fields' ] );
        $joins_clause = $this->get_joins( $args[ 'fields' ] );
        $order_clause = $this->get_order_clause();
        $limit_offset_clause = $this->get_limit_and_offset_clause( $args[ 'number' ], $args[ 'paged' ] );

        $sql = "SELECT $fields_clause
                FROM $wpdb->posts p
                $joins_clause
                WHERE p.post_type = 'donation'
                AND p.post_status IN ( %s )
                $order_clause
                GROUP BY p.post_author
                $limit_offset_clause";

        $sql = apply_filters( 'charitable_donor_query', $sql, $args );

        return $wpdb->get_results( $wpdb->prepare( $sql, $status ) );
    }

    /**
     * Return order clause. 
     *
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_order_clause() {    
        $order = in_array( $this->get( 'order' ), array( 'DESC', 'ASC' ) ) ? $this->get( 'order' ) : 'DESC';

        switch ( $this->get( 'orderby' ) ) {

            case 'date' : 
                $sql = "ORDER BY p.post_date $order";
                break;

            case 'donations' : 
                $sql = "ORDER BY donations $order";
                break;

            case 'amount' : 
                $sql = "ORDER BY amount $order";
                break;

            default : 
                $sql = "";
        }

        return apply_filters( 'charitable_donor_query_order_sql', $sql, $this );
    }

    /**
     * Return limit and offset clause. 
     *
     * @param   int     $number
     * @param   int     $paged
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_limit_and_offset_clause( $number, $paged ) {
        /* If a negative number has been passed, we will return all results. */
        if ( $number < 0 ) {
            return;
        }

        $sql = sprintf( "LIMIT %d ", $number );

        if ( $paged > 1 ) {
            $sql = sprintf( "OFFSET %d", ( $paged - 1 ) * $number );
        }

        return $sql;
    }

    /**
     * Return field limiting clause. 
     *
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_fields_clause( $fields ) {
        $select_fields = array( "p.post_author AS ID" );

        if ( is_array( $fields ) ) {
            if ( in_array( 'donations', $fields ) ) {
                $select_fields[] = "COUNT(*) AS donations";
            } 

            if ( in_array( 'amount', $fields ) ) {
                $select_fields[] = "SUM(cd.amount) AS amount";
            }

            if ( in_array( 'display_name', $fields ) ) {
                $select_fields[] = "u.display_name";
            }

            $sql = implode( ', ', $select_fields );
        }
        elseif ( 'all' == $fields ) {
            $sql = "COUNT(*) AS donations, SUM(cd.amount) AS amount, u.user_login, u.user_nicename, u.user_email, u.user_url, u.user_registered, u.display_name";
        }
        
        return apply_filters( 'charitable_donor_query_fields_sql', $sql, $fields, $select_fields );
    }

    /**
     * Return joins sql.  
     *
     * @param   array   $fields
     * @param   
     * @return  string
     * @access  protected
     * @since   1.0.0
     */
    protected function get_joins( $fields ) {    
        global $wpdb;

        $sql = "";

        if ( is_array( $fields ) && in_array( 'amount', $fields ) ) {
            $sql = "JOIN {$wpdb->prefix}charitable_campaign_donations cd ON cd.donation_id = p.ID";
        }
        elseif ( 'all' == $fields ) {
            $sql = "INNER JOIN {$wpdb->prefix}charitable_campaign_donations cd ON cd.donation_id = p.ID
                    INNER JOIN $wpdb->users u ON u.ID = p.post_author";
        }

        return apply_filters( 'charitable_donor_query_joins_sql', $sql, $fields );
    }
}

endif; // End class_exists check