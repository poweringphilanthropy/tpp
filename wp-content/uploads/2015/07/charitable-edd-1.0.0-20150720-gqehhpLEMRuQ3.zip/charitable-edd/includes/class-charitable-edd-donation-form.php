<?php
/**
 * A custom donation form handler for Charitable campaigns using EDD products.
 *
 * @package		Charitable EDD/Classes/Charitable_EDD_Donation_Form
 * @version 	1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_EDD_Donation_Form' ) ) : 

/**
 * Charitable_EDD_Donation_Form
 *
 * @since 		1.0.0 
 */
class Charitable_EDD_Donation_Form extends Charitable_Form implements Charitable_Donation_Form_Interface {

	/**
	 * The campaign object. 
	 *
	 * @var 	Charitable_Campaign
	 * @access  protected
	 */
	protected $campaign;

	/**
	 * The Charitable_EDD_Campaign object. 
	 *
	 * @var 	Charitable_EDD_Campaign
	 * @access  protected
	 */
	protected $edd_campaign;	

	/**
	 * Temporary, unique ID of this form. 
	 *
	 * @var 	string
	 * @access  protected
	 */
	protected $id;

	/**
	 * Arguments that are passed to the views. 
	 *
	 * @var 	array
	 * @access  protected
	 */
	protected $view_args;

	/**
	 * @var 	string
	 * @access  protected
	 */
	protected $nonce_action = 'charitable_donation';

	/**
	 * @var 	string
	 * @access  protected
	 */
	protected $nonce_name = '_charitable_donation_nonce';

	/**
	 * @var 	string
	 * @access  protected
	 */
	protected $form_action = 'make_donation';

	/**
	 * Create a donation form object.
	 *
	 * @param 	Charitable_Campaign $campaign
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function __construct( Charitable_Campaign $campaign ) {
		$this->campaign 	= $campaign;
		$this->id 			= uniqid();
		$this->edd_campaign = new Charitable_EDD_Campaign( $this->campaign->ID );
		$this->view_args 	= array( 
			'campaign'		=> $this->campaign, 
			'edd_campaign'	=> $this->edd_campaign, 
			'form'			=> $this
		);

		add_action( 'charitable_donation_form_amount', array( $this, 'add_hidden_fields' ), 1 );
		add_action( 'charitable_donation_form_before_donation_amount', array( $this, 'enter_donation_amount_header' ) );
		add_action( 'charitable_donation_form_amount', array( $this, 'enter_donation_amount' ) );
		add_action( 'charitable_edd_donation_form_before_downloads', array( $this, 'enter_downloads_section_header' ) );
		add_action( 'charitable_edd_donation_form_downloads', array( $this, 'select_downloads' ) );
		add_action( 'charitable_edd_donation_form_download', array( $this, 'download' ) );
		add_action( 'charitable_after_save_donation', array( $this, 'redirect_to_checkout' ) );

		do_action( 'charitable_edd_donation_form', $this );
	}

	/**
	 * Render the donation form. 
	 *
	 * @return 	void
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function render() {
		/* If the campaign has ended, donations cannot continue. */
		if ( $this->campaign->has_ended() ) {
			wp_redirect( get_permalink( $this->campaign->ID ) );
			exit;
		}

		charitable_edd_template( 'donation-form.php', $this->view_args );
	}

	/**
	 * Return arguments to pass to the view. 
	 *
	 * @return  mixed[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function get_view_args() {
		return $this->view_args;
	}

	/**
	 * Adds hidden fields to the start of the donation form.	
	 *
	 * @param 	Charitable_EDD_Donation_Form 	$form
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function add_hidden_fields( $form ) {
		if ( ! $form->is_current_form( $this->id ) ) {
			return false;
		}

		$this->nonce_field();

		?>			
		<input type="hidden" name="charitable_action" value="<?php echo $this->form_action ?>" />
		<input type="hidden" name="campaign_id" value="<?php echo $this->campaign->ID ?>" />
		<?php
	}

	/**
	 * Add header before donation amount section.
	 *
	 * @param 	Charitable_EDD_Donation_Form $form
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function enter_donation_amount_header( $form ) {
		if ( ! $form->is_current_form( $this->id ) ) {
			return;
		}

		charitable_template( 'donation-form/donation-amount-header.php' );		
	}	

	/**
	 * Load template to allow customers to enter the amount they would like to donate. 
	 *
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function enter_donation_amount() {
		charitable_template( 'donation-form/donation-amount.php', $this->view_args );
	}

	/**
	 * Load the template where the donation amount header is displayed. 
	 *
	 * @return 	void
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function enter_downloads_section_header() {
		charitable_edd_template( 'donation-form/downloads-section-header.php' );
	}

	/**
	 * Load the template where associated downloads are listed. 
	 *
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function select_downloads() {
		charitable_edd_template( 'donation-form/select-downloads.php', $this->view_args );		
	}

	/**
	 * Load the template where a single download is displayed.  
	 *
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function download( $download_id ) {		
		$this->view_args[ 'download_id' ] = $download_id;

		$view = edd_has_variable_prices( $download_id ) ? 'variable-download.php' : 'simple-download.php';

		charitable_edd_template( 'donation-form/' . $view, $this->view_args );
	}

	/**
	 * Display option to just donate money without choosing a download as a reward.
	 *
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function select_no_download( $downloads ) {
		charitable_edd_template( 'donation-form/no-download.php' );
	}

	/**
	 * Save the submitted donation.
	 *
	 * @return 	boolean
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function save_donation() {		
		if ( ! $this->validate_nonce() ) {
			return false;
		}

		if ( ! isset( $_POST[ 'campaign_id' ] ) ) {
			charitable_get_notices()->add_error( __( 'Unable to submit form. No campaign was selected.', 'charitable' ) );
			return false;
		}

		/**
 		 * Compare the cart total against the donation amount field. Any 
		 * excess in the donation amount field is added to the checkout
		 * as a fee.
		 */
		$cart_total = $this->add_downloads_to_cart();				
		$amount = Charitable_Donation_Form::get_donation_amount();
		$campaign_id = $_POST[ 'campaign_id' ];

		if ( $amount ) {
			Charitable_EDD_Cart::add_donation_fee_to_cart( $campaign_id, $amount );			
		}

		return true;
	}

	/**
	 * After saving the donation, redirect to checkout. 
	 *
	 * @return  void
	 * @access  public
	 * @since   1.0.0
	 */
	public function redirect_to_checkout() {				
		wp_redirect( edd_get_checkout_uri() ); 
		edd_die(); 
	}

	/**
	 * Add downloads to cart and return cart subtotal. 
	 *
	 * @return 	float
	 * @access  public
	 * @since 	1.0.0
	 */
	public function add_downloads_to_cart() {
		$cart_total = 0;

		if ( isset( $_POST[ 'downloads' ] ) && ! empty( $_POST[ 'downloads' ] ) ) {

			foreach ( $_POST[ 'downloads' ] as $download_id => $download_options ) {
				
				$quantity 		= isset( $download_options[ 'quantity' ] ) ? $download_options[ 'quantity' ] : 1;
				$options 		= array(
					'quantity'	=> $quantity
				);

				$line_item_amount = 0;

				if ( isset( $download_options[ 'price_id' ] ) ) {
					
					$options[ 'price_id' ] = $download_options[ 'price_id' ];
					$price = edd_get_price_option_amount( $download_id, $options[ 'price_id' ] );

					if ( is_array ( $options[ 'price_id' ] ) ) {

						foreach ( $options['price_id'] as $price_id ) {

							$line_item_amount += $quantity * edd_get_price_option_amount( $download_id, $price_id );

						}						

					}
					else {

						$line_item_amount += $quantity * edd_get_price_option_amount( $download_id, $options[ 'price_id' ] );
					}

				}
				else {

					$line_item_amount += $quantity * edd_get_download_price( $download_id );

				}

				edd_add_to_cart( $download_id, $options );

				$cart_total += $line_item_amount;				

			}				

		}

		return $cart_total;
	}
}

endif; // End class_exists check