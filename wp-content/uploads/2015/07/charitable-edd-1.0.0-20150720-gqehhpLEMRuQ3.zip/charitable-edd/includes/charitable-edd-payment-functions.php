<?php 

/**
 * Charitable EDD Payment Functions. 
 *
 * @author      Studio164a
 * @category    Functions
 * @package     Charitable EDD/Payments
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * This returns the EDD payment associated with the donation.
 *
 * @param   int     $donation_id
 * @return  int
 * @since   1.0.0
 */
function charitable_edd_get_edd_payment_from_donation( $donation_id ) {
       
}