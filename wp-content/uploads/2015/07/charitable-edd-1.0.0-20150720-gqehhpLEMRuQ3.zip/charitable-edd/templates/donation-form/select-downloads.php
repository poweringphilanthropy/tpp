<?php
/**
 * Display list of downloads that the donor can purchase which will
 * make a donation to the campaign.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 */

$campaign 		= $view_args[ 'campaign' ];
$edd_campaign 	= $view_args[ 'edd_campaign' ];
$form 			= $view_args[ 'form' ];

$downloads 		= $edd_campaign->get_connected_downloads();

if ( false === $downloads ) {
	return;
}

if ( $downloads->have_posts() ) :

	/**
	 * @hook 	charitable_edd_donation_form_before_downloads
	 */
	do_action( 'charitable_edd_donation_form_before_downloads', $campaign, $downloads ); ?>	

	<div class="charitable-connected-downloads">
	<?php 
	/**
	 * @hook 	charitable_edd_donation_form_before_first_download
	 */
	do_action( 'charitable_edd_donation_form_before_first_download', $downloads );	

	while ( $downloads->have_posts() ) : 
		$downloads->the_post();		

		/**
		 * @hook 	charitable_edd_donation_form_download
		 */
		do_action( 'charitable_edd_donation_form_download', get_the_ID() );
			
	endwhile;
	?>	
	</div>

	<?php 
	/**
	 * @hook 	charitable_edd_donation_form_after_downloads
	 */
	do_action( 'charitable_edd_donation_form_after_downloads', $campaign, $downloads );
	
endif;