<?php
/**
 * Display a download that the donor can purchase which will
 * make a donation to the campaign.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 */

$download_id 	= $view_args[ 'download_id' ];
$prices 		= apply_filters( 'edd_purchase_variable_prices', edd_get_variable_prices( $download_id ), $download_id );
$type   		= edd_single_price_option_mode( $download_id ) ? 'checkbox' : 'radio';
$mode   		= edd_single_price_option_mode( $download_id ) ? 'multi' : 'single';
$schema 		= edd_add_schema_microdata() ? ' itemprop="offers" itemscope itemtype="http://schema.org/Offer"' : '';
?>
<div class="charitable-edd-connected-download variable-download">
<div class="charitable-edd-connected-download-description">
		<?php if ( apply_filters( 'charitable_edd_donation_form_show_thumbnail', true ) ) : 

			echo get_the_post_thumbnail( $download_id, 'post-thumbnail' );
				
		endif;

		if ( apply_filters( 'charitable_edd_donation_form_show_title', true ) ) : ?>

			<h5 class="download-title"><?php echo get_the_title( $download_id ) ?></h5>

		<?php 
		endif;

		if ( apply_filters( 'charitable_edd_donation_form_show_excerpt', true ) ) :
			
			echo apply_filters( 'the_excerpt', get_post_field( 'post_content', $download_id ) );

		endif;
	
	?>
	</div><!--.charitable-edd-connected-download-description-->
	<?php 

	do_action( 'edd_before_price_options', $download_id ); 

	?>
	<div class="charitable-edd-price-options edd_price_options edd_<?php echo esc_attr( $mode ); ?>_mode">
		<ul>
			<?php
			if ( $prices ) :

				foreach ( $prices as $key => $price ) :
					
					?>
					<li id="edd_price_option_<?php echo $download_id ?>_<?php echo sanitize_key( $price['name'] ) ?>" class="edd-price-option" <?php echo $schema ?>>
						<label for="<?php esc_attr_e( 'edd_price_option_' . $download_id . '_' . $key ) ?>">
							<input type="<?php echo $type ?>"
								name="downloads[<?php echo $download_id ?>][price_id][]" 
								id="<?php esc_attr_e( 'edd_price_option_' . $download_id . '_' . $key ) ?>" 
								class="charitable-edd-download-select <?php esc_attr_e( 'edd_price_option_' . $download_id ) ?>" 
								value="<?php esc_attr_e( $key ) ?>" 
								data-price="<?php echo edd_get_price_option_amount( $download_id, $key ) ?>"
								<?php checked( edd_item_in_cart( $download_id, array( 'price_id' => $key ) ) ) ?>
							/>
							<span class="edd-price-option-price" itemprop="price">
								<?php echo edd_currency_filter( edd_format_amount( $price['amount'] ) ) ?>
								<span class="currency"><?php echo edd_get_currency() ?></span>
							</span>
							<span class="edd-price-option-name" itemprop="description">(<?php echo esc_html( $price['name'] ) ?>)</span>
						</label>
						<?php 
						do_action( 'edd_after_price_option', $key, $price, $download_id );
						?>
					</li>
					<?php 

				endforeach;
			endif;
			do_action( 'edd_after_price_options_list', $download_id, $prices, $type );
			?>
		</ul>
	</div><!--.edd_price_options-->
	<?php

	do_action( 'edd_after_price_options', $download_id );

	?>
</div><!--.charitable-edd-connected-download-->
