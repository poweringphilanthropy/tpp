<?php 
/**
 * Displays the user dashboard. The structure is based on the default page template in Underscores.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 */