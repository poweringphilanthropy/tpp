<?php
/**
 * Plugin Name: 		Charitable - Frontend Campaign Submissions
 * Plugin URI: 			http://164a.com
 * Description: 		Raise money for your campaigns with your Easy Digital Downloads store.
 * Version: 			1.0.0~alpha-1.0
 * Author: 				Studio 164a
 * Author URI: 			http://164a.com
 * Requires at least: 	4.0
 * Tested up to: 		4.1
 *
 * Text Domain: 		charitable-fes
 * Domain Path: 		/languages/
 *
 * @package 			Charitable EDD
 * @category 			Core
 * @author 				Studio164a
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Load plugin class, but only if Charitable and Easy Digital Downloads are found and activated.
 *
 * @return 	void
 * @since 	1.0.0
 */
function charitable_fes_load() {	
	require_once( 'includes/class-charitable-fes.php' );

	$has_dependencies = true;

	/* Check for Charitable */
	if ( ! class_exists( 'Charitable' ) ) {

		if ( ! class_exists( 'Charitable_Extension_Activation' ) ) {

			require_once 'includes/class-charitable-extension-activation.php';

		}

		$activation = new Charitable_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
		$activation = $activation->run();

		$has_dependencies = false;
	} 

	/* Finally, if both Charitable and Easy Digital Downloads are installed, start the plugin */
	if ( $has_dependencies ) {
	
		new Charitable_FES( __FILE__ );

	}
}

add_action( 'plugins_loaded', 'charitable_fes_load', 1 );

/**
 * Activate plugin. 
 *
 * @return 	void
 * @since 	1.0.0
 */
function charitable_fes_activate() {
	require_once( 'includes/class-charitable-fes-roles.php' );

	Charitable_FES_Roles::add_roles();

	add_action( 'init', 'flush_rewrite_rules', 100 );
}

register_activation_hook( __FILE__, 'charitable_fes_activate' );
add_action( 'charitable_install', 'charitable_fes_activate' );	

/**
 * Deactivate plugin. 
 *
 * @return 	void
 * @since 	1.0.0
 */
function charitable_fes_deactivate() {
	require_once( 'includes/class-charitable-fes-roles.php' );

	Charitable_FES_Roles::remove_caps();
}

register_deactivation_hook( __FILE__, 'charitable_fes_deactivate' );