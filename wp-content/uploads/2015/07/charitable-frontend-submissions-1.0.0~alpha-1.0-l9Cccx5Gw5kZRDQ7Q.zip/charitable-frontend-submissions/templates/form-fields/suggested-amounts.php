<?php
/**
 * The template used to display the suggested amounts field.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 * @version 1.0.0
 */

if ( ! isset( $view_args[ 'form' ] ) || ! isset( $view_args[ 'field' ] ) ) {
	return;
}

$form 		= $view_args[ 'form' ];
$field 		= $view_args[ 'field' ];
$key 		= $field[ 'key' ];
$value 		= isset( $field[ 'value' ] ) ? $field[ 'value' ] : array();

if ( isset( $field[ 'value' ] ) ) {
	$value 	= $field[ 'value' ];
}
?>
<table id="charitable-campaign-suggested-donations" class="charitable-campaign-form-table">	
	<tbody>
		<?php 
		foreach ( $value as $i => $donation ) : 

			?>			
			<tr class="suggested-donation" data-index="<?php echo $i ?>">
				<td>
					<div class="charitable-form-field odd">
						<label for="<?php printf( '%s_%d_amount', $key, $i ) ?>"><?php _e( 'Amount', 'charitable-fes' ) ?></label>
						<input 
							type="text" 
							id="<?php printf( '%s_%d_amount', $key, $i ) ?>" 
							name="<?php printf( '%s[%d][amount]', $key, $i ) ?>" 
							value="<?php echo $donation['amount'] ?>" />
					</div>
					<div class="charitable-form-field even">
						<label for="<?php printf( '%s_%d_description', $key, $i ) ?>"><?php _e( 'Description (optional)', 'charitable-fes' ) ?></label>
						<input 
							type="text" 
							id="<?php printf( '%s_%d_description', $key, $i ) ?>" 
							name="<?php printf( '%s[%d][description]', $key, $i ) ?>"
							value="<?php echo $donation['description'] ?>" />						
					</div>
					<button class="remove" data-charitable-remove-row="<?php echo $i ?>">x</button>
				</td>
			</tr>		
			<?php 

		endforeach;
		?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="3"><a class="add-row" href="#" data-charitable-add-row="suggested-amount"><?php _e( 'Add a suggested amount.', 'charitable-fes' ) ?></a></td>
		</tr>
	</tfoot>
</table>