<?php
/**
 * The main Charitable FES class.
 * 
 * The responsibility of this class is to load all the plugin's functionality.
 *
 * @package		Charitable FES
 * @copyright 	Copyright (c) 2014, Eric Daams	
 * @license     http://opensource.org/licenses/gpl-1.0.0.php GNU Public License
 * @since 		1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Charitable_FES' ) ) :

/**
 * Charitable_FES
 *
 * @since 	1.0.0
 */
class Charitable_FES {

	/**
     * @var string
     */
	const VERSION = '1.0.0';

	/**
     * @var string 	A date in the format: YYYYMMDD
     */
    const DB_VERSION = '20150331';	

	/**
	 * @var Charitable_FES
	 */
	private static $instance = null;

	/**
	 * The root file of the plugin. 
	 * 
	 * @var 	string
	 * @access  private
	 */
	private $plugin_file; 

	/**
	 * The root directory of the plugin.  
	 *
	 * @var 	string
	 * @access  private
	 */
	private $directory_path;

	/**
	 * The root directory of the plugin as a URL.  
	 *
	 * @var 	string
	 * @access  private
	 */
	private $directory_url;

    /**
     * @var 	array 		Store of registered objects.  
     * @access  private
     */
    private $registry;

	/**
     * Create class instance. 
     * 
     * @return 	void
     * @since 	1.0.0
     */
	public function __construct( $plugin_file ) {
		$this->plugin_file 		= $plugin_file;
		$this->directory_path 	= plugin_dir_path( $plugin_file );
		$this->directory_url 	= plugin_dir_url( $plugin_file );
		
		add_action( 'charitable_start', array( $this, 'start' ), 5 );
	}

	/**
	 * Returns the original instance of this class. 
	 * 
	 * @return 	Charitable
	 * @since 	1.0.0
	 */
	public static function get_instance() {
		return self::$instance;
	}

	/**
	 * Run the startup sequence. 
	 *
	 * This is only ever executed once.  
	 * 
	 * @return 	void
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function start() {
		// If we've already started (i.e. run this function once before), do not pass go. 
		if ( $this->started() ) {
			return;
		}

		// Set static instance
        self::$instance = $this;

        $this->load_dependencies();

        $this->maybe_upgrade();

        $this->attach_hooks_and_filters();

        $this->maybe_start_admin();

        $this->maybe_start_public();

		/* Hook in here to do something when the plugin is first loaded */
		do_action('charitable_fes_start', $this);
	}

	/**
	 * Include necessary files.
	 * 
	 * @return 	void
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function load_dependencies() {
		require_once( $this->get_path( 'includes' ) . 'charitable-fes-core-functions.php' );
		require_once( $this->get_path( 'includes' ) . 'charitable-fes-template-functions.php' );
		require_once( $this->get_path( 'includes' ) . 'class-charitable-fes-shortcodes.php' );
		require_once( $this->get_path( 'includes' ) . 'class-charitable-fes-templates.php' );
		require_once( $this->get_path( 'includes' ) . 'class-charitable-fes-campaign-form.php' );
		require_once( $this->get_path( 'includes' ) . 'emails/class-charitable-fes-email-new-campaign.php' );
		require_once( $this->get_path( 'includes' ) . 'widgets/class-charitable-fes-campaign-creator-widget.php' );
	}

	/**
	 * Set up hook and filter callback functions.
	 * 
	 * @return 	void
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function attach_hooks_and_filters() {		
		add_action( 'init', 					array( $this, 'add_rewrite_tag' ), 5 );
		add_action( 'init', 					array( $this, 'add_rewrite_rule' ), 10 );
		add_action( 'widgets_init', 			array( $this, 'setup_widget' ) );
		add_action( 'charitable_single_campaign_before', array( $this, 'add_edit_campaign_link' ) );
		add_action( 'charitable_creator_download_donations', array( $this, 'download_donations_csv' ) );
		add_action( 'charitable_fes_start', 	array( 'Charitable_FES_Shortcodes', 'start' ) );
		add_action( 'charitable_fes_start', 	array( 'Charitable_FES_Templates', 'start' ) );
		add_action( 'charitable_save_campaign', array( 'Charitable_FES_Campaign_Form', 'save_campaign' ) );				

		add_filter( 'charitable_active_addons', array( $this, 'load_user_dashboard_addon' ) );						
		add_filter( 'charitable_emails', 		array( $this, 'register_emails' ) );
	}

	/**
	 * Start admin functionality. 
	 *
	 * @return 	void
	 * @access  private
	 * @since 	1.0.0
	 */
	private function maybe_start_admin() {
		if ( ! is_admin() ) {
			return;
		}

		require_once( $this->get_path( 'admin' ) . 'class-charitable-fes-admin.php' );

		Charitable_FES_Admin::start( $this );
	}

	/**
	 * Start publi functionality.
	 * 
	 * @return 	void
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function maybe_start_public() {
		if ( is_admin() ) {
			return;
		}

		require_once( $this->get_path( 'includes' ) . 'class-charitable-fes-public.php' );

		Charitable_FES_Public::start( $this );
	}

	/**
	 * Returns whether we are currently in the start phase of the plugin. 
	 *
	 * @return 	bool
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function is_start() {
		return current_filter() == 'charitable_fes_start';
	}

	/**
	 * Returns whether the plugin has already started.
	 * 
	 * @return 	bool
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function started() {
		return did_action( 'charitable_fes_start' ) || current_filter() == 'charitable_fes_start';
	}

	/**
	 * Returns the plugin's version number. 
	 *
	 * @return 	string
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function get_version() {
		return self::VERSION;
	}

	/**
	 * Returns plugin paths. 
	 *
	 * @param 	string $path 			// If empty, returns the path to the plugin.
	 * @param 	bool $absolute_path 	// If true, returns the file system path. If false, returns it as a URL.
	 * @return 	string
	 * @since 	1.0.0
	 */
	public function get_path($type = '', $absolute_path = true ) {		
		$base = $absolute_path ? $this->directory_path : $this->directory_url;

		switch( $type ) {
			case 'includes' : 
				$path = $base . 'includes/';
				break;

			case 'admin' :
				$path = $base . 'includes/admin/';
				break;

			case 'templates' : 
				$path = $base . 'templates/';
				break;

			case 'assets' : 
				$path = $base . 'assets/';
				break;				

			case 'directory' : 
				$path = $base;
				break;

			default :
				$path = $this->plugin_file;
		}

		return $path;
	}

	/**
	 * Stores an object in the plugin's registry.
	 *
	 * @param 	mixed 		$object
	 * @return 	void
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function register_object( $object ) {
		if ( ! is_object( $object ) ) {
			return;
		}

		$class = get_class( $object );

		$this->registry[ $class ] = $object;
	}

	/**
	 * Returns a registered object.
	 * 
	 * @param 	string 		$class 	The type of class you want to retrieve.
	 * @return 	mixed 				The object if its registered. Otherwise false.
	 * @access 	public
	 * @since 	1.0.0
	 */
	public function get_object( $class ) {
		return isset( $this->registry[ $class ] ) ? $this->registry[ $class ] : false;
	}

	/**
	 * Perform upgrade routine if necessary. 
	 *
	 * @return 	void
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function maybe_upgrade() {
		$db_version = get_option( 'charitable_fes_version' );

		if ( $db_version !== self::VERSION ) {		

			require_once( charitable()->get_path( 'includes' ) . 'class-charitable-upgrade.php' );
			require_once( $this->get_path( 'includes' ) . 'class-charitable-fes-upgrade.php' );

			Charitable_FES_Upgrade::upgrade_from( $db_version, self::VERSION );
		}
	}

	/**
	 * Runs on plugin activation. 
	 *
	 * @see 	register_activation_hook
	 * @return 	void
	 * @access 	public
	 * @since	1.0.0
	 */
	public function activate() {
		add_action( 'init', 'flush_rewrite_rules', 100 );
	}

	/**
	 * Make sure the Frontend Dashboard addon for Charitable is activated. 
	 *
	 * @param 	array 		$active_addons
	 * @return 	array 
	 * @access  public
	 * @since 	1.0.0
	 */
	public function load_user_dashboard_addon( $active_addons ) {
		if ( ! in_array( 'charitable-user-dashboard', $active_addons ) ) {
			$active_addons[] = 'charitable-user-dashboard';
		}

		return $active_addons;
	}

	/**
	 * Register additional emails.  
	 *
	 * @param 	string[] 	$emails
	 * @return  string[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function register_emails( $emails ) {
		$emails[ 'new_campaign' ] = 'Charitable_FES_Email_New_Campaign';

		return $emails;
	}

	/**
	 * Add custom rewrite tag. 
	 *
	 * @return  void
	 * @access  public
	 * @since   1.0.0
	 */
	public function add_rewrite_tag() {
		add_rewrite_tag('%campaign_id%', '([0-9]+)' );
	}

	/**
	 * Add endpoint for editing campaigns.	
	 *
	 * @return  void
	 * @access  public
	 * @since   1.0.0
	 */
	public function add_rewrite_rule() {
		add_rewrite_rule('(.?.+?)/([0-9]+)/edit/?$','index.php?pagename=$matches[1]&campaign_id=$matches[2]','top');
	}

	/**
	 * Set up campaign creator widget. 
	 *
	 * @return  void
	 * @access  public
	 * @since   1.0.0
	 */
	public function setup_widget() {
		register_widget( 'Charitable_FES_Campaign_Creator_Widget' );
	}

	/**
	 * Add campaign editing link to the top of a campaign when viewing on the frontend. 
	 *
	 * @return  boolean 	True if the template was displayed. False otherwise.	
	 * @access  public
	 * @since   1.0.0
	 */
	public function add_edit_campaign_link() {
		/* Display the edit link if the campaign creator is looking at their own campaign. */
		if ( is_single() && 'campaign' == get_post_type() && charitable_is_current_campaign_creator( get_the_ID() ) ) {

			charitable_fes_template( 'edit-campaign-link.php' );

			return true;
			
		}

		return false;
	}

	/**
	 * Download a CSV file with the donation history for the given campaign. 
	 *
	 * @return  void
	 * @access  public
	 * @since   1.0.0
	 */
	public function download_donations_csv() {
		if ( ! isset( $_GET[ 'campaign_id' ] ) ) {
			return false;
		}

		$campaign_id = $_GET[ 'campaign_id' ];

		/* Check for nonce existence. */
		if ( ! charitable_verify_nonce( 'download_donations_nonce', 'download_donations_' . $campaign_id ) ) {
	        return false;
	    }

	    if ( ! charitable_is_current_campaign_creator( $campaign_id ) ) {
	    	return false;
	    } 

	    require_once( charitable()->get_path( 'admin' ) . 'reports/class-charitable-export-donations.php' );

	    add_filter( 'charitable_export_capability', '__return_true' );

	    $export_args = apply_filters( 'charitable_fes_campaign_creator_donations_export_args', array(
	    	'campaign_id'	=> $campaign_id
	    ) );	   		

	    new Charitable_Export_Donations( $export_args );

	    exit();
	}

	/**
	 * Throw error on object clone. 
	 *
	 * This class is specifically designed to be instantiated once. You can retrieve the instance using charitable()
	 *
	 * @since 	1.0.0
	 * @access 	public
	 * @return 	void
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'charitable-fes' ), '1.0.0' );
	}

	/**
	 * Disable unserializing of the class. 
	 *
	 * @since 	1.0.0
	 * @access 	public
	 * @return 	void
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'charitable-fes' ), '1.0.0' );
	}			
}

endif; // End if class_exists check