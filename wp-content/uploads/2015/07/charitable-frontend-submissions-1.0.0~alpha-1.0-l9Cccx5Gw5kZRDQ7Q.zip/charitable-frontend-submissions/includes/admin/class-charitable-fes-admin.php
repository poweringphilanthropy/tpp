<?php
/**
 * Class responsible for adding Charitable FES settings in admin area.
 *
 * @package		Charitable FES/Classes/Charitable_FES_Admin
 * @version 	1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_FES_Admin' ) ) : 

/**
 * Charitable_FES_Admin
 *
 * @since 		1.0.0
 */
class Charitable_FES_Admin {

	/**
	 * Charitable_FES object. 
	 *
	 * @var 	Charitable_FES
	 * @access  private
	 */
	private $charitable_fes;

	/**
	 * Instantiate the class, but only during the start phase.
	 * 
	 * @param 	Charitable_FES 		$charitable_fes
	 * @return 	void
	 * @static 
	 * @access 	public
	 * @since 	1.0.0
	 */
	public static function start( Charitable_FES $charitable_fes ) {
		if ( $charitable_fes->started() ) {
			return;
		}

		new Charitable_FES_Admin();
	}

	/**
	 * Set up the class. 
	 * 
	 * Note that the only way to instantiate an object is with the charitable_start method, 
	 * which can only be called during the start phase. In other words, don't try 
	 * to instantiate this object. 
	 *
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function __construct() {
		$this->attach_hooks_and_filters();
	}

	/**
	 * Set up hooks and filters. 
	 *
	 * @return 	void
	 * @access  private
	 * @since 	1.0.0
	 */
	private function attach_hooks_and_filters() {
		add_action( 'admin_enqueue_scripts', 			array( $this, 'load_assets' ) );
		add_filter( 'charitable_campaign_meta_boxes', 	array( $this, 'register_payment_meta_box' ) );
		add_filter( 'charitable_admin_view_path', 		array( $this, 'admin_view_path' ), 10, 3 );
		add_filter( 'charitable_settings_tabs', 		array( $this, 'add_ambassadors_section' ) );
		add_filter( 'charitable_settings_tab_fields', 	array( $this, 'register_ambassadors_section_fields' ) );
		add_filter( 'charitable_settings_fields_general', array( $this, 'add_campaign_submission_page_settings' ) );		

		/* If you want to unhook any of the registered events above, use this hook. */
		do_action( 'charitable_fes_admin_start', $this );
	}

	/**
	 * Load stylesheet and any Javascript. 
	 *
	 * @global 	WP_Scripts 		$wp_scripts
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function load_assets() {
		global $wp_scripts;

		/* The following styles are only loaded on Charitable screens. */
		$screen = get_current_screen();

		if ( in_array( $screen->id, array( 'campaign' ) ) ) {		
		
			wp_register_style( 'charitable-fes-admin', charitable_fes()->get_path( 'assets', false ) . 'css/charitable-fes-admin.css', array( 'charitable-admin' ), charitable_fes()->get_version() );
			wp_enqueue_style( 'charitable-fes-admin' );

		}
	}

	/**
	 * Add a payment information meta box to the campaign page. 
	 *
	 * @param 	array 		$meta_boxes
	 * @return 	array 
	 * @access  public
	 * @since 	1.0.0
	 */
	public function register_payment_meta_box( $meta_boxes ) {
		$meta_boxes[] = array(
			'id'				=> 'campaign-creator', 
			'title'				=> __( 'Campaign Creator', 'charitable-fes' ), 
			'context'			=> 'campaign-advanced', 
			'priority'			=> 'high', 
			'view'				=> 'metaboxes/campaign-creator', 
			'view_source'		=> 'charitable-fes'
		);

		return $meta_boxes;
	}

	/**
	 * Set the admin view path to our views folder for any of our views.  
	 *
	 * @param 	string 		$path
	 * @param 	string 		$view
	 * @param 	array 		$view_args
	 * @return 	string
	 * @access  public
	 * @since 	1.0.0
	 */
	public function admin_view_path( $path, $view, $view_args ) {
		if ( isset( $view_args[ 'view_source' ] ) && 'charitable-fes' == $view_args[ 'view_source' ] ) {

			$path = charitable_fes()->get_path( 'admin' ) . 'views/' . $view . '.php';

		}

		return $path;
	}

	/**
	 * Add Ambassadors tab to the Charitable settings UI.
	 *
	 * @param 	string[]
	 * @return  string[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function add_ambassadors_section( $sections ) {
		$keys 	= array_keys( $sections );
		$values = array_values( $sections );

		array_splice( $keys, 4, 0, 'ambassadors' );
		array_splice( $values, 4, 0, __( 'Ambassadors', 'charitable-fes' ) );		
		
		return array_combine( $keys, $values );
	}

	/**
	 * Register fields to add to the Ambassadors tab. 
	 *
	 * @return  array[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function register_ambassadors_section_fields( $fields ) {
		$fields[ 'ambassadors' ] = $this->get_ambassadors_settings();
		return $fields;
	}

	/**
	 * Add settings to the Forms tab in Charitable settings. 
	 *
	 * @param 	arary[] 	$fields
	 * @return  array[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function get_ambassadors_settings() {
		$fields = apply_filters( 'charitable_settings_fields_ambassadors', array(
			'section_campaign_form' => array(
				'title'				=> __( 'Campaign Submission Form', 'charitable-fes' ), 
				'type'				=> 'heading', 
				'priority'			=> 2
			), 
			'require_user_account_for_campaign_submission' => array(
				'title'				=> __( 'Require User Account', 'charitable-fes' ),
				'type'				=> 'checkbox',
				'priority'			=> 4,
				'default'			=> 1, 
				'help'				=> __( 'Require users to be logged in before they can submit a campaign.', 'charitable-fes' )
			),
			'campaign_length_min' => array(
				'title'				=> __( 'Minimum Campaign Length', 'charitable-fes' ), 
				'type'				=> 'number', 
				'priority'			=> 6, 
				'default'			=> 0, 
				'min'				=> 0,
				'required'			=> false,
				'help'              => __( 'The minimum number of days that a user-submitted campaign can run for. Leave empty or set to 0 for no minimum length.', 'charitable-fes' ), 
                'class'             => 'short'				
			), 
			'campaign_length_max' => array(
				'title'				=> __( 'Maximum Campaign Length', 'charitable-fes' ), 
				'type'				=> 'number', 
				'priority'			=> 8, 
				'required'			=> false,
				'min'				=> 0,
				'help'              => __( 'The maximum number of days that a user-submitted campaign can run for. Leave blank to allow users to choose any end date.', 'charitable-fes' ), 
                'class'             => 'short'
			), 
			'allow_creators_donation_export' => array(
				'title'				=> __( 'Allow Campaign Creators to Export Donation History', 'charitable-fes' ), 
				'type'				=> 'radio',
				'priority'			=> 10,
				'required'			=> true,
				'options'			=> array(
					'1'				=> __( 'Yes', 'charitable-fes' ), 
					'0'				=> __( 'No', 'charitable-fes' )
				),
				'default'			=> '0', 
				'help'				=> __( 'Allow campaign creators to export a CSV file containing the donor name, email address and amount of all donations made to their campaign.', 'charitable-fes' )
			)
		) );

		return $fields;
	}

	/**
	 * Add the campaign submission page settings to the General settings tab in Charitable.	
	 *	
	 * @param 	array[]		$fields
	 * @return  array[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function add_campaign_submission_page_settings( $fields ) {
		$new_fields = apply_filters( 'charitable_fes_campaign_submission_page_setting', array(
			'campaign_submission_page'  => array(
                'title'     => __( 'Campaign Submission Page', 'charitable-fes' ), 
                'type'      => 'select', 
                'priority'  => 28, 
                'options'   => charitable_get_helper( 'admin_settings' )->get_pages(), 
                'help'      => __( 'The static page should contain the <code>[charitable_submit_campaign]</code> shortcode.', 'charitable-fes' )
            ),
            'campaign_submission_success_page'  => array(
                'title'     => __( 'Campaign Submission Success Page', 'charitable-fes' ), 
                'type'      => 'select', 
                'priority'  => 29,
                'options'	=> array(
                	'home'  => __( 'Homepage', 'charitable-fes' ),
                	'pages' => array(
                		'options' => charitable_get_helper( 'admin_settings' )->get_pages(), 
                		'label'     => __( 'Choose a Static Page', 'charitable-fes' )
                	)
                ),               
                'help'      => __( 'This is the page to which users are redirected after submitting a campaign.', 'charitable-fes' )
            )
		) );

		$fields = array_merge( $fields, $new_fields );

		return $fields;
	}
}

endif; // End class_exists check