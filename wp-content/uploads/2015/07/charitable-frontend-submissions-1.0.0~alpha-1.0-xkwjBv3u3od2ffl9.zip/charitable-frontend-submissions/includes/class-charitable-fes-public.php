<?php
/**
 * Class responsible for loading any Charitable FES functionality that is only required on the public side of the site.
 *
 * @package		Charitable FES/Classes/Charitable_FES_Public
 * @version 	1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_FES_Public' ) ) : 

/**
 * Charitable_FES_Public
 *
 * @since 		1.0.0
 */
class Charitable_FES_Public {

	/**
	 * Instantiate the class, but only during the start phase.
	 * 
	 * @param 	Charitable_FES 		$charitable_fes
	 * @return 	void
	 * @static 
	 * @access 	public
	 * @since 	1.0.0
	 */
	public static function start( Charitable_FES $charitable_fes ) {
		if ( $charitable_fes->started() ) {
			return;
		}

		$charitable_fes->register_object( new Charitable_FES_Public( $charitable_fes ) );
	}

	/**
	 * Set up the class. 
	 * 
	 * Note that the only way to instantiate an object is with the charitable_start method, 
	 * which can only be called during the start phase. In other words, don't try 
	 * to instantiate this object. 
	 *
	 * @access 	private
	 * @since 	1.0.0
	 */
	private function __construct() {
		$this->load_dependencies();
		$this->attach_hooks_and_filters();
	}

	/**
	 * Load required files. 
	 *
	 * @return 	void
	 * @access  private
	 * @since 	1.0.0
	 */
	private function load_dependencies() {
		require_once( charitable_fes()->get_path( 'includes' ) . 'class-charitable-fes-template.php' );
	}

	/**
	 * Set up hooks and filters. 
	 *
	 * @return 	void
	 * @access  private
	 * @since 	1.0.0
	 */
	private function attach_hooks_and_filters() {
		add_filter( 'charitable_javascript_vars', array( $this, 'add_charitable_javascript_vars' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	/**
	 * Add additional variables to the global CHARITABLE javascript object. 
	 *
	 * @param 	mixed[] $vars
	 * @return  mixed[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function add_charitable_javascript_vars( $vars ) {
		$vars[ 'suggested_amount_label' ] = __( 'Amount', 'charitable-fes' );
		$vars[ 'suggested_amount_description_label' ] = __( 'Description (optional)', 'charitable-fes' );
		return $vars;
	}

	/**
	 * Load stylesheets & scripts on the frontend. 
	 * 
	 * @return 	void
	 * @since 	1.0.0
	 */
	public function enqueue_scripts() {
		$handle = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '.js' : '.min.js';
		wp_register_script( 'charitable-fes-campaign-submission', charitable_fes()->get_path( 'assets', false ) . 'js/charitable-fes-campaign-submission' . $handle, array( 'jquery' ), '1.0.0', true );
	}
}

endif; // End class_exists check