<?php
/**
 * Class that manages the display and processing of the campaign form.
 *
 * @package		Charitable FES/Classes/Charitable_FES_Campaign_Form
 * @version 	1.0.0
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Charitable_FES_Campaign_Form' ) ) : 

/**
 * Charitable_FES_Campaign_Form
 *
 * @since 		1.0.0
 */
class Charitable_FES_Campaign_Form extends Charitable_Form {

	/**
	 * Shortcode parameters. 
	 *
	 * @var 	array
	 * @access  protected
	 */
	protected $shortcode_args;

	/**
	 * @var 	string
	 */
	protected $nonce_action = 'charitable_campaign_submission';

	/**
	 * @var 	string
	 */
	protected $nonce_name = '_charitable_campaign_submission_nonce';

	/**
	 * Action to be executed upon form submission. 
	 *
	 * @var 	string
	 * @access  protected
	 */
	protected $form_action = 'save_campaign';

	/**
	 * The current user. 
	 *
	 * @var 	Charitable_User
	 * @access  protected
	 */
	protected $user;

	/**
	 * Create class object.
	 * 
	 * @param 	array 		$args 		User-defined shortcode attributes.
	 * @access 	public
	 * @since	1.0.0
	 */
	public function __construct( $args = array() ) {	
		$this->id = uniqid();	
		$this->shortcode_args = $args;		
		$this->attach_hooks_and_filters();	
	}

	/**
	 * Set up callback methods for actions & filters. 
	 *
	 * @return  void
	 * @access  protected
	 * @since   1.0.0
	 */
	protected function attach_hooks_and_filters() {
		parent::attach_hooks_and_filters();
		
		add_filter( 'charitable_campaign_submission_fields', array( $this, 'filter_non_editable_fields' ), 5 );
		add_filter( 'charitable_form_field_template', array( $this, 'use_charitable_fes_template' ), 10, 2 );		
		add_filter( 'charitable_campaign_meta_key', array( $this, 'set_thumbnail_id_meta_key' ), 10, 2 );
		add_filter( 'charitable_campaign_submission_meta_data', array( $this, 'save_picture' ), 10, 3 );
		add_filter( 'charitable_campaign_submission_meta_data', array( $this, 'get_end_date' ), 10, 3 );
		add_filter( 'charitable_campaign_submission_fields_map', array( $this, 'save_end_date' ) );
		add_filter( 'charitable_sanitize_campaign_meta__campaign_length', array( $this, 'sanitize_campaign_length' ) );
		add_filter( 'posts_where', array( $this, 'hide_other_users_media' ) );
	}

	/**
	 * Return the current user's Charitable_User object.  
	 *
	 * @return 	Charitable_User
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_user() {
		if ( ! isset( $this->user ) ) {
			$this->user = new Charitable_User( wp_get_current_user() );
		}

		return $this->user;
	}

	/**
	 * Return the current campaign's Charitable_Campaign object.  
	 *
	 * @return 	Charitable_Campaign|false
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_campaign() {		
		if ( ! isset( $this->campaign ) ) {

			if ( isset( $_POST[ 'ID' ] ) ) {
				$campaign_id = $_POST[ 'ID' ];
			}
			else {
				$campaign_id = get_query_var( 'campaign_id', false );
			}
			
			$this->campaign = $campaign_id ? new Charitable_Campaign( $campaign_id ) : false;
		}

		return $this->campaign;
	}

	/**
	 * Returns the value of a particular key. 	
	 *
	 * @return  mixed
	 * @access  public
	 * @since   1.0.0
	 */
	public function get_campaign_value(	$key ) {
		if ( isset( $_POST[ $key ] ) ) {
            return $_POST[ $key ];
        }

		$campaign = $this->get_campaign();
		$value = "";

		if ( $campaign ) {
			switch ( $key ) {
				case 'ID' : 
					$value = $campaign->ID;
					break;

				case 'post_title' : 
					$value = $campaign->post_title;
					break;

				case 'goal' : 
					$value = $campaign->get_goal();
					break;

				case 'campaign_category' : 
					$value = wp_get_object_terms( $campaign->ID, 'campaign_category', array( 'fields' => 'ids' ) );
					break;

				case 'campaign_tag' : 
					$value = wp_get_object_terms( $campaign->ID, 'campaign_tag', array( 'fields' => 'ids' ) );
					break;

				case 'post_content' : 
					$value = $campaign->post_content;
					break;

				case 'image' : 
					$thumbnail_id = get_post_thumbnail_id( $campaign->ID );

					if ( empty( $thumbnail_id ) ) {
						$value = '';
					}
					else {
						$src = wp_get_attachment_image_src( $thumbnail_id );
						$value = $src[ 0 ];
					}
					break;

				case 'suggested_amounts' : 
					$value = $campaign->get( 'suggested_donations' );
					break;

				default : 
					$value = $campaign->get( $key ); // Fallback method. 					
			}
		}
		
		return apply_filters( 'charitable_campaign_value', $value, $key, $campaign );
	}

	/**
	 * Return the campaign fields. 
	 *
	 * @return 	array[]
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_campaign_fields() {		
		$campaign_fields = apply_filters( 'charitable_campaign_submission_campaign_fields', array(
			'ID' => array(
				'type'			=> 'hidden', 
				'priority'		=> 0, 
				'value'			=> $this->get_campaign_value( 'ID' ), 
				'data_type'		=> 'core'
			),
			'post_title' => array( 
				'label' 		=> __( 'Campaign Name', 'charitable-fes' ), 				
				'type'			=> 'text', 
				'priority'		=> 2, 
				'required'		=> true, 
				'fullwidth' 	=> true, 
				'value'			=> $this->get_campaign_value( 'post_title' ), 
				'data_type'		=> 'core', 
				'editable'		=> false
			),
			'description' => array(
				'label'			=> __( 'Short Description', 'charitable-fes' ), 
				'type'			=> 'textarea', 
				'priority'		=> 4, 
				'required' 		=> true, 
				'fullwidth' 	=> true, 
				'placeholder' 	=> __( 'A short, snappy description of your campaign', 'charitable-fes' ), 
				'value'			=> $this->get_campaign_value( 'description' ), 
				'data_type'		=> 'meta'
			),
			'goal' => array(
				'label'			=> __( 'Fundraising Goal ($)', 'charitable-fes' ), 
				'type'			=> 'number',
				'priority'		=> 6, 
				'min'           => 0, 
				'required'		=> false, 
				'placeholder'  	=> '&#8734;', 
				'value'			=> $this->get_campaign_value( 'goal' ), 
				'data_type'		=> 'meta',
				'editable'		=> false
			),
			'length' => array(
				'label'			=> __( 'Length', 'charitable-fes' ), 
				'type'			=> 'number',
				'priority'		=> 8, 
				'required'		=> true, 
				'placeholder'	=> apply_filters( 'charitable_default_campaign_length', charitable_get_option( 'campaign_length_min' ), charitable_get_option( 'campaign_length_max' ), charitable_get_option( 'campaign_length_min' ) ), 
				'min'			=> charitable_get_option( 'campaign_length_min' ), 
				'max'			=> charitable_get_option( 'campaign_length_max' ), 
				'value'			=> $this->get_campaign_value( 'length' ), 
				'data_type'		=> 'meta',
				'editable'		=> false
			),
			'campaign_category' => array(
				'label' 		=> __( 'Categories', 'charitable-fes' ), 
				'type'			=> 'multi-checkbox',
				'priority'		=> 10, 
				'required'		=> true,
				'options'		=> get_terms( 'campaign_category', array( 'hide_empty' => false, 'fields' => 'id=>name' ) ), 
				'value'			=> $this->get_campaign_value( 'campaign_category' ), 
				'data_type'		=> 'taxonomy'
			),
			'campaign_tag' => array(
				'label' 		=> __( 'Tags', 'charitable-fes' ), 
				'type'			=> 'multi-checkbox',
				'priority'		=> 12, 
				'required'		=> false,
				'options'		=> get_terms( 'campaign_tag', array( 'hide_empty' => false, 'fields' => 'id=>name' ) ), 
				'value'			=> $this->get_campaign_value( 'campaign_tag' ), 
				'data_type'		=> 'taxonomy'
			),
			'post_content' => array(
				'label'			=> __( 'Full Description', 'charitable-fes' ), 
				'type'			=> 'editor', 
				'priority'		=> 14, 
				'required' 		=> true, 
				'fullwidth'		=> true, 
				'value'			=> $this->get_campaign_value( 'post_content' ), 
				'data_type'		=> 'core'
			),
			'image'	=> array(
				'label'			=> __( 'Featured Image', 'charitable-fes' ), 
				'type'			=> 'picture', 
				'priority'		=> 16, 
				'required'		=> false, 
				'fullwidth'		=> true, 
				'value'			=> $this->get_campaign_value( 'image' ), 
				'data_type'		=> 'meta'
			),
			'video'	=> array(
				'label'			=> __( 'Video', 'charitable-fes' ), 
				'type'			=> 'textarea', 
				'priority' 		=> 18, 
				'required'		=> false, 
				'placeholder' 	=> __( 'Link or embed code for a video of your campaign', 'charitable-fes' ), 
				'fullwidth' 	=> true, 
				'value'			=> $this->get_campaign_value( 'video' ), 
				'data_type'		=> 'meta'
			)
		), $this );

		uasort( $campaign_fields, 'charitable_priority_sort' );

		return $campaign_fields;
	}

	/**
	 * Return the donation options fields.  
	 *
	 * @return  array[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function get_donation_options_fields() {
		$donation_fields = apply_filters( 'charitable_campaign_submission_donation_options_fields', array(
			'donation_options'	=> array(
				'type'			=> 'paragraph',
				'priority'		=> 22, 
				'fullwidth'		=> true, 
				'content'		=> __( 'When people make a donation to your campaign, they will be able to donate any amount they choose. You can also provide suggested donation amounts in the table below.', 'charitable-fes' )
			),
			'suggested_donations' => array(
				'type'			=> 'suggested-donations',
				'priority'		=> 24,
				'fullwidth'		=> true, 
				'value'			=> $this->get_campaign_value( 'suggested_donations' ), 
				'data_type'		=> 'meta'
			),
			'allow_custom_donations' => array(
				'type'			=> 'hidden',
				'priority'		=> 26,
				'fullwidth'		=> true, 
				'value'			=> 1, 
				'data_type'		=> 'meta'
			)
		), $this );

		uasort( $donation_fields, 'charitable_priority_sort' );

		return $donation_fields;
	}

	/**
	 * Return the core user fields.  	
	 *
	 * @return 	array[]
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_user_fields() {
		$user_fields = apply_filters( 'charitable_campaign_submission_user_fields', array(
			'first_name' => array( 
				'label' 		=> __( 'First name', 'charitable-fes' ), 
				'type'			=> 'text', 
				'priority'		=> 42, 
				'required'		=> true, 
				'value'			=> $this->get_user()->first_name, 
				'data_type'		=> 'user'
			),
			'last_name' => array( 
				'label' 		=> __( 'Last name', 'charitable-fes' ), 				
				'type'			=> 'text', 
				'priority'		=> 44, 
				'required'		=> true, 
				'value'			=> $this->get_user()->last_name, 
				'data_type'		=> 'user'
			),
			'user_email' => array(
				'label' 		=> __( 'Email', 'charitable-fes' ), 
				'type'			=> 'email',
				'required' 		=> true, 
				'priority'		=> 46, 
				'value' 		=> $this->get_user()->user_email, 
				'data_type'		=> 'user'
			),
			'organisation' => array(
				'label' 		=> __( 'Organisation', 'charitable-fes' ), 				
				'type'			=> 'text', 
				'priority'		=> 48, 
				'required'		=> false, 
				'value' 		=> $this->get_user()->organisation, 
				'data_type'		=> 'user'
			), 
			'city' => array( 
				'label' 		=> __( 'City', 'charitable-fes' ), 			
				'type'			=> 'text', 
				'priority'		=> 50, 
				'required'		=> false, 
				'value' 		=> $this->get_user()->city, 
				'data_type'		=> 'user'
			),
			'state' => array( 
				'label' 		=> __( 'State', 'charitable-fes' ), 				
				'type'			=> 'text', 
				'priority'		=> 52, 
				'required'		=> false, 
				'value' 		=> $this->get_user()->state, 
				'data_type'		=> 'user'
			),
			'country' => array( 
				'label' 		=> __( 'Country', 'charitable-fes' ), 				
				'type'			=> 'select', 
				'options' 		=> charitable_get_location_helper()->get_countries(), 
				'priority'		=> 54, 
				'required'		=> false, 
				'value' 		=> $this->get_user()->country, 
				'data_type'		=> 'user'
			)
		), $this );

		uasort( $user_fields, 'charitable_priority_sort' );

		return $user_fields;
	}

	/**
	 * Payment fields.  
	 *
	 * @return 	array[]
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_payment_fields() {	
		$payment_fields = apply_filters( 'charitable_campaign_submission_payment_fields', array(
			'paypal' => array(
				'label'			=> __( 'Your PayPal Account', 'charitable-fes' ), 
				'description' 	=> __( 'When the campaign is finished, you will be paid with your PayPal account.', 'charitable-fes' ), 
				'type'			=> 'email',
				'priority'		=> 42, 
				'value'			=> $this->get_user()->paypal, 
				'data_type'		=> 'user'
			)
		), $this );

		uasort( $payment_fields, 'charitable_priority_sort' );

		return $payment_fields;
	}

	/**
	 * Profile fields to be displayed.  	
	 *
	 * @return 	array[]
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_fields() {
		$fields = apply_filters( 'charitable_campaign_submission_fields', array(
			'campaign_fields' => array(
				'legend'		=> __( 'Campaign Details', 'charitable-fes' ), 
				'type'			=> 'fieldset', 
				'fields'		=> $this->get_campaign_fields(),
				'priority'		=> 0
			), 
			'donation_fields' => array(
				'legend'		=> __( 'Donation Options', 'charitable-fes' ), 
				'type'			=> 'fieldset',
				'fields'		=> $this->get_donation_options_fields(),
				'priority'		=> 20,
			),
			'user_fields' => array(
				'legend'		=> __( 'Your Details', 'charitable-fes' ), 
				'type'			=> 'fieldset',
				'fields'		=> $this->get_user_fields(),
				'priority'		=> 40 
			), 
			'payment_fields' => array(
				'legend'		=> __( 'Payment Details', 'charitable-fes' ), 
				'type'			=> 'fieldset', 
				'fields'		=> $this->get_payment_fields(), 
				'priority'		=> 60
			)
		), $this );				

		uasort( $fields, 'charitable_priority_sort' );

		return $fields;
	}

	/**
	 * Return the submit buttons.
	 *
	 * @return  string
	 * @access  public
	 * @since   1.0.0
	 */
	public function get_submit_buttons() {
		$secondary 	= sprintf( '<input class="button button-secondary" type="submit" name="preview-campaign" value="%s" />', esc_attr( __( 'Preview', 'charitable-fes' ) ) );
		$primary_text = false === $this->get_campaign() || 'draft' == $this->get_campaign()->post_status 
			? __( 'Submit Campaign', 'charitable-fes' ) 
			: __( 'Update Campaign', 'charitable-fes' );
		$primary 	= sprintf( '<input class="button button-primary" type="submit" name="submit-campaign" value="%s" />', esc_attr( $primary_text ) );
		$output 	= sprintf( "%s %s", $secondary, $primary );
		return apply_filters( 'charitable_fes_form_submission_buttons', $output, $this, $secondary, $primary );
	}

	/**
	 * Remove non-editable fields when we are editing a published campaign. 
	 *
	 * @return  array[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function filter_non_editable_fields( $fields ) {
		if ( false == $this->get_campaign() || in_array( $this->get_campaign()->post_status, array( 'pending', 'draft' ) ) ) {
			return $fields;
		}

		foreach ( $fields as $section_key => $section ) {

			if ( isset( $section[ 'fields' ] ) ) {

				foreach ( $section[ 'fields' ] as $field_key => $field ) {

					if ( isset( $field[ 'editable' ] ) && false === $field[ 'editable' ] ) {

						unset( $fields[ $section_key ][ 'fields' ][ $field_key ] );

					}

				}

			}

		}

		return $fields;
	}

	/**
	 * Returns all fields as a merged array. 
	 *
	 * @return 	array[]
	 * @access  public
	 * @since 	1.0.0
	 */
	public function get_merged_fields() {
		$fields = array();

		foreach ( $this->get_fields() as $section ) {
			$section_fields = isset( $section[ 'fields' ] ) ? $section[ 'fields' ] : array();
			$fields = array_merge( $fields, $section_fields );
		}

		return $fields;
	}

	/**
	 * Use our template object for the 'suggested-donations' field. 
	 *
	 * @return  Charitable_Fes_Template|false 
	 * @access  public
	 * @since   1.0.0
	 */
	public function use_charitable_fes_template( $template, $field ) {
		if ( 'suggested-donations' == $field[ 'type' ] ) {
			$template = charitable_fes_template( $this->get_template_name( $field ), false );
		}

		return $template;
	}

	/**
	 * Verify that the current user can create or edit this campaign. 
	 *
	 * @return  boolean
	 * @access  public
	 * @since   1.0.0
	 */
	public function current_user_can_edit_campaign() {
		return true;
	}

	/**
	 * Organize fields by data type, also filtering out unused parameters (we just need the key and the type). 
	 *
	 * @param 	string 		$key
	 * @param 	array 		$field	 
	 * @param 	array 		$ret
	 * @return  array[]
	 * @access  public
	 * @since   1.0.0
	 */
	public function sort_field_by_data_type( $key, $field, $ret ) {		
		/* Filter out paragraphs and fields without a type. */
		if ( ! isset( $field[ 'type' ] ) || 'paragraph' == $field[ 'type' ] ) {
			return $ret;
		}

		/* Get the data type. Default to meta if no type is set. */
		$data_type = isset( $field[ 'data_type' ] ) ? $field[ 'data_type' ] : 'meta';

		$ret[ $data_type ][ $key ] = $field[ 'type' ];

		return $ret;
	}

	/**
	 * Save campaign after form submission. 
	 *
	 * @return 	void
	 * @access  public
	 * @static
	 * @since 	1.0.0
	 */
	public static function save_campaign() {
		$form = new Charitable_FES_Campaign_Form();

		if ( ! $form->validate_nonce() ) {
			return;
		}

		/* Confirm that the current user has permission to create/edit this campaign. */
		if ( ! $form->current_user_can_edit_campaign() ) {
			return;
		}

		/* If required fields are missing, stop. */
		if ( ! $form->check_required_fields( $form->get_merged_fields() ) ) {
			return;
		}	

		/* Organize fields into multi-dimensional array of core, meta, taxonomy and user data. */
		$fields = array();

		foreach ( $form->get_merged_fields() as $key => $field ) {
			$fields = $form->sort_field_by_data_type( $key, $field, $fields );
		}				

		/* Allow plugins/themes to filter the submitted values prior to saving. */
		$submitted = apply_filters( 'charitable_campaign_submission_values', $_POST, $fields, $form );

		/* Allow plugins/themes to filter the fields that will be saved by the campaign. */
		$fields = apply_filters( 'charitable_campaign_submission_fields_map', $fields, $submitted, $form );

		/* Save user data */
		$user_id = $form->save_user_data( $fields, $submitted );

		/* Save campaign data */
		$campaign_id = $form->save_core_campaign_data( $fields, $submitted, $user_id );
				
		/* Save taxonomy data */
		$form->save_campaign_taxonomies( $fields, $submitted, $campaign_id );

		/* Save campaign meta */
		$form->save_campaign_meta( $fields, $submitted, $campaign_id );

		/* Allow plugins/themes to do something now. */
		do_action( 'charitable_campaign_submission_save', $submitted, $campaign_id, $user_id, $form );
				
		wp_safe_redirect( $form->get_redirect_url( $submitted, $campaign_id, $user_id ) );

		exit();
	}

	/**
	 * Save the user data for this form.
	 *
	 * @param 	array[] 	$fields
	 * @param 	array 		$submitted
	 * @return 	int  		$user_id
	 * @access  public
	 * @since 	1.0.0
	 */
	public function save_user_data( $fields, $submitted ) {		
		if ( ! isset( $fields[ 'user' ] ) ) {
			return 0;
		}

		$user_fields = apply_filters( 'charitable_campaign_submission_user_fields', $submitted, $fields[ 'user' ], $this );

		$user_keys = array_keys( $fields[ 'user' ] );

		$user = $this->get_user();		
		$user->update_profile( $submitted, $user_keys );
		$user->add_role( 'campaign_creator' );

		return $user->ID;
	}

	/**
	 * Create the campaign as a new object in the wp_posts table. 
	 *
	 * @param 	array[]		$fields
	 * @param 	array 		$submitted
	 * @param 	int 		$user_id
	 * @return 	int 		$campaign_id
	 * @access  public
	 * @since 	1.0.0
	 */
	public function save_core_campaign_data( $fields, $submitted, $user_id ) {
		if ( ! isset( $fields[ 'core' ] ) ) {
			return 0;
		}

		$values = array(
			'post_type'		=> 'campaign',
			'post_author'	=> $user_id			
		);

		/* Updating an exiting campaign, so set the ID. */
		if ( isset( $submitted[ 'ID' ] ) && strlen( $submitted[ 'ID' ] ) ) {
			$values[ 'ID' ] = $submitted[ 'ID' ];
		}
		
		/* If we are previewing the campaign, the status is "draft". */
		if ( isset( $submitted[ 'preview-campaign' ] ) ) {
			$values[ 'post_status' ] = 'draft';
		}
		/* New submission, or a submission that was previously draft. */
		elseif ( ! isset( $values[ 'ID' ] ) || 'draft' == get_post_field( 'post_status', $values[ 'ID' ] ) ) {
			$values[ 'post_status' ] = apply_filters( 'charitable_campaign_submission_initial_status', 'pending' );
		}
		/* An update to an existing submission */
		else {
			$values[ 'post_status' ] = get_post_status( $submitted[ 'ID' ] );
		}
			
		/* We've already touched this. */
		unset( $fields[ 'core' ][ 'ID' ] );

		foreach ( $fields[ 'core' ] as $key => $field_type ) {

			if ( 'checkbox' == $field_type ) {

				$values[ $key ] = isset( $submitted[ $key ] );

			}
			elseif ( isset( $submitted[ $key ] ) ) {

				$values[ $key ] = $submitted[ $key ];

			}

		}

		$values = apply_filters( 'charitable_campaign_submission_core_data', $values, $user_id, $submitted, $this );

		/* Update post if ID is set. */
		if ( isset( $values[ 'ID' ] ) ) {
			return wp_update_post( $values );
		}

		return wp_insert_post( $values );		
	}	

	/**
	 * Save the campaign taxonomy data. 
	 *
	 * @param 	array[]		$fields
	 * @param 	array 		$submitted
	 * @param 	int 		$campaign_id
	 * @return  void
	 * @access  public
	 * @since   1.0.0
	 */
	public function save_campaign_taxonomies( $fields, $submitted, $campaign_id ) {		
		if ( ! isset( $fields[ 'taxonomy' ] ) ) {
			return;
		}

		$taxonomy_fields = $fields[ 'taxonomy' ];

		$submitted = apply_filters( 'charitable_campaign_submission_taxonomy_data', $submitted, $campaign_id, $taxonomy_fields, $this );

		foreach ( $taxonomy_fields as $taxonomy => $field_type ) {

			if ( isset( $submitted[ $taxonomy ] ) ) {
				$terms = array_map( 'intval', $submitted[ $taxonomy ] );
				wp_set_object_terms( $campaign_id, $terms, $taxonomy, false );
			}	

		}		
	}

	/**
	 * Save the meta fields for the newly created campaign. 
	 *
	 * @param 	array[]		$fields
	 * @param 	array 		$submitted
	 * @param 	int 		$campaign_id	
	 * @return 	void
	 * @access  public
	 * @since 	1.0.0
	 */
	public function save_campaign_meta( $fields, $submitted, $campaign_id ) {		
		if ( ! isset( $fields[ 'meta' ] ) ) {
			return 0;
		}

		$meta_fields = $fields[ 'meta' ];

		$submitted = apply_filters( 'charitable_campaign_submission_meta_data', $submitted, $campaign_id, $meta_fields, $this );

		$updated_pairs = array();

		foreach ( $fields[ 'meta' ] as $key => $field_type ) {

			$meta_key = apply_filters( 'charitable_campaign_meta_key', '_campaign_' . $key, $key, $campaign_id );
			
            if ( 'checkbox' != $field_type && ! isset( $submitted[ $key ] ) ) {
            	continue;
            }

            $value = 'checkbox' == $field_type ? isset( $submitted[ $key ] ) : $submitted[ $key ];

            $value = apply_filters( 'charitable_sanitize_campaign_meta', $value, $meta_key, $submitted );

			update_post_meta( $campaign_id, $meta_key, $value );

			$updated_pairs[ $key ] = $value;

		}

		return count( $updated_pairs );
	}

	/**
     * Upload campaign thumbnail and add file field to the submitted fields. 
     *
     * @param   array       $submitted
     * @param 	int 		$campaign_id
     * @param   array[]     $meta_fields
     * @return  array 
     * @access  public
     * @since   1.0.0
     */
    public function save_picture( $submitted, $campaign_id, $meta_fields ) {
        if ( isset( $_FILES ) && isset( $_FILES[ 'image' ] ) ) {

            $attachment_id = $this->upload_post_attachment( 'image', $campaign_id );

            if ( ! is_wp_error( $attachment_id ) ) {

                $submitted[ 'image' ] = $attachment_id;

            }
            else {
                /** 
                 * @todo Handle image upload error.
                 */
                charitable_get_notices()->add_error( __( 'There was an error uploading your campaign image.', 'charitable-fes' ) );
            }
        }

        return $submitted;
    } 

    /**
     * Save campaign end date based on length.
     *
     * @param   array       $submitted
     * @param 	int 		$campaign_id
     * @param   array[]     $meta_fields
     * @return  array 
     * @access  public
     * @since   1.0.0
     */
    public function get_end_date( $submitted, $campaign_id, $meta_fields ) {
    	if ( 'publish' == get_post_status( $campaign_id ) ) {
    		return $submitted;
    	}

    	if ( isset( $submitted[ 'length' ] ) ) {

			$end_date = strtotime( sprintf( '+%d day', $submitted[ 'length' ] ), current_time( 'timestamp' ) );
			$submitted[ 'end_date' ] = date( 'Y-m-d H:i:s', $end_date );

    	}

    	return $submitted;
	}

    /**
     * Add end_date to the campaign meta fields to be saved.
     *
     * @param   array[] 	$fields
     * @return  array[] 
     * @access  public
     * @since   1.0.0
     */
    public function save_end_date( $fields ) {
    	$fields[ 'meta' ][ 'end_date' ] = 'date';
    	return $fields;
	}

	/**
	 * Make sure the campaign length is a valid value.  
	 *
	 * @return  int
	 * @access  public
	 * @since   1.0.0
	 */
	public function sanitize_campaign_length( $value ) {
		$min = charitable_get_option( 'campaign_length_min' ); 
		$max = charitable_get_option( 'campaign_length_max' );

		/* If the passed value is less than the miniminum length permitted
		 * or greater than the max permitted, set to the minimum length 
		 */
		if ( ( $min && $value < $min ) || ( $max && $value > $max ) ) {
			$value = apply_filters( 'charitable_default_campaign_length', $min, $max, $min );
		}

		return $value;
	}

    /**
     * Set meta key for thumbnail ID.  
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function set_thumbnail_id_meta_key( $key, $original_key ) {
    	if ( 'image' == $original_key ) {
    		$key = '_thumbnail_id';
    	}
	
		return $key;    	
    }

    /**
     * Redirect to the campaign if it's published or we're previewing. 
     *
     * Otherwise, redirect to the campaign submission success page set in the admin settings.
     *
     * @param 	array 	$submitted
     * @param 	int 	$campaign_id
     * @param 	int 	$user_id 
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_redirect_url( $submitted, $campaign_id, $user_id ) {    	
		if ( 'publish' == get_post_status( $campaign_id ) ) {

			$url = get_permalink( $campaign_id );
			$url = esc_url_raw( add_query_arg( array( 'updated' => true ), $url ) );

		}
		elseif ( isset( $submitted[ 'preview-campaign' ] ) ) {
			
			$url = get_permalink( $campaign_id );
			$url = esc_url_raw( add_query_arg( array( 'preview' => true ), $url ) );

		} 
		else {

			$url = charitable_get_permalink( 'campaign_submission_success_page', array( 'campaign_id' => $campaign_id ) );			

		}

		return apply_filters( 'charitable_campaign_submission_redirect_url', $url, $submitted, $campaign_id, $user_id );
    }

    /**
     * Filter media library to only show the users' own media when they click the Add Media button. 
     *
     * @global 	WP_User $current_user
     * @param 	string 	$where
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function hide_other_users_media( $where ) {
    	global $current_user;

	    // if ( ! current_user_can( 'manage_options' ) ) {
	    //     if ( is_user_logged_in() ){
	    //         if ( isset( $_POST['action'] ) ) {
	    //             if ( 'query-attachments' == $_POST['action'] ) {
	    //                 $where .= ' AND post_author=' . $current_user->data->ID;
	    //             }
	    //         }
	    //     }
	    // }
	 
	    return $where;
    }
}

endif; // End class_exists check