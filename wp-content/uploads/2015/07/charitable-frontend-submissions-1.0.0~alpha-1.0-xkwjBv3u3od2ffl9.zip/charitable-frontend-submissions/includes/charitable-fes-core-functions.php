<?php 

/**
 * Charitable FES Core Functions. 
 *
 * General core functions.
 *
 * @author 		Studio164a
 * @category 	Core
 * @package 	Charitable FES
 * @subpackage 	Functions
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * This returns the original Charitable_FES object. 
 *
 * Use this whenever you want to get an instance of the class. There is no
 * reason to instantiate a new object, though you can do so if you're stubborn :)
 *
 * @return 	Charitable_FES
 * @since 	1.0.0
 */
function charitable_fes() {
    return Charitable_FES::get_instance();
}

/**
 * Displays a template. 
 *
 * @param 	string|array 	$template_name 		A single template name or an ordered array of template
 * @param 	bool 		 	$load 				If true the template file will be loaded if it is found.
 * @param 	bool 			$require_once 		Whether to require_once or require. Default true. Has no effect if $load is false. 
 * @return 	Charitable_FES_Template
 * @since 	1.0.0
 */
function charitable_fes_template( $template_name, $load = true, $require_once = true ) {
	return new Charitable_FES_Template( $template_name, $load, $require_once ); 
}