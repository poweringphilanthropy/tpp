<?php
/**
 * Charitable FES template
 *
 * @version		1.0.0
 * @package		Charitable FES/Classes/Charitable_FES_Template
 * @author 		Eric Daams
 * @copyright 	Copyright (c) 2014, Studio 164a
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License  
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Charitable_FES_Template' ) ) : 

/**
 * Charitable_FES_Template
 *
 * @since 		1.0.0
 */
class Charitable_FES_Template extends Charitable_Template {
	
	/**
     * Set theme template path. 
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_theme_template_path() {
        return trailingslashit( apply_filters( 'charitable_fes_theme_template_path', 'charitable/charitable-fes' ) );
    }

    /**
     * Return the base template path.
     *
     * @return  string
     * @access  public
     * @since   1.0.0
     */
    public function get_base_template_path() {
        return charitable_fes()->get_path( 'templates' );
    }
}

endif;