<?php
/**
 * The template used to display the campaign submission form.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 * @version 1.0.0
 */

$form 	= $view_args[ 'form' ];
$donor	= new Charitable_User( wp_get_current_user() );

/**
 * @hook 	charitable_campaign_submission_before
 */
do_action('charitable_campaign_submission_before');

?>
<form method="post" id="charitable-campaign-submission-form" class="charitable-form" enctype="multipart/form-data">
	<?php 
	/**
	 * @hook 	charitable_form_before_fields
	 */
	do_action( 'charitable_form_before_fields', $form ) ?>
	
	<div class="charitable-form-fields cf">

	<?php 

	$i = 1;

	foreach ( $form->get_fields() as $key => $field ) :

		do_action( 'charitable_form_field', $field, $key, $form, $i );

		$i += apply_filters( 'charitable_form_field_increment', 1, $field, $key, $form );

	endforeach;

	?>
	
	</div>

	<?php
	/**
	 * @hook 	charitable_form_after_fields
	 */
	do_action( 'charitable_form_after_fields', $form );

	?>
	<div class="charitable-form-field charitable-submit-field">

		<?php echo $form->get_submit_buttons() ?>		
		
	</div>
</form>
<?php

/**
 * @hook 	charitable_campaign_submission_after
 */
do_action('charitable_campaign_submission_after');