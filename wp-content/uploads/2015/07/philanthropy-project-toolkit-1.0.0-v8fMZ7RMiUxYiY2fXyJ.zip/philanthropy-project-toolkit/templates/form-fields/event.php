<?php
/**
 * The template used to display the merchandise fields.
 *
 * @author  Studio 164a
 * @since   1.0.0
 * @version 1.0.0
 */

if ( ! isset( $view_args[ 'form' ] ) || ! isset( $view_args[ 'field' ] ) ) {
    return;
}

$form       = $view_args[ 'form' ];
$field      = $view_args[ 'field' ];
$nonce      = wp_create_nonce( 'pp-event-form' );
$index      = 0;
?>
<table id="pp-event" class="charitable-campaign-form-table charitable-repeatable-form-field-table"> 
    <tbody>
        <?php 
        foreach ( $field[ 'value' ] as $event ) :

            if ( empty( $event ) ) :
                continue;
            endif;
        
            $template = new PP_Toolkit_Template( 'form-fields/event-form.php', false );
            $template->set_view_args( array(
                'form'      => new PP_Event_Form( $event ),
                'index'     => $index
            ) );
            $template->render();

            $index += 1;
        
        endforeach ?> 
        <tr class="loading-row"><td></td></tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3"><a class="add-row" href="#" data-charitable-add-row="event-form" data-nonce="<?php echo $nonce ?>"><?php _e( 'Add an event', 'pp-toolkit' ) ?></a></td>
        </tr>
    </tfoot>
</table>