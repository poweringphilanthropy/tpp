<?php
/**
 * The template used to display the user's events.
 *
 * @author  Studio 164a
 * @since   1.0.0
 * @version 1.0.0
 */

$user = wp_get_current_user();
$events = tribe_get_events( array( 
    'posts_per_page' => -1, 
    'author' => $user->ID
) );

/**
 * @hook    charitable_user_events_before
 */
do_action('charitable_user_events_before');
?>

<header class="entry-header">
    <?php the_title( '<h1 class="entry-title">', '</h1>' ) ?>
</header><!-- .entry-header -->
<?php 
if ( ! empty( $events ) ) : ?>

<table class="charitable-user-events">
    <thead>
        <tr>
            <th><?php _e( 'Event', 'pp-toolkit' ) ?></th>
            <th><?php _e( 'Linked Campaign', 'pp-toolkit' ) ?></th>
            <th><?php _e( 'Event Date', 'pp-toolkit' ) ?></th>
            <th><?php _e( '# Attendees', 'pp-toolkit' ) ?></th>
            <th><?php _e( 'Actions', 'pp-toolkit' ) ?></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ( $events as $event ) : 
        $campaign = get_post_meta( $event->ID, '_event_linked_campaign', true );
        $download_args = array(
            'event_id' => $event->ID, 
            'download_attendees' => true, 
            'download_attendees_nonce' => wp_create_nonce( 'download_attendees_' . $event->ID )
        );
        $attendees = TribeEventsTickets::get_event_attendees( $event->ID );
        ?>
        <tr>
            <td><a href="<?php echo get_permalink( $event->ID ) ?>" rel="bookmark"><?php echo get_the_title( $event->ID ) ?></a></td>
            <td>
                <?php if ( $campaign ) : ?>
                    <a href="<?php echo get_permalink( $campaign ) ?>" rel="bookmark"><?php echo get_the_title( $campaign ) ?></a>
                <?php else : ?>
                    -
                <?php endif ?>
            </td>
            <td><?php echo tribe_events_event_schedule_details( $event->ID ) ?></td>
            <td><?php echo count( $attendees ) ?></td>
            <td>
                <?php if ( count( $attendees ) ) : ?>
                    <a href="<?php echo esc_url( add_query_arg( $download_args, site_url() ) ) ?>" target="_blank"><?php _e( 'Download Attendees List', 'pp-toolkit' ) ?></a>
                <?php endif ?>
            </td>
        </tr>
    <?php endforeach ?>
    </tbody>
</table>

<?php 
endif;