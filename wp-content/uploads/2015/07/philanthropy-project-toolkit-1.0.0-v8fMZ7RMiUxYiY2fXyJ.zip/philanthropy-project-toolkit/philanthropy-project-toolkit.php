<?php
/**
 * Plugin Name: 		Philanthropy Project - Toolkit
 * Plugin URI: 			http://philanthropyproject.com
 * Description: 		Custom features for The Philanthropy Project
 * Version: 			1.0.0
 * Author: 				Studio 164a & The Philanthropy Project
 * Author URI: 			http://164a.com
 * Requires at least: 	4.0
 * Tested up to: 		4.1
 *
 * Text Domain: 		pp-toolkit
 * Domain Path: 		/languages/
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Load plugin class, but only if Charitable is found and activated.
 *
 * @return 	void
 * @since 	1.0.0
 */
function philanthropy_project_load() {	
	require_once( 'includes/class-philanthropy-project.php' );

	/* Check for Charitable */
	if ( ! class_exists( 'Charitable' ) ) {

		if ( ! class_exists( 'Charitable_Extension_Activation' ) ) {

			require_once 'includes/class-charitable-extension-activation.php';

		}

		$activation = new Charitable_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
		$activation = $activation->run();
	} 
	else {
	
		new Philanthropy_Project( __FILE__ );

	}
}

add_action( 'plugins_loaded', 'philanthropy_project_load', 1 );