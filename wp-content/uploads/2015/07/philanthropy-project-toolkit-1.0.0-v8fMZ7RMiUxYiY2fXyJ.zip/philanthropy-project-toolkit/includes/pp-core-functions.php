<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Return the instance of Philanthropy_Project class.   
 *
 * @return  Philanthropy_Project
 * @since   1.0.0
 */
function pp_toolkit() {
    return Philanthropy_Project::get_instance();
}