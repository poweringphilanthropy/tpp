<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/** 
 * Register the custom meta box. 
 */
function pp_register_meta_box() {
    add_meta_box(
        'campaign_info_meta_box',
        esc_html__( 'Campaign Info'),
        'pp_campaign_info_meta_box',
        'campaign',
        'side',
        'default'
      );
}

add_action( 'add_meta_boxes', 'pp_register_meta_box' );    

/**
 * The meta box output.
 */
function pp_campaign_info_meta_box() {
    global $post;

    $campaign                   = new Charitable_Campaign( $post );
    $philanthrophy_challange    = ( get_post_meta( $campaign->ID, '_campaign_philanthropy_challenge', true ) );
    $group_campaign             = ( get_post_meta( $campaign->ID, '_campaign_group_campaign', true ) );
    ?>
    <p>
        <label for="campaign-philanthropy-challenge">
            <input type="checkbox" id="campaign-philanthropy-challenge" name="_campaign_philanthropy_challenge" <?php if ( '1' ==  $philanthrophy_challange ) { echo 'checked'; } ?> disabled="disabled" />30 day Philanthropy Challenge
        </label>
    </p>
    <p>
        <label for="campaign-group-campaign">
            <input type="checkbox" id="campaign-group-campaign" name="_campaign_group_campaign" <?php if ( '1' ==  $group_campaign ) { echo 'checked'; } ?> disabled="disabled" />Group campaign?
        </label>
    </p>
    <?php 
}