<?php 

/** 
 * Store the user thumbnail in the payment meta.
 */
function pp_edd_store_custom_fields($payment_meta) {
    if ( ! function_exists( 'wp_handle_upload' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/admin.php' );
    }

    $upload_overrides = array( 'test_form' => false );

    if ( '' != $_FILES[ 'edd_user_thumbnail' ] ) {
        $upload = wp_handle_upload( $_FILES[ 'edd_user_thumbnail' ], $upload_overrides );
        $payment_meta['user_thumbnail'] = $upload['url'];       
    }

    return $payment_meta;
}

add_filter('edd_payment_meta', 'pp_edd_store_custom_fields');

/** 
 * Output our custom field HTML
 */
function pp_edd_custom_checkout_fields() {
?>
    <p id="edd-user-thumbnail-wrap">
        <label class="edd-label" for="edd-user-thumbnail"><?php _e('Picture', 'pippin_edd'); ?></label>
        <span class="edd-description"><?php _e( 'Upload Your Photo (optional). Adding your photo helps personalize your donation and build community around the campaign.', 'pippin_edd' ); ?></span>
        <input class="edd-input" type="file" name="edd_user_thumbnail" id="edd-user-thumbnail" value=""/>
    </p>
<?php
}

add_action('edd_purchase_form_user_info', 'pp_edd_custom_checkout_fields');

/**
 * Given a donor ID, this will attempt to find a user_thumbnail for them.
 */
function pp_get_donor_user_thumbnail( $donor, $payment_id = "" ) {
    if ( isset( $payment_id ) ) {
        $meta = edd_get_payment_meta( $payment_id );

        if ( isset( $meta[ 'user_thumbnail' ] ) && strlen( $meta[ 'user_thumbnail' ] ) ) {
            return sprintf( '<img src="%s" alt="%s" class="avatar photo" width="%s" height="%s" />', 
                $meta[ 'user_thumbnail' ], 
                esc_attr( $donor->display_name ), 
                100,
                100
            );
        }
    }

    return false;    
}