<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Add additional fields to the user registration form. 
 *
 * @param   array   $fields
 * @return  array
 */
function pp_charitable_user_registration_fields( $fields ) {
    // unset( $fields[ 'last_name' ] );
    unset( $fields[ 'user_login' ] );    

    $fields[ 'dob' ] = array(
        'label'         => __( 'Date of Birth', 'pp-toolkit' ), 
        'type'          => 'text', 
        'required'      => true, 
        'priority'      => 1, 
        'fullwidth'     => true, 
        'class'         => 'datepicker',
        'value'         => isset( $_POST[ 'dob' ] ) ? $_POST[ 'dob' ] : ''
    );

    $fields[ 'coppa' ] = array(
        'type'          => 'paragraph', 
        'content'       => sprintf( __( '* %s complies with The Children’s Online Privacy Protection Act (COPPA). We request your birthdate to ensure that our website remains safe for all ages.', 'pp-toolkit' ), get_option( 'blogname' ) ), 
        'priority'      => 2, 
        'fullwidth'     => true, 
        'class'         => 'pp-coppa',
    );

    $fields[ 'first_name' ] = array(
        'label'         => __( 'First Name', 'pp-toolkit' ),
        'type'          => 'text', 
        'required'      => true, 
        'priority'      => 3,
        'value'         => isset( $_POST[ 'first_name' ] ) ? $_POST[ 'first_name' ] : ''
    );

    $fields[ 'last_name' ] = array(
        'label'         => __( 'Last Name', 'pp-toolkit' ),
        'type'          => 'text', 
        'required'      => true, 
        'priority'      => 4,
        'value'         => isset( $_POST[ 'last_name' ] ) ? $_POST[ 'last_name' ] : ''
    );   

    $fields[ 'user_email' ][ 'priority' ] = 5;

    $fields[ 'user_confirmation' ] = array(
        'label'         => sprintf( '%s %s\'s %s + %s', 
            __( 'I agree to', 'pp-toolkit' ), 
            get_option( 'blogname' ),
            sprintf( '<a target="_blank" href="' . home_url( "terms-of-service" ) . '">%s</a>', __( 'Terms of Service', 'pp-toolkit' ) ), 
            sprintf( '<a target="_blank" href="' . home_url( "privacy-policy" ) . '">%s</a>', __( 'Privacy Policy', 'pp-toolkit' ) )
        ), 
        'type'          => 'checkbox',
        'required'      => true, 
        'priority'      => 9, 
        'fullwidth'     => true
    );
    
    return $fields;
}

add_filter( 'charitable_user_registration_fields', 'pp_charitable_user_registration_fields' );

/**
 * Customize labels of user fields. 
 *
 * @param   array[]
 * @return  array[]
 * @since   1.0.0
 */
function pp_charitable_user_fields( $fields ) {
    // unset( $fields[ 'last_name' ] );
    unset( $fields[ 'user_login' ] );

    $fields[ 'first_name' ][ 'label' ] = __( 'First Name', 'pp-toolkit' );    
    $fields[ 'organisation' ][ 'label' ] = __( 'Organization', 'pp-toolkit' );
    $fields[ 'description' ][ 'label' ] = __( 'A Little Bit About Me', 'pp-toolkit' );
    $fields[ 'description' ][ 'required' ] = true;

    return $fields;
 }

add_filter( 'charitable_user_fields', 'pp_charitable_user_fields' );

/**
 * Customize address fields. 
 *
 * @param   array[]   $fields
 * @return  array[]
 * @since   1.0.0
 */
function pp_charitable_user_address_fields( $fields ) {
    unset( $fields[ 'phone' ] );
    return $fields;  
}

add_filter( 'charitable_user_address_fields', 'pp_charitable_user_address_fields' );