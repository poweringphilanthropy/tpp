<?php
/**
 * Display the events that are connected to a campaign.
 *
 * @author  Studio 164a
 * @since   1.0.0
 */
$widget_title   = apply_filters( 'widget_title', $view_args['title'] );
$campaign_id    = $view_args[ 'campaign_id' ] == 'current' ? get_the_ID() : $view_args[ 'campaign_id' ];
$events         = get_post_meta( $campaign_id, '_campaign_events', true );

if ( false === $events || empty( $events ) ) {
    return;
}

echo $view_args['before_widget'];

if ( ! empty( $widget_title ) ) :
    echo $view_args['before_title'] . $widget_title . $view_args['after_title'];
endif;

foreach ( $events as $event_id ) : 
    $GLOBALS['post'] = get_post( $event_id );
    $tickets = TribeEDDTickets::get_instance()->get_tickets_ids( $event_id );
    $has_purchaseable_tickets = false;
    ?>

    <div class="charitable-connected-event widget-block">
        <?php if ( $view_args['show_featured_image'] ) : ?>
            <?php echo get_the_post_thumbnail( $event_id ) ?>
        <?php endif ?>        
        <h4 class="event-title download-title">
            <a href="<?php echo get_the_permalink( $event_id ) ?>"><?php echo get_the_title( $event_id ) ?></a>
        </h4>      
        <?php echo tribe_events_event_schedule_details( get_the_ID(), '<div class="event-schedule">', '</div>' ) ?>
        <?php echo apply_filters( 'the_content', get_post_field( 'post_content', $event_id ) ) ?>        
        <?php if ( count( $tickets ) ) : ?>            
            <?php foreach ( $tickets as $ticket_id ) : 

                if ( ! pp_is_ticket_in_sale_period( $ticket_id, $event_id ) ) : 
                    continue;
                endif;
                
                /* We only want to display the tickets header if there is a ticket on sale */  
                if ( $has_purchaseable_tickets === false ) :
                    $has_purchaseable_tickets = true;
                ?>

                <h5><?php _e( 'Tickets', 'pp-toolkit' ) ?></h5>
                    <ul class="event-tickets">                              
                
                <?php endif; ?>
                
                    <li>
                        <h6><?php echo get_the_title( $ticket_id ) ?></h6>
                        <?php 
                        if ( ! TribeEDDTickets::is_stock_left( $ticket_id ) ) : 
                            printf( '<span class="out-of-stock">%s</span>', esc_html__( 'Out of stock!', 'pp-toolkit' ) );
                        else : 
                            // echo edd_price( $ticket_id );
                            echo edd_get_purchase_link( array( 'download_id' => $ticket_id ) );
                        endif;
                        ?>
                        <?php  ?>
                    </li>

            <?php endforeach ?>
            
            <?php if ( $has_purchaseable_tickets ) : ?>

                </ul>

            <?php endif;
        endif ?>
    </div>

<?php endforeach;

wp_reset_postdata();

echo $view_args['after_widget'];