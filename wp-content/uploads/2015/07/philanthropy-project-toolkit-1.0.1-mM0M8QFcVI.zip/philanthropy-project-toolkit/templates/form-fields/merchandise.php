<?php
/**
 * The template used to display the merchandise fields.
 *
 * @author  Studio 164a
 * @since   1.0.0
 * @version 1.0.0
 */

if ( ! isset( $view_args[ 'form' ] ) || ! isset( $view_args[ 'field' ] ) ) {
    return;
}

$form       = $view_args[ 'form' ];
$field      = $view_args[ 'field' ];
$nonce      = wp_create_nonce( 'pp-merchandise-form' );
$index      = 0;
?>
<table id="pp-merchandise" class="charitable-campaign-form-table charitable-repeatable-form-field-table"> 
    <tbody>
        <?php 
        foreach ( $field[ 'value' ] as $campaign_benefactor_id => $relationship ) :
        
            $template = new PP_Toolkit_Template( 'form-fields/merchandise-form.php', false );
            $template->set_view_args( array(
                'form'      => new PP_Merchandise_Form( $relationship ),
                'index'     => $index
            ) );
            $template->render();

            $index += 1;
        
        endforeach ?> 
        <tr class="loading-row"><td></td></tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3"><a class="add-row" href="#" data-charitable-add-row="merchandise-form" data-nonce="<?php echo $nonce ?>"><?php _e( 'Add merchandise', 'pp-toolkit' ) ?></a></td>
        </tr>
    </tfoot>
</table>