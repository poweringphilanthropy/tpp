<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Add additional fields to the user registration form. 
 *
 * @param   array   $fields
 * @return  array
 */
function pp_charitable_user_registration_fields( $fields ) {
    // unset( $fields[ 'last_name' ] );
    unset( $fields[ 'user_login' ] );    

    $fields[ 'dob' ] = array(
        'label'         => __( 'Date of Birth', 'pp-toolkit' ), 
        'type'          => 'text', 
        'required'      => true, 
        'priority'      => 1, 
        'fullwidth'     => true, 
        'class'         => 'datepicker',
        'value'         => isset( $_POST[ 'dob' ] ) ? $_POST[ 'dob' ] : ''
    );

    $fields[ 'coppa' ] = array(
        'type'          => 'paragraph', 
        'content'       => sprintf( __( '* %s complies with The Children’s Online Privacy Protection Act (COPPA). We request your birthdate to ensure that our website remains safe for all ages.', 'pp-toolkit' ), get_option( 'blogname' ) ), 
        'priority'      => 2, 
        'fullwidth'     => true, 
        'class'         => 'pp-coppa',
    );

    $fields[ 'first_name' ] = array(
        'label'         => __( 'First Name', 'pp-toolkit' ),
        'type'          => 'text', 
        'required'      => true, 
        'priority'      => 3,
        'value'         => isset( $_POST[ 'first_name' ] ) ? $_POST[ 'first_name' ] : ''
    );

    $fields[ 'last_name' ] = array(
        'label'         => __( 'Last Name', 'pp-toolkit' ),
        'type'          => 'text', 
        'required'      => true, 
        'priority'      => 4,
        'value'         => isset( $_POST[ 'last_name' ] ) ? $_POST[ 'last_name' ] : ''
    );   

    $fields[ 'user_email' ][ 'priority' ] = 5;

    $fields[ 'user_confirmation' ] = array(
        'label'         => sprintf( '%s %s\'s %s + %s', 
            __( 'I agree to', 'pp-toolkit' ), 
            get_option( 'blogname' ),
            sprintf( '<a target="_blank" href="' . home_url( "terms-of-service" ) . '">%s</a>', __( 'Terms of Service', 'pp-toolkit' ) ), 
            sprintf( '<a target="_blank" href="' . home_url( "privacy-policy" ) . '">%s</a>', __( 'Privacy Policy', 'pp-toolkit' ) )
        ), 
        'type'          => 'checkbox',
        'required'      => true, 
        'priority'      => 9, 
        'fullwidth'     => true
    );
    
    return $fields;
}

add_filter( 'charitable_user_registration_fields', 'pp_charitable_user_registration_fields' );

/**
 * The last name field is not required if the registering user is under 13. 
 *
 * @param
 *
 * @return  boolean
 * @since   1.0.1
 */
function pp_charitable_validate_last_name_field( $exists, $key, $field, $submitted ) {
    if ( $key == 'last_name' && ! $exists ) {

        if ( ! isset( $submitted[ 'dob' ] ) ) {
            return $exists;
        }        

        return pp_is_less_than_thirteen( $submitted[ 'dob' ] );
    }    

    return $exists;
}

add_filter( 'charitable_required_field_exists', 'pp_charitable_validate_last_name_field', 10, 4 );

/**
 * Filter submitted registration fields. 
 *
 * @param   array   $submitted
 * @return  array
 * @since   1.0.1
 */
function pp_charitable_filter_registration_fields( $submitted ) {
    unset( $submitted[ 'coppa' ], $submitted[ 'user_confirmation' ] );

    if ( pp_is_less_than_thirteen( $submitted[ 'dob' ] ) ) {
        unset( $submitted[ 'last_name' ] );
    }

    return $submitted;
}

add_filter( 'charitable_registration_values', 'pp_charitable_filter_registration_fields' );

/**
 * Checks whether the submitted date of birth is less than 13 years old.
 *
 * @param   string  $dob
 * @return  boolean
 * @since   1.0.1
 */
function pp_is_less_than_thirteen( $dob ) {
    if ( ! strpos( $dob, '/' ) ) {
        return false;
    }

    list( $month, $day, $year ) = explode( '/', $dob );

    $years_elapsed = date( 'Y' ) - $year;

    if ( $years_elapsed == 13 ) {

        if ( date( 'm' ) == $month ) {
            
            /* The birthday day has already passed this month. */
            return intval( $day ) < date( 'd' );
        }

        /* The birthday month has already passed. */
        return intval( $month ) < date( 'm' );
    }

    return $years_elapsed < 13;
}

/**
 * Customize labels of user fields. 
 *
 * @param   array[]
 * @return  array[]
 * @since   1.0.0
 */
function pp_charitable_user_fields( $fields ) {
    unset( $fields[ 'user_login' ] );

    if ( pp_is_less_than_thirteen( get_user_meta( get_current_user_id(), 'dob', true ) ) ) {
        unset( $fields[ 'last_name' ] );
    }

    $fields[ 'first_name' ][ 'label' ] = __( 'First Name', 'pp-toolkit' );    
    $fields[ 'organisation' ][ 'label' ] = __( 'Organization', 'pp-toolkit' );
    $fields[ 'description' ][ 'label' ] = __( 'A Little Bit About Me', 'pp-toolkit' );
    $fields[ 'description' ][ 'required' ] = true;

    return $fields;
 }

add_filter( 'charitable_user_fields', 'pp_charitable_user_fields' );

/**
 * Customize address fields. 
 *
 * @param   array[]   $fields
 * @return  array[]
 * @since   1.0.0
 */
function pp_charitable_user_address_fields( $fields ) {
    unset( $fields[ 'phone' ] );
    return $fields;  
}

add_filter( 'charitable_user_address_fields', 'pp_charitable_user_address_fields' );