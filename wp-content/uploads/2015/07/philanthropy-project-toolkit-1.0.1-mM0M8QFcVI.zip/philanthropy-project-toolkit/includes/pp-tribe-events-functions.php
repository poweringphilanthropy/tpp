<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Checks whether the given ticket is currently available to be purchased, based on its start and end date.
 *
 * @param   int     $ticket_id
 * @param   int     $event_id
 * @return  boolean
 * @since   1.0.0
 */
function pp_is_ticket_in_sale_period( $ticket_id, $event_id ) {
    $ticket = TribeEDDTickets::get_instance()->get_ticket( $event_id, $ticket_id );

    $gmt_offset = ( get_option( 'gmt_offset' ) >= '0' ) ? ' +' . get_option( 'gmt_offset' ) : " " . get_option( 'gmt_offset' );
    $gmt_offset = str_replace( array( '.25', '.5', '.75' ), array( ':15', ':30', ':45' ), $gmt_offset );
    $end_date = null;

    if ( ! empty( $ticket->end_date ) ) {
        $end_date = strtotime( $ticket->end_date . $gmt_offset );
    }
    else{
        $end_date = strtotime( tribe_get_end_date( $event_id, false, 'Y-m-d G:i' ) . $gmt_offset );
    }

    $start_date = null;

    if ( !empty( $ticket->start_date ) ) {
        $start_date = strtotime( $ticket->start_date . $gmt_offset );
    }

    /* The ticket is in its sale period if the start date has passed and the end date has not yet passed. */
    return ( empty( $start_date ) || time() > $start_date ) && ( empty( $end_date ) || time() < $end_date );
}

/**
 * Download CSV with event attendees. 
 *
 * @param   int     $event_id
 * @return  void
 * @since   1.0.0
 */
function pp_download_event_attendees( $event_id ) {    
    /* Check for nonce existence. */
    if ( ! isset( $_GET[ 'download_attendees_nonce'] ) || ! wp_verify_nonce( $_GET[ 'download_attendees_nonce'], 'download_attendees_' . $event_id ) ) {
        return false;
    }

    /* User must have edit ability OR be the creator of this event. */
    if ( ! current_user_can( 'edit_tribe_events' ) && get_post_field( 'post_author', $event_id ) !== get_current_user_id() ) {
        return false;
    }

    $items = TribeEventsTickets::get_event_attendees( $event_id );
    $event = get_post( $event_id );

    if ( ! empty( $items ) ) {

        $charset  = get_option( 'blog_charset' );
        $filename = sanitize_file_name( $event->post_title . '-' . __( 'attendees', 'tribe-events-calendar' ) );
        $columns  = array( 
            'order_id' => __( 'Order #' ), 
            'order_status' => __( 'Order Status' ),
            'purchaser_name' => __( 'Purchaser name' ), 
            'purchaser_email' => __( 'Purchaser email', 'pp-toolkit' ),
            'ticket' => __( 'Ticket type', 'pp-toolkit' ),
            'attendee_id' => __( 'Ticket #', 'pp-toolkit' ),
            'security' => __( 'Security Code', 'pp-toolkit' ),
            '' => __( 'Check in', 'pp-toolkit' )
        );

        /* Output headers so that the file is downloaded rather than displayed */
        header( "Content-Type: text/csv; charset=$charset" );
        header( "Content-Disposition: attachment; filename=$filename.csv" );

        /* Create a file pointer connected to the output stream */
        $output = fopen( 'php://output', 'w' );

        /* Print header row */
        fputcsv( $output, array_values( $columns ) );        

        /* And echo the data */
        foreach ( $items as $item ) {
            $row = array();
            foreach( $item as $key => $data ) {
                if ( array_key_exists( $key, $columns ) ) {
                    $row[] = $data;
                }    
            }
            fputcsv( $output, $row );
        }

        fclose( $output );
        exit;
    }
}