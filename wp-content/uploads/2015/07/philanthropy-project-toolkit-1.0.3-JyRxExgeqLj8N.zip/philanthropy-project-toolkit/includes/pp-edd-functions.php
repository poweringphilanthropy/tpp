<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Organize downloads into "merchandise" and "tickets" arrays.
 *
 * @param   array[] $downloads
 * @return  array[]
 * @since   1.0.0
 */
function pp_edd_organize_downloads( $downloads ) {
    $groups = array( 'merchandise' => array(), 'tickets' => array() );

    /* Unless a download is a ticket, we will classify it as "merchandise". */
    foreach ( $downloads as $download ) {
        $d = is_a( $download, 'WP_Post' ) ? $download : $download[ 'id' ];
        $group = has_term( 'ticket', 'download_category', $d ) ? 'tickets' : 'merchandise';
        $groups[ $group ][] = $download;
    }

    return $groups;
}

/**
 * Customise the label of the donation fee before it is passed to EDD.
 *
 * @param   mixed[] $args
 * @param   int     $campaign_id
 * @return  mixed[]
 * @since   1.0.0
 */
function pp_edd_fee_donation_args( $args, $campaign_id ) {
    $args[ 'label' ] = sprintf( '%s <a href="%s" title="%s">%s</a>', 
        _x( 'Donation to', 'donation to campaign', 'pp-toolkit' ), 
        get_permalink( $campaign_id ),
        get_the_title( $campaign_id ),
        get_the_title( $campaign_id ) 
    );

    return $args;
}

add_filter( 'charitable_edd_donation_fee_args', 'pp_edd_fee_donation_args', 10, 2 );


/************* CRUSTY STUFF *************/
/* THIS CAN BE REMOVED WHEN EDD ADDS A  */
/* FILTER TO THE SUMMARY                */
/****************************************/
class PP_EDD_Payment_Fees {
    private static $fees;
    private function __construct(){}
    public static function set( $fees ) {
        self::$fees = $fees;
    }
    public static function get() {
        return self::$fees;
    }
}

function pp_edd_wepay_log_fees( $payment_id ) {
    $fees = edd_get_payment_fees( $payment_id, 'item' );
    PP_EDD_Payment_Fees::set( $fees );
}

add_action( 'edd_insert_payment', 'pp_edd_wepay_log_fees' );

/**
 * Include the donation fees in the short description.
 *
 * @param   array   $args
 * @return  array   $args
 * @since   1.0.0
 */
function pp_edd_wepay_short_description( $args ) {
    if ( ! function_exists( 'charitable_edd' ) ) {
        return $args;
    }

    $fees = PP_EDD_Payment_Fees::get();

    if ( empty( $fees ) ) {
        return $args;
    }

    $summary = $args[ 'short_description' ];

    foreach ( $fees as $fee ) {
        if ( ! Charitable_EDD_Cart::fee_is_donation( $fee ) ) {
            continue;
        }

        $prepend = strlen( $summary ) ? ', ' : '';

        $summary .= sprintf( '%s%s %s', $prepend, charitable_get_currency_helper()->get_monetary_amount( $fee[ 'amount' ] ), $fee[ 'label' ] );
    }

    substr( $summary, 0, -2 );

    $args[ 'short_description' ] = stripslashes_deep( html_entity_decode( wp_strip_all_tags( $summary ) ) );

    return $args;
}

add_filter( 'edd_wepay_checkout_args', 'pp_edd_wepay_short_description', 10 );

/**
 * Checkout Form Shortcode
 *
 * Show the checkout form.
 *
 * @since 1.0
 * @param array $atts Shortcode attributes
 * @param string $content
 * @return string
 */
function pp_edd_checkout_form_shortcode( $atts, $content = null ) {
    return pp_edd_checkout_form();
}

remove_shortcode( 'download_checkout', 'edd_checkout_form_shortcode' );
add_shortcode( 'download_checkout', 'pp_edd_checkout_form_shortcode' );

/**
 * Get Checkout Form
 *
 * @since 1.0
 * @return string
 */
function pp_edd_checkout_form() {
    $payment_mode = edd_get_chosen_gateway();
    $form_action  = esc_url( edd_get_checkout_uri( 'payment-mode=' . $payment_mode ) );

    ob_start();
        echo '<div id="edd_checkout_wrap">';
        if ( edd_get_cart_contents() || edd_cart_has_fees() ) :

            edd_checkout_cart();
?>
            <div id="edd_checkout_form_wrap" class="edd_clearfix">
                <?php do_action( 'edd_before_purchase_form' ); ?>
                <form id="edd_purchase_form" class="edd_form" action="<?php echo $form_action; ?>" method="POST" enctype="multipart/form-data">
                    <?php
                    /**
                     * Hooks in at the top of the checkout form
                     *
                     * @since 1.0
                     */
                    do_action( 'edd_checkout_form_top' );

                    if ( edd_show_gateways() ) {
                        do_action( 'edd_payment_mode_select'  );
                    } else {
                        do_action( 'edd_purchase_form' );
                    }

                    /**
                     * Hooks in at the bottom of the checkout form
                     *
                     * @since 1.0
                     */
                    do_action( 'edd_checkout_form_bottom' )
                    ?>
                </form>
                <?php do_action( 'edd_after_purchase_form' ); ?>
            </div><!--end #edd_checkout_form_wrap-->
        <?php
        else:
            /**
             * Fires off when there is nothing in the cart
             *
             * @since 1.0
             */
            do_action( 'edd_cart_empty' );
        endif;
        echo '</div><!--end #edd_checkout_wrap-->';
    return ob_get_clean();
}
