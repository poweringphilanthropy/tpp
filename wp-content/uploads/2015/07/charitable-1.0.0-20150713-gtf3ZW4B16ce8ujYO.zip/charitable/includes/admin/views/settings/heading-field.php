<?php
/**
 * Display section heading in settings area.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 */
?>
<hr />