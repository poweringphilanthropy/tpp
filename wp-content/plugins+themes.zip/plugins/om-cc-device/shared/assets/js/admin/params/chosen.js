jQuery(function ($) {
    $('[data-om-cc-chosen]').chosen({width: '100%'});
});