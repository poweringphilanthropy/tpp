<?php


class Tribe__Tickets__REST__V1__Validator__Base
	extends Tribe__Tickets__Validator__Base
	implements Tribe__Tickets__REST__V1__Validator__Interface {

}