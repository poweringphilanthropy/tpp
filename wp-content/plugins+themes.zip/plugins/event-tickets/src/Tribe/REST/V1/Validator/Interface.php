<?php


interface Tribe__Tickets__REST__V1__Validator__Interface  extends Tribe__Tickets__Validator__Interface {

}