<th class="ticket_price"><?php esc_html_e( 'Price', 'event-tickets' ); ?></th>
