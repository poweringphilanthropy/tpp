<?php
/**
 * Campaign category archive.
 *
 * This template is only used if Charitable is active.
 *
 * @package     Reach
 */

get_template_part( 'archive', 'campaign' );
