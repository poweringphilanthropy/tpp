<?php wp_footer() ?>
</body>
