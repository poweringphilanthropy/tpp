<?php 
/**
 * Single leaderboard template.
 *
 * @package Reach
 */
get_header();
	
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post(); ?>
			
			<section class="campaign-summary current-campaign feature-block cf ">
			    <div class="shadow-wrapper">
			        <div class="layout-wrapper leaderboard-content">
			        	<h1 class="leaderboard-title">
			            		<?php the_title(); ?>
			            	</h1>
			            	<div class="campaign-description">      
    						<?php the_content(); ?>
    				   	 </div>
    				    	<div class="leaderboard-image">
    						<?php if ( has_post_thumbnail() ) {
    								the_post_thumbnail('leaderboard-featured-img'); 
    					     		}
    						?>
    				    	</div>            
	    				<div class="leaderboard-details cf barometer-added">
				            	<p class="leaderboard-campaign-stat">    
							<span class="leaderboard-stat-figure">211</span>
						        <span class="leaderboard-stat-label">Campaigns</span>						
						</p> 
						<p class="leaderboard-donations-stat">
						        <span class="leaderboard-stat-figure">$150,000</span> 
							<span class="leaderboard-stat-label">Donated to charity</span>
						</p>    
						<p class="leaderboard-volunteers-stat">
						        <span class="leaderboard-stat-figure">1,678</span> 
							<span class="leaderboard-stat-label">Volunteer hours logged</span>
						</p>
						<p class="leaderboard-impact-stat">
						        <span class="leaderboard-stat-figure">3,042</span> 
							<span class="leaderboard-stat-label">Lives impacted</span>
						</p>						
						<!-- <div class="campaign-countdown">
						    <span class="countdown is-countdown" data-enddate="15 April 2016 00:00:00"><span class="countdown-row countdown-show4"><span class="countdown-section"><span class="countdown-amount">33</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">10</span><span class="countdown-period">Hours</span></span><span class="countdown-section"><span class="countdown-amount">37</span><span class="countdown-period">Minutes</span></span><span class="countdown-section"><span class="countdown-amount">3</span><span class="countdown-period">Seconds</span></span></span></span>
						    <span>Countdown</span>
						</div>            
					</div> .leaderboard-details -->			            						
			        </div><!-- .layout-wrapper -->
				<div class="leaderboard-sharing-block" style="text-align: center;">
					<ul class="leaderboard-sharing share horizontal rrssb-buttons rrssb-1">
					    <li data-initwidth="14.285714285714286" style="width: 14.2857%;"><h6>Share</h6></li>
					    <li class="share-twitter" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#" class="popup icon" data-icon=""></a>
					    </li>
					    <li class="share-facebook" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#" data-icon=""></a>
					    </li>
					    <li class="share-googleplus" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#" class="popup icon" data-icon=""></a>
					    </li>
					    <li class="share-linkedin" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#" class="popup icon" data-icon=""></a>
					    </li>
					    <li class="share-pinterest" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#" class="popup icon" data-icon=""></a>
					    </li>
					    <li class="share-widget" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#" class="icon" data-icon="" data-trigger-modal=""></a>
					        <div id="campaign-widget-7368" class="modal">
					            <a class="modal-close"></a>         
					            <h4 class="block-title">Share Campaign</h4>
					            <div class="block"> 
					                                <p><strong>Embed Code</strong></p>
					                <pre>&lt;iframe src="http://staging1.philanthropyproject.com/campaigns/im-not-the-one-2016/widget/" width="275px" height="400px" frameborder="0" scrolling="no" /&gt;&lt;/iframe&gt;</pre>
					            </div>
					            <div class="block iframe-block">
					                <p><strong>Preview</strong></p>
					                <iframe src="http://staging1.philanthropyproject.com/campaigns/im-not-the-one-2016/widget/" width="275px" height="400px" frameborder="0" scrolling="no"></iframe>
					            </div>
					        </div>
					    </li>   
					</ul>
				</div><!-- .leaderboard-sharing-block -->
			        <div style="clear: both;"></div>					
			    </div><!-- .shadow-wrapper -->
			</section>			
			
			<div class="layout-wrapper">
				<main class="site-main content-area" role="main">
					<?php get_template_part( 'partials/content', 'leaderboard' ) ?>
				</main><!-- .site-main -->
				<?php get_sidebar('leaderboard') ?>
			</div><!-- .layout-wrapper -->
		<?php 
		endwhile;
	endif;

get_footer();