<?php

define( 'PHILANTHROPY_PROJECT_CAMPAIGN_ID', 4574 );

add_filter( 'oembed_ttl', function() {
	return 1; 
});
add_filter( 'embed_cache_oembed_types', function() {
	return array();
});

add_filter( 'edd_log_test_payment_stats', '__return_true' );

/**
 * Prepare child theme. 
 *
 * This enqueues the child theme's style.css file after first loading
 * the main theme's stylesheet.
 *
 * @return  void
 * @since   1.0.0
 */
function reach_child_load_styles() {    

    // uikit
    // wp_enqueue_style( 'normalize', get_stylesheet_directory_uri() . "/css/normalize.css" );
    wp_enqueue_style( 'uikit', get_stylesheet_directory_uri() . "/css/uikit.css" );

	wp_dequeue_style( 'reach-style' );
    wp_register_style( 'franklin-palette', get_stylesheet_directory_uri() . "/palette.css", array('reach-base'), filemtime(get_stylesheet_directory().'/palette.css') );
    wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/custom.css", array( 'franklin-palette' ), filemtime(get_stylesheet_directory().'/custom.css') );
    // wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/css/main.css", array( 'franklin-palette' ), reach_get_theme()->get_theme_version() );
    wp_enqueue_style( 'reach-child-styles' );

    // new layout
    wp_enqueue_style( 'new-layout', get_stylesheet_directory_uri() . "/new-layout.css" );

    wp_enqueue_script('jscroll', get_stylesheet_directory_uri().'/js/jquery.jscroll.min.js', false, '2.3.5');
    wp_enqueue_script('philanthropy-project-scripts', get_stylesheet_directory_uri().'/js/custom.js', false, filemtime(get_stylesheet_directory().'/js/custom.js'));

    wp_enqueue_script( 'philanthropy-project-scripts', get_stylesheet_directory_uri() . "/media/js/custom.js" );
}

add_action( 'wp_enqueue_scripts', 'reach_child_load_styles', 100 );

/**
 * Set up child theme
 */
function franklin_child_after_setup_theme() {
	register_sidebar( array(
		'id'              => 'sidebar_get_inspired',
		'name'            => __( 'Get inspired sidebar', 'reach' ),
		'description'     => __( 'The get inspired sidebar.', 'reach' ),
		'before_widget'   => '<aside id="%1$s" class="widget cf %2$s">',
		'after_widget'    => '</aside>',
		'before_title'    => '<div class="title-wrapper"><h4 class="widget-title">',
		'after_title'     => '</h4></div>'
	));

    register_sidebar( array(
        'id'              => 'sidebar_tpp_campaign',            
        'name'            => __( 'Greeks4Good Campaign - sidebar', 'reach' ),
        'description'     => __( 'The sidebar on Greeks4Good campaign.', 'reach' ),
        'before_widget'   => '<aside id="%1$s" class="widget cf %2$s">',
        'after_widget'    => '</aside>',
        'before_title'    => '<div class="title-wrapper"><h4 class="widget-title">',
        'after_title'     => '</h4></div>'
    ));

    register_sidebar( array(
        'id'            => 'tpp_campaign_after_content',            
        'name'          => __( 'Greeks4Good Campaign - below content', 'reach' ),
        'description'   => __( 'Displayed below the Greeks4Good campaign\'s content, but above the comment section.', 'reach' ),
        'before_widget' => '<aside id="%1$s" class="widget block content-block cf %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<div class="title-wrapper"><h3 class="widget-title">',
        'after_title'   => '</h3></div>'
    ));    
    register_sidebar( array(
        'id'            => 'leaderboard',            
        'name'          => __( 'Leaderboard', 'reach' ),
        'description'   => __( 'Displayed only on leaderboard pages.', 'reach' ),
        'before_widget' => '<aside id="%1$s" class="widget block content-block cf %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<div class="title-wrapper"><h3 class="widget-title">',
        'after_title'   => '</h3></div>'
    ));     
}

add_action('after_setup_theme', 'franklin_child_after_setup_theme');

/**
 * Add special body class to TPP campaign page. 
 *
 * @param   string[] $classes
 * @return  string[]
 * @since   1.1.1
 */
function tpp_custom_campaign_body_class( $classes ) {
    if ( PHILANTHROPY_PROJECT_CAMPAIGN_ID == get_the_ID() ) {
        $classes[] = 'tpp-campaign';
    }

    return $classes;
}

add_filter( 'body_class', 'tpp_custom_campaign_body_class' );

/**
 * Remove the TPP campaign from the archive query.
 *
 * @param   WP_Query $wp_query
 * @return  void
 * @since   1.1.1
 */
function tpp_remove_campaign_from_archives( $query ) {
    if ( is_admin() ) {
        return;
    }

    if ( $query->is_main_query() && is_post_type_archive( 'campaign' ) ) {
        $query->set( 'post__not_in', array( PHILANTHROPY_PROJECT_CAMPAIGN_ID ) );
    }
}

add_action( 'pre_get_posts', 'tpp_remove_campaign_from_archives' );

/**
 * Remove comment form allowed tags text.
 *
 * @param   array $defaults
 * @return  array
 */
function remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

add_filter( 'comment_form_defaults', 'remove_comment_form_allowed_tags' );

/**
 * Display donate button or link in the campaign summary.
 *
 * @param   Charitable_Campaign $campaign
 * @return  boolean     True if the template was displayed. False otherwise.
 * @since   1.1.1
 */
function charitable_template_donate_button( $campaign ) {
    if ( ! $campaign->has_goal() ) {
        return false;
    }

    if ( $campaign->has_ended() ) {
        return false;
    }

    $campaign->donate_button_template();

    return true;
}

/**
 * Insert Impact Goal where stats would normally go for campaigns without a 
 * fundraising target. 
 *
 * @param   Charitable_Campaign $campaign
 * @return  void
 * @since   1.1.1
 
function pp_add_impact_goal_before_countdown( Charitable_Campaign $campaign ) {
    if ( $campaign->has_goal() ) {
        return;
    }

    reach_template_campaign_impact_summary( $campaign );

    remove_action( 'charitable_campaign_summary_after', 'reach_template_campaign_impact_summary', 8 );
}

add_action( 'charitable_campaign_summary', 'pp_add_impact_goal_before_countdown', 2 );
*/

// Add featured image size for the leaderboard
add_image_size( 'leaderboard-featured-img', 630, 400, true );

/** 
 * Remove payment fields from the campaign form.
 */
$object = charitable()->get_registered_object( 'PP_Charitable_Campaign_Form' );
if ( is_a( $object, 'PP_Charitable_Campaign_Form' ) ) {
	remove_filter( 'charitable_campaign_submission_payment_fields', array( $object, 'customise_payment_fields' ), 10, 2 );
}

add_filter( 'charitable_campaign_submission_fields', function( $fields ){
	unset( $fields[ 'payment_fields' ] );
	return $fields;
});

/* HIDE ADMIN BAR */
if(!current_user_can('administrator'))
    add_filter( 'show_admin_bar', '__return_false' );


    function test_save_tickets( $event_id, $event, $campaign_id, $user_id ) {

        $tickets = isset($event['tickets']) ? $event['tickets'] : '';

        $tickets = [
            '5777219b5ffb9' => [
                'ID' => '',
                'ticket_name' => 'THIS BE IT',
                'ticket_price' => '10',
                'ticket_description' => 'This be ticket',
                'ticket_start_date' => '07/01/2016',
                'ticket_end_date' => '07/31/2016',
                'ticket_edd_stock' => '100'
            ]
        ];

        if ( empty($tickets) )
            return;
        
        foreach ( $tickets as $ticket ) {
            $ticket_object              = new Tribe__Tickets__Ticket_Object();
            $ticket_object->name        = $ticket['ticket_name'];
            $ticket_object->price       = $ticket['ticket_price'];
            $ticket_object->description = $ticket['ticket_description'];
            $ticket_object->start_date  = $ticket['ticket_start_date'];
            $ticket_object->end_date    = $ticket['ticket_end_date'];
            // $ticket_object->stock       = $ticket['ticket_edd_stock'];

            if ( !empty($ticket['ID']) )
                $ticket_object->ID = $ticket['ID'];

            Tribe__Tickets_Plus__Commerce__EDD__Main::get_instance()->save_ticket($event_id, $ticket_object, ['ticket_edd_stock' => $ticket['ticket_edd_stock']]);
        }

        $ticket_ids = Tribe__Tickets_Plus__Commerce__EDD__Main::get_tickets_ids( $event_id );

        foreach ( $ticket_ids as $t_id ) {
            PP_Ticket_Form::save_benefactor_relationships($t_id, $event_id, $campaign_id);
$submitted = '';

            do_action('charitable_campaign_submission_save_product', $submitted, $t_id, $campaign_id, $user_id);
        }
    }




function test_everything() {

//    test_save_tickets(7688, [], 7686,21);


    $donation = charitable_get_donation(7783);
    $donor = $donation->get_donor();


    $payment_id = Charitable_EDD_Payment::get_payment_for_donation(7783);
md($payment_id);
    $meta = edd_get_payment_meta($payment_id);
mdd($meta);
}

//add_action('init','test_everything');

//* GUM Edit - add CSS to hide comments on Campaign preview */
add_action( 'wp_enqueue_scripts', 'gum_campaign_preview_enqueue_inline_css', 100 );
function gum_campaign_preview_enqueue_inline_css() {
	
	//on preview post only
	if ( !is_preview() ) return;
	
	$css = '';
	
	$css .= '
			.campaign-comments.block.multi-block.comments-section {
				display:none;
			}
		';
		
	if( !empty( $css ) )
		wp_add_inline_style( 'reach-child-styles', $css );
		//get_stylesheet_directory_uri() . "/custom.css"
}

//Send email on campaign publish vs pending
add_filter( 'charitable_ambassadors_send_creator_campaign_submission_email_on_status', 'pp_send_creator_camapign_submission_email_on_publish', 10, 1 );
function pp_send_creator_camapign_submission_email_on_publish( $status ) {
	return 'publish';
}

//* fix for EDD quantity fields ??
//add_action( 'edd_purchase_link_top', 'edd_download_purchase_form_quantity_field', 10 );