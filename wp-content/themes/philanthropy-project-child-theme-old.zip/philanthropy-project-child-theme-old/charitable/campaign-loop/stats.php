<?php 
/**
 * Campaign stats.
 *

 * 

 * @package Reach
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$campaign           = $view_args[ 'campaign' ];
$currency_helper    = charitable()->get_currency_helper();
?>
<ul class="campaign-stats">

    <li class="campaign-time-left">
        <?php echo $campaign->get_time_left() ?>                
    </li>       
     
</ul>