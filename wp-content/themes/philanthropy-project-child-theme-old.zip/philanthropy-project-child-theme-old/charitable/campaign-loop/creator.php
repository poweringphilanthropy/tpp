<?php
/**
 * Campaign creator.
 *
 * @package Reach
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

$campaign = $view_args['campaign'];
$campaign_author = new WP_User($campaign->get_campaign_creator());

$user_id = $campaign_author->ID;

$author_meta = [
    'organization' => get_user_meta($user_id, 'organisation', 1),
    'grade'        => get_user_meta($user_id, 'grade_level', 1),
    'city'         => get_user_meta($user_id, 'donor_city', 1),
    'state'        => get_user_meta($user_id, 'donor_state', 1),
    'country'      => get_user_meta($user_id, 'donor_country', 1),
];

if (strpos(strtolower($author_meta['grade']), 'grade') !== false) {
    $author_meta['grade'] = 'Grade '.substr($author_meta['grade'], 5);
}
?>
<style>
    .meta p {
        font-size: 14px;
    }

    .center.center--meta {
        line-height: 19px;
        font-size: 11px;
        padding-bottom: 8px !important;
    }

    .center.center--meta span {
        color: #777;
    }
</style>

<div class="meta meta-below">

    <p class="center">
        <?php printf('<a href="%s">%s</a>',
                     get_author_posts_url(get_the_author_meta('ID')),
                     $campaign_author->display_name
        ); ?>
    </p>
    <p class="center center--meta">
        <span><?= $author_meta['organization'] ?></span> |
        <span><?= $author_meta['grade'] ?></span> |
        <span><?= $author_meta['city'] ?>, <?= $author_meta['state'] ?>, <?= $author_meta['country'] ?></span>
    </p>

</div>