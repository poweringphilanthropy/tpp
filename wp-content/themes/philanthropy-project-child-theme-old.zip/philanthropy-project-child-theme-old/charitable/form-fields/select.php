<?php
/**
 * The template used to display select form fields.
 *
 * @author 	Studio 164a
 * @since 	1.0.0
 * @version 1.0.0
 */

if ( ! isset( $view_args[ 'form' ] ) || ! isset( $view_args[ 'field' ] ) ) {
	return;
}

$form 			= $view_args[ 'form' ];
$field 			= $view_args[ 'field' ];
$classes 		= $view_args[ 'classes' ];
$is_required 	= isset( $field[ 'required' ] ) 	? $field[ 'required' ] 		: false;
$options		= isset( $field[ 'options' ] ) 		? $field[ 'options' ] 		: array();
$value			= isset( $field[ 'value' ] ) 		? $field[ 'value' ] 		: '';
$value_array			= isset( $field[ 'value' ] ) 		? $field[ 'value' ] 		: array();

if ( count( $options ) ) : 

?>
<div id="charitable_field_<?php echo $field['key'] ?>" class="<?php echo $classes ?>">
	<?php if ( isset( $field['label'] ) ) : ?>
		<label for="charitable_field_<?php echo $field['key'] ?>">
			<?php echo $field['label'] ?>
			<?php if ( $is_required ) : ?>
				<abbr class="required" title="required">*</abbr>
			<?php endif ?>
		</label>
	<?php endif ?>
	<?php if ($field['key'] == 'campaign_group') { 
		if(isset($field['name'])){
		?>
 		<select name="<?php echo $field['name'] ?>" multiple>
		<?php }else{ ?>
		<select name="<?php echo $field['key'] ?>" multiple>
		<?php
		}
		?>
 			<?php 

			foreach ( $options as $val => $label ) :
				if ( is_array( $label ) ) : ?>
					
					<optgroup>
					
					<?php foreach( $label as $val => $label ) : ?>
	
						<option value="<?php echo $val ?>" <?php selected( in_array($val, $value_array) ); ?>>						
							<?php echo $label ?>
						</option>
					<?php endforeach; ?>
					
					</optgroup>
				
				<?php else : ?>
	
					<option value="<?php echo $val ?>" <?php selected( in_array($val, $value_array) ); ?>><?php echo $label ?></option> 
					
				<?php 
	
				endif;	
				
			endforeach;
			
			?>
		</select>		
 	<?php } else { ?>
 		<select name="<?php echo $field['key'] ?>">
 	
			<?php 
	
			foreach ( $options as $val => $label ) :
				if ( is_array( $label ) ) : ?>
					
					<optgroup>
					
					<?php foreach( $label as $val => $label ) : ?>
	
						<option value="<?php echo $val ?>" <?php selected( $val, $value ) ?>><?php echo $label ?></option>
	
					<?php endforeach; ?>
					
					</optgroup>
				
				<?php else : ?>
	
					<option value="<?php echo $val ?>" <?php selected( $val, $value ) ?>><?php echo $label ?></option> 
					
				<?php 
	
				endif;
			endforeach;
	
			?>
		</select>
	<?php } ?>
</div>
<?php 

endif;