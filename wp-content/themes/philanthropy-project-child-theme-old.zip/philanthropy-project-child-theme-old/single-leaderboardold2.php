<?php 

/**

 * Single leaderboard template without search

 *

 * @package Reach

 */

get_header();



$leaderboard_id = $post->ID;

$current_tax_terms_ids = wp_get_post_terms($leaderboard_id, campaign_group, array(

	'fields' => 'ids'

) );



// associated campaign query

$campaigns = Charitable_Campaigns::query( array( 	

	'post_status' => 'publish',			        

	'tax_query' => array(

		array(

			'taxonomy' => 'campaign_group',

			'field'    => 'term_id',															

			'terms'    => $current_tax_terms_ids,

			'operator' => 'IN'

		)

	    )

	) 

);



// Associated Campaigns

$assoc_campaigns = $campaigns->posts;

//print_r($assoc_campaigns[1]);



$assoc_campaigns[] = array();



foreach ($assoc_campaigns as $assoc_campaign) {

	$assoc_campaign_ids[] = $assoc_campaign->ID;	

}



$imploded_arr = implode(',',$assoc_campaign_ids);

$imploded_arr = substr($imploded_arr, 0, -1);

//print_r($imploded_arr);



// Get associated campaign's total donation

global $wpdb;

$donation = $wpdb->get_results("SELECT SUM(amount) AS total FROM wp_frank_charitable_campaign_donations WHERE campaign_id IN ($imploded_arr)");

$result = $donation[0];

$single_campaign_donation = $result->total;

// echo bcdiv($single_campaign_donation, 1, 2);



// Query campaigns based on the user id result

$campaigns_by_author_search = Charitable_Campaigns::query( array( 	

	'post_status' => 'publish',			        

	'author' => $user_query_search_arr,								

	'tax_query' => array(

		array(

			'taxonomy' => 'campaign_group',

			'field'    => 'term_id',															

			'terms'    => $current_tax_terms_ids,

			'operator' => 'IN'

		)

	   )					

	) 

);

						

// Get the campaign author ids for the leaderboard stats

$campaign_posts = $campaigns_by_author_search->posts;

//print_r($campaign_posts);



foreach	($campaign_posts as $campaign_post) {

	$campaign_post_author_id[] = $campaign_post->post_author;	

}



//print_r($campaign_post_author_id);

// only implode if $campaign_post_author_id is not empty to avoid PHP warning

if ($campaign_post_author_id != '' || $campaign_post_author_id != NULL ) {

	$implode_author_ids = implode(',',$campaign_post_author_id);

	//echo $implode_author_ids;

}

						

// Get the total schools/organisations associated with this leaderboard

$total_schools_organisations = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'organisation' AND `meta_value` != ''");

$total_schools_organisations_result = $total_schools_organisations[0];

$schools_organisations_number = $total_schools_organisations_result->total;



// Get the total cities associated with this leaderboard

$total_cities = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'location' AND `meta_value` != ''");

$total_cities_result = $total_cities[0];

$cities_number = $total_cities_result->total;



// Get the total states associated with this leaderboard

$total_states = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'donor_state' AND `meta_value` != ''");

$total_states_result = $total_states[0];

$states_number = $total_states_result->total;



// Get the total countries associated with this leaderboard

$total_countries = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'donor_country' AND `meta_value` != ''");

$total_countries_result = $total_countries[0];

$countries_number = $total_countries_result->total;

	

	if ( have_posts() ) :

		while ( have_posts() ) :

			the_post(); ?>			

			<section class="campaign-summary current-campaign feature-block cf ">

			    <div class="shadow-wrapper">

			        <div class="layout-wrapper leaderboard-content">			        	

    				    	<div class="ezcol ezcol-one-quarter">

    				    		<div class="leaderboard-image">

	    						<?php if ( has_post_thumbnail() ) {

	    								the_post_thumbnail('leaderboard-featured-img'); 

	    					     		}

	    						?>

    				    		</div> 

    				    	</div><!-- end .ezcol-one-quarter --> 

    				    	<div class="ezcol ezcol-three-quarter ezcol-last">   

    				    		<h1 class="leaderboard-title">

			            			<?php the_title(); ?>

				            	</h1>

				            	<div class="campaign-description">      

	    						<?php the_content(); ?>

	    				   	</div> 			   	

		    				<div class="leaderboard-details cf barometer-added">

		    					<?php 

		    						$leaderboard_stats = get_field('leaderboard_stats'); 	

		    						//print_r($leaderboard_stats);	    						

		    					?>

		    					<?php if ( in_array('campaigns', $leaderboard_stats) ) { ?> 

			    					<div class="ezcol ezcol-one-fifth">

							            	<p class="leaderboard-campaign-stat">    

										<span class="leaderboard-stat-figure">

											<?php 											

												echo $campaigns->found_posts;	

											?>

										</span>

									        <span class="leaderboard-stat-label">Campaigns</span>						

									</p> 

								</div>

							<?php } ?>

							<?php if ( in_array('donated_charity', $leaderboard_stats) ) { ?>

								<div class="ezcol ezcol-one-quarter">

									<p class="leaderboard-donations-stat">

									        <span class="leaderboard-stat-figure">

									        	<?php 

									        		echo "$" . bcdiv($single_campaign_donation, 1, 2); 

									        	?>

									        </span> 

										<span class="leaderboard-stat-label">Donated to charity</span>

									</p>  

								</div>

							<?php } ?>

							<?php if ( in_array('schools_organizations', $leaderboard_stats) ) { ?>

								<div class="ezcol ezcol-one-quarter">  

									<p class="leaderboard-volunteers-stat">

									        <span class="leaderboard-stat-figure">

									        	<?php 

									        		if ($schools_organisations_number != '' || $schools_organisations_number != NULL ) {

									        			echo $schools_organisations_number; 

									        		} else {

									        			echo "0";

									        		}									        	

									        	?>

									        </span> 

										<span class="leaderboard-stat-label">Schools/Organizations</span>

									</p>

								</div>

							<?php } ?>

							<?php if ( in_array('cities', $leaderboard_stats) ) { ?>

								<div class="ezcol ezcol-one-quarter">

									<p class="leaderboard-impact-stat">

									        <span class="leaderboard-stat-figure">

									        	<?php 

									        		if ($cities_number != '' || $cities_number != NULL ) {

									        			echo $cities_number; 

									        		} else {

									        			echo "0";

									        		}									        	

									        	?>

									        </span> 

										<span class="leaderboard-stat-label">Cities</span>

									</p>	

								</div>	

							<?php } ?>

							<?php if ( in_array('states', $leaderboard_stats) ) { ?>

								<div class="ezcol ezcol-one-quarter">

									<p class="leaderboard-impact-stat">

									        <span class="leaderboard-stat-figure">

									        	<?php 

									        		if ($states_number != '' || $states_number != NULL ) {

									        			echo $states_number; 

									        		} else {

									        			echo "0";

									        		}

									        	?>

									        </span> 

										<span class="leaderboard-stat-label">States</span>

									</p>	

								</div>	

							<?php } ?>

							<?php if ( in_array('countries', $leaderboard_stats) ) { ?>

								<div class="ezcol ezcol-one-quarter">

									<p class="leaderboard-impact-stat">

									        <span class="leaderboard-stat-figure">

									        	<?php 

									        		if ($countries_number != '' || $countries_number != NULL ) {

									        			echo $countries_number; 

									        		} else {

									        			echo "0";

									        		}

									        	?>

									        </span> 

										<span class="leaderboard-stat-label">Countries</span>

									</p>	

								</div>	

							<?php } ?>				

							<!-- <div class="campaign-countdown">

							    <span class="countdown is-countdown" data-enddate="15 April 2016 00:00:00"><span class="countdown-row countdown-show4"><span class="countdown-section"><span class="countdown-amount">33</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">10</span><span class="countdown-period">Hours</span></span><span class="countdown-section"><span class="countdown-amount">37</span><span class="countdown-period">Minutes</span></span><span class="countdown-section"><span class="countdown-amount">3</span><span class="countdown-period">Seconds</span></span></span></span>

							    <span>Countdown</span>

							</div>            

						</div><!-- .leaderboard-details -->	

					</div><!-- end .ezcol-three-quarter ezcol-last		            						

			        </div><!-- .layout-wrapper -->

				<div class="leaderboard-sharing-block">

					<ul class="leaderboard-sharing share horizontal rrssb-buttons rrssb-1">

					    <li data-initwidth="14.285714285714286" style="width: 14.2857%;"><h6>Share</h6></li>

					    <li class="share-twitter" data-initwidth="14.285714285714286" style="width: 14.2857%;">

					        <a href="http://twitter.com/home?status=<?php echo $title ?>%20<?php echo $permalink ?>" class="popup icon" data-icon="&#xf099;"></a>

					    </li>

					    <li class="share-facebook" data-initwidth="14.285714285714286" style="width: 14.2857%;">

					        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $permalink ?>" class="popup icon" data-icon="&#xf09a;"></a>

					    </li>

					    <li class="share-googleplus" data-initwidth="14.285714285714286" style="width: 14.2857%;">

					        <a href="https://plus.google.com/share?url=<?php echo $title . $permalink ?>" class="popup icon" data-icon="&#xf0d5;"></a>

					    </li>

					    <li class="share-linkedin" data-initwidth="14.285714285714286" style="width: 14.2857%;">

					        <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo $permalink ?>&amp;title=<?php echo $title ?>" class="popup icon" data-icon="&#xf0e1;"></a>

					    </li>

					    <li class="share-pinterest" data-initwidth="14.285714285714286" style="width: 14.2857%;">

					        <a href="http://pinterest.com/pin/create/button/?url=<?php echo $permalink ?>&amp;description=<?php echo $title ?>" class="popup icon" data-icon="&#xf0d2;"></a>

					    </li>

					    <li class="share-widget" data-initwidth="14.285714285714286" style="width: 14.2857%;">

					        <a href="#campaign-widget-<?php the_ID() ?>" class="icon" data-icon="&#xf121;" data-trigger-modal></a>

					        <div id="campaign-widget-<?php the_ID() ?>" class="modal">

					            <a class="modal-close"></a>         

					            <h4 class="block-title"><?php _e( 'Share Campaign', 'reach' ) ?></h4>

					            <div class="block"> 

					                <?php echo apply_filters( 'the_excerpt', get_theme_mod( 'campaign_sharing_text', '' ) ) ?>

					                <p><strong><?php _e( 'Embed Code', 'reach' ) ?></strong></p>

					                <pre><?php echo htmlspecialchars( '<iframe src="' . charitable_get_permalink( 'campaign_widget_page' ) . '" width="275px" height="468px" frameborder="0" scrolling="no" /></iframe>' ) ?></pre>

					            </div>

					            <div class="block iframe-block">

					                <p><strong><?php _e( 'Preview', 'reach' ) ?></strong></p>

					                <iframe src="<?php echo charitable_get_permalink( 'campaign_widget_page' ) ?>" width="275px" height="468px" frameborder="0" scrolling="no" /></iframe>

					            </div>

					        </div>

					    </li>   

					</ul>

				</div><!-- .leaderboard-sharing-block -->

			        <div style="clear: both;"></div>					

			    </div><!-- .shadow-wrapper -->

			</section>			

			

			<div class="layout-wrapper">

				<main class="site-main content-area" role="main">

					<div class="campaigns-grid-wrapper">																			

						<?php get_template_part( 'partials/content', 'leaderboard' ); ?>

					</div>

				</main><!-- .site-main -->

				<?php 

					//get_sidebar('leaderboard');				

				?>

			</div><!-- .layout-wrapper -->

		<?php 

		endwhile;

	endif;



get_footer();