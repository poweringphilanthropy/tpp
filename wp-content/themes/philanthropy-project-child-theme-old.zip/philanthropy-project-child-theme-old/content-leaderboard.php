<article id="post-<?php the_ID() ?>" <?php post_class() ?>>

    <div class="entry cf">
        <?php
        global $current_tax_terms_ids, $campaigns, $imploded_arr, $assoc_campaign_ids, $assoc_campaigns;
        $organization_input = (!empty($_REQUEST["organisation"]) ? $_REQUEST["organisation"] : null);
        $city_input = (!empty($_REQUEST["city"]) ? $_REQUEST["city"] : null);
        $state_input = (!empty($_REQUEST["state"]) ? $_REQUEST["state"] : null);
        $country_input = (!empty($_REQUEST["country"]) ? $_REQUEST["country"] : null);
        $gradelevel_input = (!empty($_REQUEST["gradelevel"]) ? $_REQUEST["gradelevel"] : null);

        $inputArray = array();
        if($organization_input){
            $inputArray['organisation'] = $organization_input;
        }
        if($city_input){
            $inputArray['city'] = $city_input;
        }
        if($state_input){
            $inputArray['state'] = $state_input;
        }
        if($country_input){
            $inputArray['country'] = $country_input;
        }
        if($gradelevel_input){
            $inputArray['grade_level'] = $gradelevel_input;
        }

        // Get leaderboard cause query
        $leaderboard_cause_filter = $_REQUEST["campaign_cause"];
        //echo $leaderboard_cause_filter;

        // Query campaigns based on the user id result
        $taxQ = array();
        if ($leaderboard_cause_filter) {
            $taxQ[] = array(
                'taxonomy' => 'campaign_category',
                'field' => 'slug',
                'terms' => $leaderboard_cause_filter,
            );
        }
        if ($current_tax_terms_ids) {
            $taxQ[] = array(
                'taxonomy' => 'campaign_group',
                'field' => 'term_id',
                'terms' => $current_tax_terms_ids,
                'operator' => 'IN'
            );
        }
        if (count($taxQ) > 1) {
            $taxQ['relation'] = 'AND';
        }

        $campaignsQ = Charitable_Campaigns::query(array(
                                                      'post_status' => 'publish',
                                                      'posts_per_page' => -1,
                                                      'tax_query' => $taxQ,
                                                  )
        );
        $campIds = array();
        if ($campaignsQ->have_posts()) {
            while($campaignsQ->have_posts()) {
                $campaignsQ->the_post();
                $cID = get_the_ID();
                $campData = get_post_meta($cID,'_campaign_submission_data', true);
                $camDataArray = array();
                $camDataArray['organisation'] = !empty($campData['organisation']) ? $campData['organisation'] : null;
                $camDataArray['city'] = !empty($campData['city']) ? $campData['city'] : null;
                $camDataArray['state'] = !empty($campData['state']) ? $campData['state'] : null;
                $camDataArray['country'] = !empty($campData['country']) ? $campData['country'] : null;
                $camDataArray['grade_level'] = !empty($campData['grade_level']) ? $campData['grade_level'] : null;
                $trigger = true;
                if(!empty($inputArray)){
                    foreach ($inputArray as $key => $value){

                        if($camDataArray[$key] != $value){
                            $trigger = false;
                        }
                    }
                }
                if($trigger){
                    $campIds[] = $cID;
                }

            }
        }

        wp_reset_postdata();

        $paged = $_REQUEST['nav']  ? $_REQUEST['nav'] : 1;
        $campaignListQ = Charitable_Campaigns::query(array(
                                                         'post_status' => 'publish',
                                                         'paged' => $paged,
                                                         'post__in' => $campIds
                                                     )
        );

        if ($campaignListQ->have_posts()) {
            charitable_template_campaign_loop($campaignListQ, 3);
        } else {
            echo "<h4 style='text-align: center;'>There are no campaigns that meet your search criteria.</h4>";
        }
        wp_reset_postdata();

        /* Restore original Post Data */
        $total_pages = $campaignListQ->max_num_pages;
        if ($total_pages > 1) {
            $current_page = max(1, $_REQUEST['nav']);
            echo '<div class="page_nav">';
            echo paginate_links(array(
                                    'base' => get_the_permalink() . '%_%',
                                    'format' => '?nav=%#%',
                                    'current' => $current_page,
                                    'total' => $total_pages,
                                    'prev_text' => 'Prev',
                                    'next_text' => 'Next'
                                ));
            echo '</div>';
        }

        ?>

    </div>

</article>
