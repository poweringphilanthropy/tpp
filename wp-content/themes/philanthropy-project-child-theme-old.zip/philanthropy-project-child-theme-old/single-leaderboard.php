<?php 
/**
 * Single leaderboard template.
 *
 * @package Reach
 */
get_header();

$leaderboard_id = $post->ID;
$current_tax_terms_ids = wp_get_post_terms($leaderboard_id, campaign_group, array(
	'fields' => 'ids'
) );

// associated campaign query
$campaigns = Charitable_Campaigns::query( array( 	
	'post_status' => 'publish',
	'posts_per_page' => -1,		        
	'tax_query' => array(
		array(
			'taxonomy' => 'campaign_group',
			'field'    => 'term_id',															
			'terms'    => $current_tax_terms_ids,
			'operator' => 'IN'
		)
	    )
	) 
);

// Associated Campaigns
$assoc_campaigns = $campaigns->posts;
//print_r($assoc_campaigns[1]);

$assoc_campaigns[] = array();

foreach ($assoc_campaigns as $assoc_campaign) {
	$assoc_campaign_ids[] = $assoc_campaign->ID;	
}

$imploded_arr = implode(',',$assoc_campaign_ids);
$imploded_arr = substr($imploded_arr, 0, -1);
//print_r($imploded_arr);

// Count the number of associated stats
foreach($assoc_campaign_ids as $assoc_campaign_id) {
	$campaign_submission_data = get_post_meta($assoc_campaign_id, '_campaign_submission_data', true);
	if (is_array($campaign_submission_data)) {
		// city
		$campaign_city = $campaign_submission_data[city];
		$campaign_cities[] = $campaign_city;				
		// state
		$campaign_state = $campaign_submission_data[state];
		$campaign_states[] = $campaign_state;
		// country
		$campaign_country = $campaign_submission_data[country];
		$campaign_countries[] = $campaign_country;
		// organisation
		$campaign_organisation = $campaign_submission_data[organisation];
		$campaign_organisations[] = $campaign_organisation;		
	}
}
if ($campaign_cities != '' || $campaign_cities != NULL) {
	$filtered_cities = array_unique(array_filter($campaign_cities));
	//echo "Cities: ";
	//print_r($filtered_cities);
}
//echo "<br />";
if ($campaign_states != '' || $campaign_states != NULL) {
	$filtered_states = array_unique(array_filter($campaign_states));
	//echo "States: ";
	//print_r($filtered_states);
}
//echo "<br />";
if ($campaign_countries != '' || $campaign_countries != NULL) {
	$filtered_countries = array_unique(array_filter($campaign_countries));
	//echo "Countries: ";
	//print_r($filtered_countries);
}
//echo "<br />";
if ($campaign_organisations != '' || $campaign_organisations != NULL) {
	$filtered_organisations = array_unique(array_filter($campaign_organisations));
	//echo "Organizations: ";
	//print_r($filtered_organisations);
}

// Get associated campaign's total donation
global $wpdb;
$donation = $wpdb->get_results("SELECT SUM(amount) AS total FROM wp_frank_charitable_campaign_donations WHERE campaign_id IN ($imploded_arr)");
$result = $donation[0];
$single_campaign_donation = $result->total;
// echo bcdiv($single_campaign_donation, 1, 2);

// Query campaigns based on the user id result
$campaigns_by_author_search = Charitable_Campaigns::query( array( 	
	'post_status' => 'publish',			        
	'author' => $user_query_search_arr,								
	'tax_query' => array(
		array(
			'taxonomy' => 'campaign_group',
			'field'    => 'term_id',															
			'terms'    => $current_tax_terms_ids,
			'operator' => 'IN'
		)
	   )					
	) 
);
						
// Get the campaign author ids for the leaderboard stats
$campaign_posts = $campaigns_by_author_search->posts;
//print_r($campaign_posts);

foreach	($campaign_posts as $campaign_post) {
	$campaign_post_author_id[] = $campaign_post->post_author;	
}

//print_r($campaign_post_author_id);
// only implode if $campaign_post_author_id is not empty to avoid PHP warning
if ($campaign_post_author_id != '' || $campaign_post_author_id != NULL ) {
	$implode_author_ids = implode(',',$campaign_post_author_id);
	//echo $implode_author_ids;
}

if ( have_posts() ) {
	while ( have_posts() ) {
		the_post(); ?>
		
		<section class="campaign-summary current-campaign feature-block cf ">
			    <div class="shadow-wrapper">
			        <div class="layout-wrapper leaderboard-content">			        	
    				    	<div class="ezcol ezcol-one-half">
    				    		<div class="campaign-image-campaign-thumbnail-large leaderboard-featured-img">
	    						<?php if ( has_post_thumbnail() ) {
	    								the_post_thumbnail(); 
	    					     		}
	    						?>
    				    		</div> 
    				    	</div><!-- end .ezcol-one-half --> 
    				    	<div class="ezcol ezcol-one-half ezcol-last">   
    				    		<h1 class="leaderboard-title">
			            			<?php the_title(); ?>
				            	</h1>
				            	<div class="campaign-description">      
	    						<?php the_content(); ?>
	    				   	</div> 			   	
		    				<div class="leaderboard-details cf barometer-added">
		    					<?php 
		    						$leaderboard_stats = get_field('leaderboard_stats'); 	
			    					//print_r($leaderboard_stats);			
		    					?>
		    					<?php if ($leaderboard_stats != '' || $leaderboard_stats != NULL) {
		    						if ( in_array('campaigns', $leaderboard_stats) ) { ?> 
			    					<div class="ezcol ezcol-one-fifth">
							            	<p class="leaderboard-campaign-stat">    
										<span class="leaderboard-stat-figure">
											<?php 											
												echo $campaigns->found_posts;
											?>
										</span>
									        <span class="leaderboard-stat-label">Campaigns</span>						
									</p> 
								</div>
							<?php } } ?>														
							<?php if ($leaderboard_stats != '' || $leaderboard_stats != NULL) {
								if ( in_array('cities', $leaderboard_stats) ) { ?>							
								<div class="ezcol ezcol-one-fifth">
									<p class="leaderboard-impact-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 	
									        		// Total associated cities
												$total_cities = sizeof($filtered_cities);
												echo $total_cities;									        	
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Cities</span>
									</p>	
								</div>	
							<?php } } ?>
							<?php if ($leaderboard_stats != '' || $leaderboard_stats != NULL) {
								if ( in_array('states', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-fifth">
									<p class="leaderboard-impact-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		// Total associated states
												$total_states = sizeof($filtered_states);
												echo $total_states;
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">States</span>
									</p>	
								</div>	
							<?php } } ?>
							<?php if ($leaderboard_stats != '' || $leaderboard_stats != NULL) {
								if ( in_array('countries', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-fifth">
									<p class="leaderboard-impact-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		// Total associated countries
												$total_countries = sizeof($filtered_countries);
												echo $total_countries;
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Countries</span>
									</p>	
								</div>	
							<?php } } ?>
							<?php if ($leaderboard_stats != '' || $leaderboard_stats != NULL) {
								if ( in_array('donated_charity', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-third">
									<p class="leaderboard-donations-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		echo "$" . bcdiv($single_campaign_donation, 1, 2); 
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Donated to charity</span>
									</p>  
								</div>
							<?php } } ?>
							<?php if ($leaderboard_stats != '' || $leaderboard_stats != NULL) {
								if ( in_array('schools_organizations', $leaderboard_stats) ) { ?>
								<div class="ezcol">  
									<p class="leaderboard-volunteers-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		// Total associated organisations
												$total_organisations = sizeof($filtered_organisations);
												echo $total_organisations;									        	
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Schools/Organizations</span>
									</p>
								</div>
							<?php } } ?>				
							<!-- <div class="campaign-countdown">
							    <span class="countdown is-countdown" data-enddate="15 April 2016 00:00:00"><span class="countdown-row countdown-show4"><span class="countdown-section"><span class="countdown-amount">33</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">10</span><span class="countdown-period">Hours</span></span><span class="countdown-section"><span class="countdown-amount">37</span><span class="countdown-period">Minutes</span></span><span class="countdown-section"><span class="countdown-amount">3</span><span class="countdown-period">Seconds</span></span></span></span>
							    <span>Countdown</span>
							</div>            
						</div><!-- .leaderboard-details -->	
					</div><!-- end .ezcol-one-half ezcol-last		            						
			        </div><!-- .layout-wrapper -->
				<div class="leaderboard-sharing-block">
					<ul class="leaderboard-sharing share horizontal rrssb-buttons rrssb-1">
					    <li data-initwidth="14.285714285714286" style="width: 14.2857%;"><h6>Share</h6></li>
					    <li class="share-twitter" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="http://twitter.com/home?status=<?php echo $title ?>%20<?php echo $permalink ?>" class="popup icon" data-icon="&#xf099;"></a>
					    </li>
					    <li class="share-facebook" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $permalink ?>" class="popup icon" data-icon="&#xf09a;"></a>
					    </li>
					    <li class="share-googleplus" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="https://plus.google.com/share?url=<?php echo $title . $permalink ?>" class="popup icon" data-icon="&#xf0d5;"></a>
					    </li>
					    <li class="share-linkedin" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo $permalink ?>&amp;title=<?php echo $title ?>" class="popup icon" data-icon="&#xf0e1;"></a>
					    </li>
					    <li class="share-pinterest" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="http://pinterest.com/pin/create/button/?url=<?php echo $permalink ?>&amp;description=<?php echo $title ?>" class="popup icon" data-icon="&#xf0d2;"></a>
					    </li>
					    <li class="share-widget" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#campaign-widget-<?php the_ID() ?>" class="icon" data-icon="&#xf121;" data-trigger-modal></a>
					        <div id="campaign-widget-<?php the_ID() ?>" class="modal">
					            <a class="modal-close"></a>         
					            <h4 class="block-title"><?php _e( 'Share Campaign', 'reach' ) ?></h4>
					            <div class="block"> 
					                <?php echo apply_filters( 'the_excerpt', get_theme_mod( 'campaign_sharing_text', '' ) ) ?>
					                <p><strong><?php _e( 'Embed Code', 'reach' ) ?></strong></p>
					                <pre><?php echo htmlspecialchars( '<iframe src="' . charitable_get_permalink( 'campaign_widget_page' ) . '" width="275px" height="468px" frameborder="0" scrolling="no" /></iframe>' ) ?></pre>
					            </div>
					            <div class="block iframe-block">
					                <p><strong><?php _e( 'Preview', 'reach' ) ?></strong></p>
					                <iframe src="<?php echo charitable_get_permalink( 'campaign_widget_page' ) ?>" width="275px" height="468px" frameborder="0" scrolling="no" /></iframe>
					            </div>
					        </div>
					    </li>   
					</ul>
				</div><!-- .leaderboard-sharing-block -->
			        <div style="clear: both;"></div>					
			    </div><!-- .shadow-wrapper -->
			</section>	

			<div class="layout-wrapper">
				<main class="site-main content-area" role="main">
					<div class="campaigns-grid-wrapper">
						<div class="leaderboard-author-search">
							<?php global $current_page_url; ?>
							<form method="GET" action="<?php $current_page_url; ?>">
								<div class="one_sixth">
									<div class="filter-inner">									
										<input type="text" name="author_organisation" value="<?php echo !empty($_REQUEST['author_organisation']) ? $_REQUEST['author_organisation'] : null; ?>" placeholder="School Name">
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<input type="text" name="author_city" value="<?php echo !empty($_REQUEST['author_city']) ? $_REQUEST['author_city'] : null; ?>" placeholder="City">
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">
										<input type="text" name="author_state" value="<?php echo !empty($_REQUEST['author_state']) ? $_REQUEST['author_state'] : null; ?>" placeholder="State">
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<select list="countries" name="author_country"> 
											<option value="" disabled selected>Country</option>
											<option value="">Select</option>
											<!-- missing code here -->
										</select>
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<select list="gradelevel" name="author_gradelevel"> 
											<option value="" disabled selected>Grade Level</option>
											<!-- missing code here -->
										</select>
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">
										<?php
											// Get campaign cause
											$campaign_categories = get_terms( 'campaign_category', 'orderby=count&hide_empty=0' );
										?>

										<select name="campaign_cause">
											<option value="" disabled selected>Cause</option>
											<?php
												$campaign_posts = $campaigns->posts;
												foreach ($campaign_posts as $campaign_post) {
													$category_names = get_the_terms( $campaign_post->ID, 'campaign_category' );
													foreach ($category_names as $category_name) {
														$category_term_name[$category_name->slug] = $category_name->name;
													}
												}
												$category_term_name = array_unique($category_term_name);
												$catValue = !empty($_REQUEST['campaign_cause']) ? $_REQUEST['campaign_cause'] : null;
												foreach ($category_term_name as $key => $value) {
													$causeSlt = ($key == $catValue ? "selected" : null);
													echo "<option value='{$key}' {$causeSlt}>{$value}</option>";
												}
											?>

										</select>
									</div>									
								</div>
								<div class="filter-inner submit">
									<input type="submit" value="FILTER">
                                    	<a href="<?php the_permalink(); ?>" class="reset_btn">CLEAR</a>	
								</div>
							</form>
						</div>
						<?php get_template_part( 'partials/content', 'leaderboard' ); ?>
					</div>
				</main>
			</div><!-- .layout-wrapper -->

	<?php } // end while
} // end if

get_footer(); ?>