		<article id="post-<?php the_ID() ?>" <?php post_class() ?>>			
		
			<div class="entry cf">
				<?php 					
				    	global $current_tax_terms_ids, $campaigns, $imploded_arr, $assoc_campaign_ids, $assoc_campaigns;
				    	
				    	$organization_input = $_GET["author_organisation"];
						//echo $organization_input;
						
						$city_input = $_GET["author_city"];
						//echo $city_input;
						
						$state_input = $_GET["author_state"];
						//echo $state_input;
						
						$country_input = $_GET["author_country"];
						//echo $country_input;
						
						$gradelevel_input = $_GET["author_gradelevel"];
						//echo $gradelevel_input;
						
						// Get user by school name or organisation
						if ( $organization_input != '' || $organization_input != NULL ) {
							//echo "ORGANISATION INPUT IS NOT EMPTY<br/>";
							$user_query_organisation = new WP_User_Query( array( 'meta_key' => 'organisation', 'meta_value' => $organization_input ) );
							// Query results [organisation]
							$organisation_results = $user_query_organisation->results;
							$organisation_results[] = array();
							
							// Get the user id of each organisation result
							foreach ($organisation_results as $organisation_result) {							
								$organisation_user_id_result[] = $organisation_result->ID;
							}
							
							$user_query_organisation_arr = array_filter($organisation_user_id_result);		
							$implode_user_query_organisation_arr = implode(', ',$user_query_organisation_arr);
							//echo $implode_user_query_organisation_arr;
						
						}
						
						// Get user by location
						if ( $city_input != '' || $city_input != NULL ) {
							//echo "CITY INPUT IS NOT EMPTY<br/>";
							$user_query_city = new WP_User_Query( array( 'meta_key' => 'location', 'meta_value' => $city_input ) );
							// Query results [city]
							$city_results = $user_query_city->results;
							$city_results[] = array();
							
							// Get the user id of each city result
							foreach ($city_results as $city_result) {							
								$city_user_id_result[] = $city_result->ID;
							}							
							
							$user_query_city_arr = array_filter($city_user_id_result);		
							$implode_user_query_city_arr = implode(', ',$user_query_city_arr);
							//echo $implode_user_query_city_arr;
						
						}
						
						// Get user by state
						if ( $state_input != '' || $state_input != NULL ) {
							//echo "STATE INPUT IS NOT EMPTY<br/>";
							$user_query_state = new WP_User_Query( array( 'meta_key' => 'donor_state', 'meta_value' => $state_input ) );
							// Query results [state]
							$state_results = $user_query_state->results;
							$state_results[] = array();
							
							// Get the user id of each state result
							
							foreach ($state_results as $state_result) {							
								$state_user_id_result[] = $state_result->ID;								
							}							 							
							
							$user_query_state_arr = array_filter($state_user_id_result);		
							$implode_user_query_state_arr = implode(', ',$user_query_state_arr);
							//echo $implode_user_query_state_arr;
						
						}
						
						// Get user by country
						if ( $country_input != '' || $country_input != NULL ) {
							//echo "COUNTRY INPUT IS NOT EMPTY<br/>";
							$user_query_country = new WP_User_Query( array( 'meta_key' => 'donor_country', 'meta_value' => $country_input ) );
							// Query results [country]
							$country_results = $user_query_country->results;
							$country_results[] = array();																		
							
							// Get the user id of each country result							
							foreach ($country_results as $country_result) {							
								$country_user_id_result[] = $country_result->ID;															
							}													
							
							$user_query_country_arr = array_filter($country_user_id_result);		
							$implode_user_query_country_arr = implode(', ',$user_query_country_arr);
							//echo $implode_user_query_country_arr;							
						}
						
						// Get user by Grade Level
						if ( $gradelevel_input != '' || $gradelevel_input != NULL ) {
							//echo "GRADE LEVEL INPUT IS NOT EMPTY<br/>";
							$user_query_gradelevel = new WP_User_Query( array( 'meta_key' => 'grade_level', 'meta_value' => $gradelevel_input ) );
							// Query results [gradelevel]
							$gradelevel_results = $user_query_gradelevel->results;
							$gradelevel_results[] = array();
							
							// Get the user id of each gradelevel result							
							foreach ($gradelevel_results as $gradelevel_result) {							
								$gradelevel_user_id_result[] = $gradelevel_result->ID;								
							}													
							
							$user_query_gradelevel_arr = array_filter($gradelevel_user_id_result);		
							$implode_user_query_gradelevel_arr = implode(', ',$user_query_gradelevel_arr);
							//echo $implode_user_query_gradelevel_arr;							
						}
						
					$user_query_search_arr = $implode_user_query_organisation_arr . '' . $implode_user_query_city_arr . '' . $implode_user_query_state_arr . '' . $implode_user_query_country_arr . '' . $implode_user_query_gradelevel_arr;
							
						//echo $user_query_search_arr;
						
						// Get leaderboard cause query
						$leaderboard_cause_filter = $_GET["campaign_cause"];						
						//echo $leaderboard_cause_filter;
						
						// Get campaigns on this leaderboard by category
						if ( $leaderboard_cause_filter != '' || $leaderboard_cause_filter != NULL ) {	
							$args = array(	
								'post_status' => 'publish', 
								'tax_query' => array(	
									array(
										'taxonomy' => 'campaign_category',
										'field'    => 'slug',
										'terms'    => $leaderboard_cause_filter,
									),
								),
							);
							
							$leaderboard_cause_query = new WP_Query( $args );

							// Query results [city]
							$leaderboard_cause_query_results = $leaderboard_cause_query->posts;
							$leaderboard_cause_query_results[] = array();
							//print_r($leaderboard_cause_query_results);

							// Get the id of each campaign category
							foreach ($leaderboard_cause_query_results as $leaderboard_cause_query_result) {
								$leaderboard_cause_query_result_id[] = $leaderboard_cause_query_result->ID;	
								//echo "<li>" . $leaderboard_cause_query_result->ID . "</li>";							
							}	
							//print_r($leaderboard_cause_query_result_id);										
							
							// Filter empty and implode
							$leaderboard_cause_query_result_id_arr = array_filter($leaderboard_cause_query_result_id);		
							$implode_leaderboard_cause_query_result_id_arr = implode(',',$leaderboard_cause_query_result_id_arr);							
							//print_r($implode_leaderboard_cause_query_result_id_arr);							
						}	
						
						
						
						// Put 0 if empty
						if ( $user_query_search_arr == '' ) {
							$user_query_search_arr = 0;
						}					
												
						// Query campaigns based on the user id result
						$campaigns_by_author_search = Charitable_Campaigns::query( array( 	
							'post_status' => 'publish',			        
							'author' => $user_query_search_arr,								
							'tax_query' => array(
								array(
									'taxonomy' => 'campaign_group',
									'field'    => 'term_id',															
									'terms'    => $current_tax_terms_ids,
									'operator' => 'IN'
								)
							   ),
							'post__in' => $leaderboard_cause_query_result_id_arr					
							) 
						);
					
						$viewed_URL = curPageURL();
						$leaderboard_URL = get_the_permalink();
						$empty_url = get_the_permalink() . "?author_organisation=&author_city=&author_state=&author_country=&author_gradelevel=";
						$campaigns_posts = $campaigns->found_posts;
						//echo "<h2>Campaign Found Posts: " . $campaigns_posts . "</h2>";
						$campaigns_by_author_search_posts = $campaigns_by_author_search->found_posts;
						//echo "<h2>Filter Found Posts: " . $campaigns_by_author_search_posts . "</h2>";
						
						// Get the campaign author id
						$leaderboard_campaigns = $campaigns_by_author_search->posts;
						foreach ($leaderboard_campaigns as $leaderboard_campaign) {
							//echo "<li>" . $leaderboard_campaign->post_author . "</li>";
							$post_author[] = $leaderboard_campaign->post_author;
						}
						$post_author[] = array();							
						// Remove extra empty key from the array					
						$filtered_post_author = array_filter($post_author);
						// Avoid duplicate in the array						
						$filtered_post_author = array_unique($filtered_post_author);
						//print_r($filtered_post_author);
						
						// Turn $user_query_search_arr as an array in preparation for in_array_any function
						$user_id_arr = explode(',',$user_query_search_arr);
						//print_r($user_id_arr);
						
						// $campaigns_by_author_search query results 
						$campaigns_by_author_search_authors = $campaigns_by_author_search->query['author'];
						$exploded_campaigns_by_author_search_authors = explode(',',$campaigns_by_author_search_authors);
						//print_r($exploded_campaigns_by_author_search_authors);
						
						// Check if ANY id result of the query is present in the array of author ids $post_author
						function in_array_any($filtered_post_author, $user_id_arr ) {
						   return !!array_intersect($filtered_post_author, $user_id_arr);
						}			
						
						// Set the condition on what to show per frontend filter query
						if ( in_array_any( $filtered_post_author, $user_id_arr ) ) {
							//echo "True<br/>"; //true, since an integer is present
							charitable_template_campaign_loop( $campaigns_by_author_search, 3 );
						} elseif ( isset($_GET['author_country']) && $campaigns_by_author_search_authors != 0 && $campaigns_by_author_search_posts != 0 ) {							
							charitable_template_campaign_loop( $campaigns_by_author_search, 3 );
						} elseif ( isset($_GET['campaign_cause']) && $campaigns_by_author_search_posts != 0 ) {							
							charitable_template_campaign_loop( $campaigns_by_author_search, 3 );
						} elseif ( $viewed_URL == $leaderboard_URL ) {							
							charitable_template_campaign_loop( $campaigns_by_author_search, 3 );						
						} else {
							//echo "False"; //false, since not a single integer is present
							echo "<h4 style='text-align: center;'>There are no campaigns that meet your search criteria.</h4>";
						}
				
				?>				
				
				    <?php 
				    //wp_reset_postdata();
				
				    //if ( $campaigns->max_num_pages > 1 ) : 
				    
				    ?> 
				
				        <p class="center">
				            <!-- <a class="button button-alt" href="<?php echo site_url( apply_filters( 'reach_previous_campaigns_link', '/campaigns/page/2/' ) ) ?>">
				                <?php //echo apply_filters( 'reach_previous_campaigns_text', __( 'Previous Campaigns', 'reach' ) ) ?>
				            </a> -->
				            <a class="button button-alt" href="<?php the_permalink(); ?>">See All</a>
				        </p>
				
				 <?php //endif; 
				 ?>
			</div>						

		</article>