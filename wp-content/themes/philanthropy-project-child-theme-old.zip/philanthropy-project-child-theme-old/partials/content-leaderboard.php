		<article id="post-<?php the_ID() ?>" <?php post_class() ?>>			

		

			<div class="entry cf">

				<?php 					

				    	global $current_tax_terms_ids, $campaigns, $imploded_arr, $assoc_campaign_ids, $assoc_campaigns;


						// Query campaigns based on the user id result
						
						$default_posts_per_page_kzr = get_option( 'posts_per_page' );	
						
						//$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;	
						if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {$paged = get_query_var('page'); } else {$paged = 1; }				

						$campaigns_by_author_search = Charitable_Campaigns::query( array( 						
							'paged'			=> $paged,		
							'post_status' => 'publish',
							'author' => $user_query_search_arr,
							//'posts_per_page' 	=> 6,	
							'tax_query' => array(
								array(
									'taxonomy' => 'campaign_group',
									'field'    => 'term_id',	
									'terms'    => $current_tax_terms_ids,
									'operator' => 'IN',		
								)
							   )	
							) 
						);

						charitable_template_campaign_loop( $campaigns_by_author_search, 3 );
						
				?>		

			</div>						



		</article>