<?php 
/**
 * Single leaderboard template.
 *
 * @package Reach
 */
get_header();

$leaderboard_id = $post->ID;
$current_tax_terms_ids = wp_get_post_terms($leaderboard_id, campaign_group, array(
	'fields' => 'ids'
) );

// associated campaign query
$campaigns = Charitable_Campaigns::query( array( 	
	'post_status' => 'publish',			        
	'tax_query' => array(
		array(
			'taxonomy' => 'campaign_group',
			'field'    => 'term_id',															
			'terms'    => $current_tax_terms_ids,
			'operator' => 'IN'
		)
	    )
	) 
);

// Associated Campaigns
$assoc_campaigns = $campaigns->posts;
//print_r($assoc_campaigns[1]);

$assoc_campaigns[] = array();

foreach ($assoc_campaigns as $assoc_campaign) {
	$assoc_campaign_ids[] = $assoc_campaign->ID;	
}

$imploded_arr = implode(',',$assoc_campaign_ids);
$imploded_arr = substr($imploded_arr, 0, -1);
//print_r($imploded_arr);

// Get associated campaign's total donation
global $wpdb;
$donation = $wpdb->get_results("SELECT SUM(amount) AS total FROM wp_frank_charitable_campaign_donations WHERE campaign_id IN ($imploded_arr)");
$result = $donation[0];
$single_campaign_donation = $result->total;
// echo bcdiv($single_campaign_donation, 1, 2);

// Query campaigns based on the user id result
$campaigns_by_author_search = Charitable_Campaigns::query( array( 	
	'post_status' => 'publish',			        
	'author' => $user_query_search_arr,								
	'tax_query' => array(
		array(
			'taxonomy' => 'campaign_group',
			'field'    => 'term_id',															
			'terms'    => $current_tax_terms_ids,
			'operator' => 'IN'
		)
	   )					
	) 
);
						
// Get the campaign author ids for the leaderboard stats
$campaign_posts = $campaigns_by_author_search->posts;
//print_r($campaign_posts);

foreach	($campaign_posts as $campaign_post) {
	$campaign_post_author_id[] = $campaign_post->post_author;	
}

//print_r($campaign_post_author_id);
// only implode if $campaign_post_author_id is not empty to avoid PHP warning
if ($campaign_post_author_id != '' || $campaign_post_author_id != NULL ) {
	$implode_author_ids = implode(',',$campaign_post_author_id);
	//echo $implode_author_ids;
}
						
// Get the total schools/organisations associated with this leaderboard
$total_schools_organisations = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'organisation' AND `meta_value` != ''");
$total_schools_organisations_result = $total_schools_organisations[0];
$schools_organisations_number = $total_schools_organisations_result->total;

// Get the total cities associated with this leaderboard
$total_cities = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'location' AND `meta_value` != ''");
$total_cities_result = $total_cities[0];
$cities_number = $total_cities_result->total;

// Get the total states associated with this leaderboard
$total_states = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'donor_state' AND `meta_value` != ''");
$total_states_result = $total_states[0];
$states_number = $total_states_result->total;

// Get the total countries associated with this leaderboard
$total_countries = $wpdb->get_results("SELECT COUNT(*) AS total FROM `wp_frank_usermeta` WHERE `user_id` IN ($implode_author_ids) AND `meta_key` = 'donor_country' AND `meta_value` != ''");
$total_countries_result = $total_countries[0];
$countries_number = $total_countries_result->total;
	
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post(); ?>			
			<section class="campaign-summary current-campaign feature-block cf ">
			    <div class="shadow-wrapper">
			        <div class="layout-wrapper leaderboard-content">			        	
    				    	<div class="ezcol ezcol-one-quarter">
    				    		<div class="leaderboard-image">
	    						<?php if ( has_post_thumbnail() ) {
	    								the_post_thumbnail('leaderboard-featured-img'); 
	    					     		}
	    						?>
    				    		</div> 
    				    	</div><!-- end .ezcol-one-quarter --> 
    				    	<div class="ezcol ezcol-three-quarter ezcol-last">   
    				    		<h1 class="leaderboard-title">
			            			<?php the_title(); ?>
				            	</h1>
				            	<div class="campaign-description">      
	    						<?php the_content(); ?>
	    				   	</div> 			   	
		    				<div class="leaderboard-details cf barometer-added">
		    					<?php 
		    						$leaderboard_stats = get_field('leaderboard_stats'); 	
		    						//print_r($leaderboard_stats);	    						
		    					?>
		    					<?php if ( in_array('campaigns', $leaderboard_stats) ) { ?> 
			    					<div class="ezcol ezcol-one-fifth">
							            	<p class="leaderboard-campaign-stat">    
										<span class="leaderboard-stat-figure">
											<?php 											
												echo $campaigns->post_count;	
											?>
										</span>
									        <span class="leaderboard-stat-label">Campaigns</span>						
									</p> 
								</div>
							<?php } ?>
							<?php if ( in_array('donated_charity', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-quarter">
									<p class="leaderboard-donations-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		echo "$" . bcdiv($single_campaign_donation, 1, 2); 
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Donated to charity</span>
									</p>  
								</div>
							<?php } ?>
							<?php if ( in_array('schools_organizations', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-quarter">  
									<p class="leaderboard-volunteers-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		if ($schools_organisations_number != '' || $schools_organisations_number != NULL ) {
									        			echo $schools_organisations_number; 
									        		} else {
									        			echo "0";
									        		}									        	
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Schools/Organizations</span>
									</p>
								</div>
							<?php } ?>
							<?php if ( in_array('cities', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-quarter">
									<p class="leaderboard-impact-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		if ($cities_number != '' || $cities_number != NULL ) {
									        			echo $cities_number; 
									        		} else {
									        			echo "0";
									        		}									        	
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Cities</span>
									</p>	
								</div>	
							<?php } ?>
							<?php if ( in_array('states', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-quarter">
									<p class="leaderboard-impact-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		if ($states_number != '' || $states_number != NULL ) {
									        			echo $states_number; 
									        		} else {
									        			echo "0";
									        		}
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">States</span>
									</p>	
								</div>	
							<?php } ?>
							<?php if ( in_array('countries', $leaderboard_stats) ) { ?>
								<div class="ezcol ezcol-one-quarter">
									<p class="leaderboard-impact-stat">
									        <span class="leaderboard-stat-figure">
									        	<?php 
									        		if ($countries_number != '' || $countries_number != NULL ) {
									        			echo $countries_number; 
									        		} else {
									        			echo "0";
									        		}
									        	?>
									        </span> 
										<span class="leaderboard-stat-label">Countries</span>
									</p>	
								</div>	
							<?php } ?>				
							<!-- <div class="campaign-countdown">
							    <span class="countdown is-countdown" data-enddate="15 April 2016 00:00:00"><span class="countdown-row countdown-show4"><span class="countdown-section"><span class="countdown-amount">33</span><span class="countdown-period">Days</span></span><span class="countdown-section"><span class="countdown-amount">10</span><span class="countdown-period">Hours</span></span><span class="countdown-section"><span class="countdown-amount">37</span><span class="countdown-period">Minutes</span></span><span class="countdown-section"><span class="countdown-amount">3</span><span class="countdown-period">Seconds</span></span></span></span>
							    <span>Countdown</span>
							</div>            
						</div><!-- .leaderboard-details -->	
					</div><!-- end .ezcol-three-quarter ezcol-last		            						
			        </div><!-- .layout-wrapper -->
				<div class="leaderboard-sharing-block">
					<ul class="leaderboard-sharing share horizontal rrssb-buttons rrssb-1">
					    <li data-initwidth="14.285714285714286" style="width: 14.2857%;"><h6>Share</h6></li>
					    <li class="share-twitter" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="http://twitter.com/home?status=<?php echo $title ?>%20<?php echo $permalink ?>" class="popup icon" data-icon="&#xf099;"></a>
					    </li>
					    <li class="share-facebook" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $permalink ?>" class="popup icon" data-icon="&#xf09a;"></a>
					    </li>
					    <li class="share-googleplus" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="https://plus.google.com/share?url=<?php echo $title . $permalink ?>" class="popup icon" data-icon="&#xf0d5;"></a>
					    </li>
					    <li class="share-linkedin" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo $permalink ?>&amp;title=<?php echo $title ?>" class="popup icon" data-icon="&#xf0e1;"></a>
					    </li>
					    <li class="share-pinterest" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="http://pinterest.com/pin/create/button/?url=<?php echo $permalink ?>&amp;description=<?php echo $title ?>" class="popup icon" data-icon="&#xf0d2;"></a>
					    </li>
					    <li class="share-widget" data-initwidth="14.285714285714286" style="width: 14.2857%;">
					        <a href="#campaign-widget-<?php the_ID() ?>" class="icon" data-icon="&#xf121;" data-trigger-modal></a>
					        <div id="campaign-widget-<?php the_ID() ?>" class="modal">
					            <a class="modal-close"></a>         
					            <h4 class="block-title"><?php _e( 'Share Campaign', 'reach' ) ?></h4>
					            <div class="block"> 
					                <?php echo apply_filters( 'the_excerpt', get_theme_mod( 'campaign_sharing_text', '' ) ) ?>
					                <p><strong><?php _e( 'Embed Code', 'reach' ) ?></strong></p>
					                <pre><?php echo htmlspecialchars( '<iframe src="' . charitable_get_permalink( 'campaign_widget_page' ) . '" width="275px" height="468px" frameborder="0" scrolling="no" /></iframe>' ) ?></pre>
					            </div>
					            <div class="block iframe-block">
					                <p><strong><?php _e( 'Preview', 'reach' ) ?></strong></p>
					                <iframe src="<?php echo charitable_get_permalink( 'campaign_widget_page' ) ?>" width="275px" height="468px" frameborder="0" scrolling="no" /></iframe>
					            </div>
					        </div>
					    </li>   
					</ul>
				</div><!-- .leaderboard-sharing-block -->
			        <div style="clear: both;"></div>					
			    </div><!-- .shadow-wrapper -->
			</section>			
			
			<div class="layout-wrapper">
				<main class="site-main content-area" role="main">
					<div class="campaigns-grid-wrapper"> 
						
												
						<div class="leaderboard-author-search">
							<?php global $current_page_url; ?>
							<form method="get" action="<?php $current_page_url; ?>">
								<div class="one_sixth">
									<div class="filter-inner">									
										<input type="text" name="author_organisation" placeholder="School Name">
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<input type="text" name="author_city" placeholder="City">
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<select list="states" name="author_state">  
											<option value="" disabled selected>State</option>
											<option value="">Select</option>
											<option value="AL">Alabama</option>
											<option value="AK">Alaska</option>
											<option value="AZ">Arizona</option>
											<option value="AR">Arkansas</option>
											<option value="CA">California</option>
											<option value="CO">Colorado</option>
											<option value="CT">Connecticut</option>
											<option value="DE">Delaware</option>
											<option value="FL">Florida</option>
											<option value="GA">Georgia</option>
											<option value="HI">Hawaii</option>
											<option value="ID">Idaho</option>
											<option value="IL">Illinois</option>
											<option value="IN">Indiana</option>
											<option value="IA">Iowa</option>
											<option value="KS">Kansas</option>
											<option value="KY">Kentucky</option>
											<option value="LA">Louisiana</option>
											<option value="ME">Maine</option>
											<option value="MD">Maryland</option>
											<option value="MA">Massachusetts</option>
											<option value="MI">Michigan</option>
											<option value="MN">Minnesota</option>
											<option value="MS">Mississippi</option>
											<option value="MO">Missouri</option>
											<option value="MT">Montana</option>
											<option value="NE">Nebraska</option>
											<option value="NV">Nevada</option>
											<option value="NH">New Hampshire</option>
											<option value="NJ">New Jersey</option>
											<option value="NM">New Mexico</option>
											<option value="NY">New York</option>
											<option value="NC">North Carolina</option>
											<option value="ND">North Dakota</option>
											<option value="OH">Ohio</option>
											<option value="OK">Oklahoma</option>
											<option value="OR">Oregon</option>
											<option value="PA">Pennsylvania</option>
											<option value="RI">Rhode Island</option>
											<option value="SC">South Carolina</option>
											<option value="SD">South Dakota</option>
											<option value="TN">Tennessee</option>
											<option value="TX">Texas</option>
											<option value="UT">Utah</option>
											<option value="VT">Vermont</option>
											<option value="VA">Virginia</option>
											<option value="WA">Washington</option>
											<option value="WV">West Virgina</option>
											<option value="WI">Wisconsin</option>
											<option value="WY">Wyoming</option>
											<option value="Other">Other</option>
										</select>
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<select list="countries" name="author_country"> 
											<option value="" disabled selected>Country</option>
											<option value="">Select</option>
											<option value="AF">Afghanistan</option>
											<option value="AX">Åland Islands</option>
											<option value="AL">Albania</option>
											<option value="DZ">Algeria</option>
											<option value="AS">American Samoa</option>
											<option value="AD">Andorra</option>
											<option value="AO">Angola</option>
											<option value="AI">Anguilla</option>
											<option value="AQ">Antarctica</option>
											<option value="AG">Antigua and Barbuda</option>
											<option value="AR">Argentina</option>
											<option value="AM">Armenia</option>
											<option value="AW">Aruba</option>
											<option value="AU">Australia</option>
											<option value="AT">Austria</option>
											<option value="AZ">Azerbaijan</option>
											<option value="BS">Bahamas</option>
											<option value="BH">Bahrain</option>
											<option value="BD">Bangladesh</option>
											<option value="BB">Barbados</option>
											<option value="BY">Belarus</option>
											<option value="BE">Belgium</option>
											<option value="BZ">Belize</option>
											<option value="BJ">Benin</option>
											<option value="BM">Bermuda</option>
											<option value="BT">Bhutan</option>
											<option value="BO">Bolivia (Plurinational State of)</option>
											<option value="BQ">Bonaire, Sint Eustatius and Saba</option>
											<option value="BA">Bosnia and Herzegovina</option>
											<option value="BW">Botswana</option>
											<option value="BV">Bouvet Island</option>
											<option value="BR">Brazil</option>
											<option value="IO">British Indian Ocean Territory</option>
											<option value="BN">Brunei Darussalam</option>
											<option value="BG">Bulgaria</option>
											<option value="BF">Burkina Faso</option>
											<option value="BI">Burundi</option>
											<option value="CV">Cabo Verde</option>
											<option value="KH">Cambodia</option>
											<option value="CM">Cameroon</option>
											<option value="CA">Canada</option>
											<option value="KY">Cayman Islands</option>
											<option value="CF">Central African Republic</option>
											<option value="TD">Chad</option>
											<option value="CL">Chile</option>
											<option value="CN">China</option>
											<option value="CX">Christmas Island</option>
											<option value="CC">Cocos (Keeling) Islands</option>
											<option value="CO">Colombia</option>
											<option value="KM">Comoros</option>
											<option value="CG">Congo</option>
											<option value="CD">Congo (Democratic Republic of the)</option>
											<option value="CK">Cook Islands</option>
											<option value="CR">Costa Rica</option>
											<option value="CI">Côte d'Ivoire</option>
											<option value="HR">Croatia</option>
											<option value="CU">Cuba</option>
											<option value="CW">Curaçao</option>
											<option value="CY">Cyprus</option>
											<option value="CZ">Czech Republic</option>
											<option value="DK">Denmark</option>
											<option value="DJ">Djibouti</option>
											<option value="DM">Dominica</option>
											<option value="DO">Dominican Republic</option>
											<option value="EC">Ecuador</option>
											<option value="EG">Egypt</option>
											<option value="SV">El Salvador</option>
											<option value="GQ">Equatorial Guinea</option>
											<option value="ER">Eritrea</option>
											<option value="EE">Estonia</option>
											<option value="ET">Ethiopia</option>
											<option value="FK">Falkland Islands (Malvinas)</option>
											<option value="FO">Faroe Islands</option>
											<option value="FJ">Fiji</option>
											<option value="FI">Finland</option>
											<option value="FR">France</option>
											<option value="GF">French Guiana</option>
											<option value="PF">French Polynesia</option>
											<option value="TF">French Southern Territories</option>
											<option value="GA">Gabon</option>
											<option value="GM">Gambia</option>
											<option value="GE">Georgia</option>
											<option value="DE">Germany</option>
											<option value="GH">Ghana</option>
											<option value="GI">Gibraltar</option>
											<option value="GR">Greece</option>
											<option value="GL">Greenland</option>
											<option value="GD">Grenada</option>
											<option value="GP">Guadeloupe</option>
											<option value="GU">Guam</option>
											<option value="GT">Guatemala</option>
											<option value="GG">Guernsey</option>
											<option value="GN">Guinea</option>
											<option value="GW">Guinea-Bissau</option>
											<option value="GY">Guyana</option>
											<option value="HT">Haiti</option>
											<option value="HM">Heard Island and McDonald Islands</option>
											<option value="VA">Holy See</option>
											<option value="HN">Honduras</option>
											<option value="HK">Hong Kong</option>
											<option value="HU">Hungary</option>
											<option value="IS">Iceland</option>
											<option value="IN">India</option>
											<option value="ID">Indonesia</option>
											<option value="IR">Iran (Islamic Republic of)</option>
											<option value="IQ">Iraq</option>
											<option value="IE">Ireland</option>
											<option value="IM">Isle of Man</option>
											<option value="IL">Israel</option>
											<option value="IT">Italy</option>
											<option value="JM">Jamaica</option>
											<option value="JP">Japan</option>
											<option value="JE">Jersey</option>
											<option value="JO">Jordan</option>
											<option value="KZ">Kazakhstan</option>
											<option value="KE">Kenya</option>
											<option value="KI">Kiribati</option>
											<option value="KP">Korea (Democratic People's Republic of)</option>
											<option value="KR">Korea (Republic of)</option>
											<option value="KW">Kuwait</option>
											<option value="KG">Kyrgyzstan</option>
											<option value="LA">Lao People's Democratic Republic</option>
											<option value="LV">Latvia</option>
											<option value="LB">Lebanon</option>
											<option value="LS">Lesotho</option>
											<option value="LR">Liberia</option>
											<option value="LY">Libya</option>
											<option value="LI">Liechtenstein</option>
											<option value="LT">Lithuania</option>
											<option value="LU">Luxembourg</option>
											<option value="MO">Macao</option>
											<option value="MK">Macedonia (the former Yugoslav Republic of)</option>
											<option value="MG">Madagascar</option>
											<option value="MW">Malawi</option>
											<option value="MY">Malaysia</option>
											<option value="MV">Maldives</option>
											<option value="ML">Mali</option>
											<option value="MT">Malta</option>
											<option value="MH">Marshall Islands</option>
											<option value="MQ">Martinique</option>
											<option value="MR">Mauritania</option>
											<option value="MU">Mauritius</option>
											<option value="YT">Mayotte</option>
											<option value="MX">Mexico</option>
											<option value="FM">Micronesia (Federated States of)</option>
											<option value="MD">Moldova (Republic of)</option>
											<option value="MC">Monaco</option>
											<option value="MN">Mongolia</option>
											<option value="ME">Montenegro</option>
											<option value="MS">Montserrat</option>
											<option value="MA">Morocco</option>
											<option value="MZ">Mozambique</option>
											<option value="MM">Myanmar</option>
											<option value="NA">Namibia</option>
											<option value="NR">Nauru</option>
											<option value="NP">Nepal</option>
											<option value="NL">Netherlands</option>
											<option value="NC">New Caledonia</option>
											<option value="NZ">New Zealand</option>
											<option value="NI">Nicaragua</option>
											<option value="NE">Niger</option>
											<option value="NG">Nigeria</option>
											<option value="NU">Niue</option>
											<option value="NF">Norfolk Island</option>
											<option value="MP">Northern Mariana Islands</option>
											<option value="NO">Norway</option>
											<option value="OM">Oman</option>
											<option value="PK">Pakistan</option>
											<option value="PW">Palau</option>
											<option value="PS">Palestine, State of</option>
											<option value="PA">Panama</option>
											<option value="PG">Papua New Guinea</option>
											<option value="PY">Paraguay</option>
											<option value="PE">Peru</option>
											<option value="PH">Philippines</option>
											<option value="PN">Pitcairn</option>
											<option value="PL">Poland</option>
											<option value="PT">Portugal</option>
											<option value="PR">Puerto Rico</option>
											<option value="QA">Qatar</option>
											<option value="RE">Réunion</option>
											<option value="RO">Romania</option>
											<option value="RU">Russian Federation</option>
											<option value="RW">Rwanda</option>
											<option value="BL">Saint Barthélemy</option>
											<option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
											<option value="KN">Saint Kitts and Nevis</option>
											<option value="LC">Saint Lucia</option>
											<option value="MF">Saint Martin (French part)</option>
											<option value="PM">Saint Pierre and Miquelon</option>
											<option value="VC">Saint Vincent and the Grenadines</option>
											<option value="WS">Samoa</option>
											<option value="SM">San Marino</option>
											<option value="ST">Sao Tome and Principe</option>
											<option value="SA">Saudi Arabia</option>
											<option value="SN">Senegal</option>
											<option value="RS">Serbia</option>
											<option value="SC">Seychelles</option>
											<option value="SL">Sierra Leone</option>
											<option value="SG">Singapore</option>
											<option value="SX">Sint Maarten (Dutch part)</option>
											<option value="SK">Slovakia</option>
											<option value="SI">Slovenia</option>
											<option value="SB">Solomon Islands</option>
											<option value="SO">Somalia</option>
											<option value="ZA">South Africa</option>
											<option value="GS">South Georgia and the South Sandwich Islands</option>
											<option value="SS">South Sudan</option>
											<option value="ES">Spain</option>
											<option value="LK">Sri Lanka</option>
											<option value="SD">Sudan</option>
											<option value="SR">Suriname</option>
											<option value="SJ">Svalbard and Jan Mayen</option>
											<option value="SZ">Swaziland</option>
											<option value="SE">Sweden</option>
											<option value="CH">Switzerland</option>
											<option value="SY">Syrian Arab Republic</option>
											<option value="TW">Taiwan, Province of China[a]</option>
											<option value="TJ">Tajikistan</option>
											<option value="TZ">Tanzania, United Republic of</option>
											<option value="TH">Thailand</option>
											<option value="TL">Timor-Leste</option>
											<option value="TG">Togo</option>
											<option value="TK">Tokelau</option>
											<option value="TO">Tonga</option>
											<option value="TT">Trinidad and Tobago</option>
											<option value="TN">Tunisia</option>
											<option value="TR">Turkey</option>
											<option value="TM">Turkmenistan</option>
											<option value="TC">Turks and Caicos Islands</option>
											<option value="TV">Tuvalu</option>
											<option value="UG">Uganda</option>
											<option value="UA">Ukraine</option>
											<option value="AE">United Arab Emirates</option>
											<option value="GB">United Kingdom of Great Britain and Northern Ireland</option>
											<option value="US">United States of America</option>
											<option value="UM">United States Minor Outlying Islands</option>
											<option value="UY">Uruguay</option>
											<option value="UZ">Uzbekistan</option>
											<option value="VU">Vanuatu</option>
											<option value="VE">Venezuela (Bolivarian Republic of)</option>
											<option value="VN">Viet Nam</option>
											<option value="VG">Virgin Islands (British)</option>
											<option value="VI">Virgin Islands (U.S.)</option>
											<option value="WF">Wallis and Futuna</option>
											<option value="EH">Western Sahara</option>
											<option value="YE">Yemen</option>
											<option value="ZM">Zambia</option>
											<option value="ZW">Zimbabwe</option>
										</select>
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">									
										<select list="gradelevel" name="author_gradelevel"> 
											<option value="" disabled selected>Grade Level</option>
											<option value="grade1">Grade 1</option>
											<option value="grade2">Grade 2</option>
											<option value="grade3">Grade 3</option>
											<option value="grade4">Grade 4</option>
											<option value="grade5">Grade 5</option>
											<option value="grade6">Grade 6</option>
											<option value="grade7">Grade 7</option>
											<option value="grade8">Grade 8</option>
											<option value="grade9">Grade 9</option>
											<option value="grade10">Grade 10</option>
											<option value="grade11">Grade 11</option>
											<option value="grade12">Grade 12</option>
											<option value="university">University</option>
										</select>
									</div>
								</div>
								<div class="one_sixth">
									<div class="filter-inner">
										<?php
											// Get campaign cause
											$campaign_categories = get_terms( 'campaign_category', 'orderby=count&hide_empty=0' );
											//print_r($campaign_categories); 
										?>

										<select name="campaign_cause">
											<option value="" disabled selected>Cause</option>
											<?php 
												//foreach ($campaign_categories as $campaign_category) {														
													//echo "<option value=" . $campaign_category->slug . ">" . $campaign_category->name .  "</option>";	
												//}
												$campaign_posts = $campaigns->posts; 
												
												//print_r($campaigns->posts);
												foreach ($campaign_posts as $campaign_post) {
													//echo "<li>" . $campaign_post->ID . "</li>";
													//$campaign_ID[] = $campaign_post->ID;
													//print_r($campaign_post);
													$category_names = get_the_terms( $campaign_post->ID, 'campaign_category' );
													foreach ($category_names as $category_name) {
														//echo "<li>" . $category_name->name . "</li>";
														$category_term_name[] = $category_name->name;
													}
												}
												$category_term_name = array_unique($category_term_name);
					
												foreach ($category_term_name as $key => $value) { ?>
													<option value="<?php echo $value; ?>"><?php echo $value; ?></option>
												<?php }												
											?>

										</select>
									</div>									
								</div>
								<div class="filter-inner submit">
									<input type="submit" value="SEARCH">
								</div>
							</form>
							</div>	
							
							
																					
						<?php get_template_part( 'partials/content', 'leaderboard' ); ?>
					</div>
				</main><!-- .site-main -->
				<?php 
					//get_sidebar('leaderboard');				
				?>
			</div><!-- .layout-wrapper -->
		<?php 
		endwhile;
	endif;

get_footer();