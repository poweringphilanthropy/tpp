<div id="secondary" class="widget-area sidebar sidebar-get-inspired" role="complementary">
    <?php dynamic_sidebar('sidebar_get_inspired') ?>
</div><!-- #secondary -->