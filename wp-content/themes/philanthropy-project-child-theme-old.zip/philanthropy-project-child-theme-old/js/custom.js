jQuery(document).ready(function($) {
    jQuery(".campaigns-grid-wrapper").jscroll({
        autoTrigger: false,
        nextSelecter: 'a.load-more-button',
        callback: function() {
            setTimeout(delayedMasonry, 600)
        }
    });


    $(".campaign-sharing.share").appendTo('.campaign-details').css({
        'float': 'left',
        'width': '100%'
    });

    $("#impact-target").prependTo('.content-area');

    jQuery('#volunteerModalOpen').animatedModal({
        modalTarget: 'volunteerModal',
        animatedIn:'fadeInDown',
        animatedOut:'flipOutY',
        color: '#fff'
    });

});

function delayedMasonry() {
    jQuery(".masonry-grid").masonry();
}
