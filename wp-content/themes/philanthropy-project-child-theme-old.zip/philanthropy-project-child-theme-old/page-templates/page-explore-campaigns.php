<?php
/**
 * Template name: Explore Campaigns
 */

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script('jscroll', get_stylesheet_directory_uri().'/js/jquery.jscroll.min.js', false, '2.3.5');
});

/* add_action('wp_footer', function() {
    ?>
    <script>
        jQuery(".campaigns-grid-wrapper").jscroll();
    </script>
    <?php
}); */

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$next = add_query_arg('offset', $offset + 15, site_url('/explore/'));


$campaigns = Charitable_Campaigns::query([
    'post__not_in' => [PHILANTHROPY_PROJECT_CAMPAIGN_ID],
    'offset'       => $offset
]);

if (!$offset)
    get_header();

?>

<?php if (!$offset): ?>
    <main id="main" class="site-main site-content cf" role="main">
        <div class="layout-wrapper">
            <div id="primary" class="content-area no-sidebar">
                <?php

                if (have_posts()) :
                    while (have_posts()) :
                        the_post();
                        get_template_part('partials/content', 'page');

                    endwhile;
                endif;

                ?>

                <?php echo facetwp_display( 'facet', 'campaign_categories' ); ?>
                <?php echo facetwp_display( 'facet', 'test' ); ?>
                <div class="campaigns-grid-wrapper">
<?php endif; ?>
                    <?php

                    //mdd($campaigns);
                    charitable_template_campaign_loop($campaigns, 3);

                    wp_reset_postdata();

                    if ($campaigns->max_num_pages > 1) : ?>

                        <p class="center">
                            <a class="button button-alt"
                               href="<?= $next ?>">
                                Load More
                            </a>
                        </p>

                    <?php endif ?>
                    <?php if ($offset): ?>
                    <script>
                        function delayedMasonry() {
                            jQuery(".masonry-grid").masonry();
                        }
                        setTimeout(delayedMasonry, 600);

                    </script>
                    <?php endif; ?>
                    <?php if (!$offset): ?>
                </div>
            </div><!-- #primary -->
        </div><!-- .layout-wrapper -->
    </main><!-- #main -->
<?php endif; ?>
<?php if (!$offset) get_footer();