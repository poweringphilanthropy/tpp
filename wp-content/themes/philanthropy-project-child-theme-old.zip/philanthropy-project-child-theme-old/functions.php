<?php

define( 'PHILANTHROPY_PROJECT_CAMPAIGN_ID', 4574 );

add_filter( 'oembed_ttl', function() {
	return 1; 
});
add_filter( 'embed_cache_oembed_types', function() {
	return array();
});

add_filter( 'edd_log_test_payment_stats', '__return_true' );

/**
 * Prepare child theme. 
 *
 * This enqueues the child theme's style.css file after first loading
 * the main theme's stylesheet.
 *
 * @return  void
 * @since   1.0.0
 */
function reach_child_load_styles() {    
	wp_dequeue_style( 'reach-style' );
    wp_register_style( 'franklin-palette', get_stylesheet_directory_uri() . "/palette.css", array('reach-base'), filemtime(get_stylesheet_directory().'/palette.css') );
    wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/custom.css", array( 'franklin-palette' ), filemtime(get_stylesheet_directory().'/custom.css') );
    // wp_register_style( 'reach-child-styles', get_stylesheet_directory_uri() . "/css/main.css", array( 'franklin-palette' ), reach_get_theme()->get_theme_version() );
    wp_enqueue_style( 'reach-child-styles' );

    wp_enqueue_script('jscroll', get_stylesheet_directory_uri().'/js/jquery.jscroll.min.js', false, '2.3.5');
    wp_enqueue_script('philanthropy-project-scripts', get_stylesheet_directory_uri().'/js/custom.js', false, filemtime(get_stylesheet_directory().'/js/custom.js'));

    /* For Volunteer, but should extend to all modals eventually */
    wp_enqueue_style( 'animate', '//cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.0/animate.min.css', false, '3.2.0');
    wp_enqueue_script( 'pt-animatedModal', get_stylesheet_directory_uri() . '/js/animatedModal.min.js', false, '1.0');
    wp_enqueue_script('font-awesome', 'https://use.fontawesome.com/4897c4c6a4.js', false, false);


}

add_action( 'wp_enqueue_scripts', 'reach_child_load_styles', 100 );

/**
 * Set up child theme
 */
function franklin_child_after_setup_theme() {
	register_sidebar( array(
		'id'              => 'sidebar_get_inspired',
		'name'            => __( 'Get inspired sidebar', 'reach' ),
		'description'     => __( 'The get inspired sidebar.', 'reach' ),
		'before_widget'   => '<aside id="%1$s" class="widget cf %2$s">',
		'after_widget'    => '</aside>',
		'before_title'    => '<div class="title-wrapper"><h4 class="widget-title">',
		'after_title'     => '</h4></div>'
	));

    register_sidebar( array(
        'id'              => 'sidebar_tpp_campaign',            
        'name'            => __( 'Philanthropy Project Campaign - sidebar', 'reach' ),
        'description'     => __( 'The sidebar on The Philanthropy Project campaign.', 'reach' ),
        'before_widget'   => '<aside id="%1$s" class="widget cf %2$s">',
        'after_widget'    => '</aside>',
        'before_title'    => '<div class="title-wrapper"><h4 class="widget-title">',
        'after_title'     => '</h4></div>'
    ));

    register_sidebar( array(
        'id'            => 'tpp_campaign_after_content',            
        'name'          => __( 'Philanthropy Project Campaign Campaign - below content', 'reach' ),
        'description'   => __( 'Displayed below the Philanthropy Project campaign\'s content, but above the comment section.', 'reach' ),
        'before_widget' => '<aside id="%1$s" class="widget block content-block cf %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<div class="title-wrapper"><h3 class="widget-title">',
        'after_title'   => '</h3></div>'
    ));    
    register_sidebar( array(
        'id'            => 'leaderboard',            
        'name'          => __( 'Leaderboard', 'reach' ),
        'description'   => __( 'Displayed only on leaderboard pages.', 'reach' ),
        'before_widget' => '<aside id="%1$s" class="widget block content-block cf %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<div class="title-wrapper"><h3 class="widget-title">',
        'after_title'   => '</h3></div>'
    ));     
}

add_action('after_setup_theme', 'franklin_child_after_setup_theme');

/**
 * Add special body class to TPP campaign page. 
 *
 * @param   string[] $classes
 * @return  string[]
 * @since   1.1.1
 */
function tpp_custom_campaign_body_class( $classes ) {
    if ( PHILANTHROPY_PROJECT_CAMPAIGN_ID == get_the_ID() ) {
        $classes[] = 'tpp-campaign';
    }

    return $classes;
}

add_filter( 'body_class', 'tpp_custom_campaign_body_class' );

/**
 * Remove the TPP campaign from the archive query.
 *
 * @param   WP_Query $wp_query
 * @return  void
 * @since   1.1.1
 */
function tpp_remove_campaign_from_archives( $query ) {
    if ( is_admin() ) {
        return;
    }

    if ( $query->is_main_query() && is_post_type_archive('campaign') ) {
        $query->set( 'post__not_in', array( PHILANTHROPY_PROJECT_CAMPAIGN_ID ) );
    }
}

add_action( 'pre_get_posts', 'tpp_remove_campaign_from_archives' );

/**
 * Remove comment form allowed tags text.
 *
 * @param   array $defaults
 * @return  array
 */
function remove_comment_form_allowed_tags( $defaults ) {
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

add_filter( 'comment_form_defaults', 'remove_comment_form_allowed_tags' );

/**
 * Display donate button or link in the campaign summary.
 *
 * @param   Charitable_Campaign $campaign
 * @return  boolean     True if the template was displayed. False otherwise.
 * @since   1.1.1
 */
function charitable_template_donate_button( $campaign ) {
    if ( ! $campaign->has_goal() ) {
        return false;
    }

    if ( $campaign->has_ended() ) {
        return false;
    }

    $campaign->donate_button_template();

    return true;
}



// Add featured image size for the leaderboard
add_image_size( 'leaderboard-featured-img', 200, 250, true );

// additional Charitable Campaign Group taxonomy
// hook into the init action and call create_campaign_group_hierarchical_taxonomy when it fires
add_action( 'init', 'create_campaign_group_hierarchical_taxonomy', 0 );

// create the campaign group taxonomy for campaigns
function create_campaign_group_hierarchical_taxonomy() {

// add new taxonomy, make it hierarchical like categories
// first do the translations part for GUI

  $labels = array(
    'name' => _x( 'Campaign Groups', 'taxonomy general name' ),
    'singular_name' => _x( 'Campaign Group', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Campaign Groups' ),
    'all_items' => __( 'All Campaign Groups' ),
    'parent_item' => __( 'Parent Campaign Group' ),
    'parent_item_colon' => __( 'Parent Campaign Group:' ),
    'edit_item' => __( 'Edit Campaign Group' ), 
    'update_item' => __( 'Update Campaign Group' ),
    'add_new_item' => __( 'Add New Campaign Group' ),
    'new_item_name' => __( 'New Campaign Group' ),
    'menu_name' => __( 'Campaign Groups' ),
  ); 	

// Now register the taxonomy

  register_taxonomy('campaign_group',array('campaign'), array(
    'hierarchical' => true,
    'public' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'show_in_nav_menus' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'campaign-group' ),
  ));

}

//
add_action('admin_menu', 'charitable_campaign_group_tax_submenu');
 
function charitable_campaign_group_tax_submenu() {
    add_submenu_page(
        'charitable',
        'Campaign Groups',
        'Campaign Groups',
        'manage_options',
        'edit-tags.php?taxonomy=campaign_group&post_type=campaign' );
}

// Get current page URL 
function curPageURL() {
 	$pageURL = 'http';
 	if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 		$pageURL .= "://";
 	if ($_SERVER["SERVER_PORT"] != "80") {
  		$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 	} else {
  		$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 	}
 return $pageURL;
}

// Start of additional user profile fields

add_action( 'show_user_profile', 'pp_additional_user_profile_fields' );
add_action( 'edit_user_profile', 'pp_additional_user_profile_fields' );

function pp_additional_user_profile_fields( $user ) { ?>
	<h3><?php _e("Additional User Profile Information"); ?></h3>

	<table class="form-table">
		<tr>
			<th><label for="school_organization"><?php _e("School / Organization"); ?></label></th>
			<td>
				<input type="text" name="school-organization" id="school-organization" value="<?php echo esc_attr( get_the_author_meta( 'organisation', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your school/organization."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="school-type"><?php _e("Type of School / Organization"); ?></label></th>
			<td>
				<input type="text" name="school-type" id="school-type" value="<?php echo esc_attr( get_the_author_meta( 'school_type', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter the type of school/organization."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="user-grade-level"><?php _e("Grade Level"); ?></label></th>
			<td>	
				<?php
					$grade_level_value = get_the_author_meta( 'grade_level', $user->ID );
					$grade_level_array = array(
						'grade1'    => __( 'Grade 1' ),
					        'grade2'    => __( 'Grade 2' ),
					        'grade3'    => __( 'Grade 3' ),
					        'grade4'    => __( 'Grade 4' ),
					        'grade5'    => __( 'Grade 5' ),
					        'grade6'    => __( 'Grade 6' ),
					        'grade7'    => __( 'Grade 7' ),
					        'grade8'    => __( 'Grade 8' ),
					        'grade9'    => __( 'Grade 9' ),
					        'grade10'   => __( 'Grade 10' ),
					        'grade11'   => __( 'Grade 11' ),
					        'grade12'   => __( 'Grade 12' ),
					        'university'=> __( 'University' )
					);
					//print_r($grade_level_array);
				?>
					
				<select name="user-grade-level" id="user-grade-level">
					<?php
						foreach($grade_level_array as $key => $value) { ?>
							<option value="<?php echo $key; ?>"
								<?php 
									if ( $grade_level_value == $key ) {
										echo "selected";
									}									
								?>
							><?php echo $value; ?></option>
						<?php }
					?>					
				</select><br />
				<span class="description"><?php _e("Please choose grade level."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="user-address"><?php _e("Address"); ?></label></th>
			<td>
				<input type="text" name="user-address" id="user-address" value="<?php echo esc_attr( get_the_author_meta( 'donor_address', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your address."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="user-address-2"><?php _e("Address 2"); ?></label></th>
			<td>
				<input type="text" name="user-address-2" id="user-address-2" value="<?php echo esc_attr( get_the_author_meta( 'donor_address_2', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your second address."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="user-city"><?php _e("City"); ?></label></th>
			<td>
				<input type="text" name="user-city" id="user-city" value="<?php echo esc_attr( get_the_author_meta( 'donor_city', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your city."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="user-state"><?php _e("State"); ?></label></th>
			<td>
				<input type="text" name="user-state" id="user-state" value="<?php echo esc_attr( get_the_author_meta( 'donor_state', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your state."); ?></span>
			</td>
		</tr>
		<tr>
			<th><label for="user-postcode"><?php _e("Postcode / ZIP code"); ?></label></th>
			<td>
				<input type="text" name="user-postcode" id="user-postcode" value="<?php echo esc_attr( get_the_author_meta( 'donor_postcode', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your postal code."); ?></span>
			</td>
		</tr>		
		<tr>
			<th><label for="user-country"><?php _e("Country"); ?></label></th>
			<td>
				
				<?php
					$user_country_value = get_the_author_meta( 'donor_country', $user->ID );
					$user_country_array = array(
						'AF'    => __( 'Afghanistan' ),
						'AX'    => __( 'Åland Islands' ),
						'AL'    => __( 'Albania' ),
						'DZ'    => __( 'Algeria' ),
						'AD'    => __( 'Andorra' ),
						'AO'    => __( 'Angola' ),
						'AI'    => __( 'Anguilla' ),
						'AQ'    => __( 'Antarctica' ),
						'AG'    => __( 'Antigua and Barbuda' ),
						'AR'    => __( 'Argentina' ),
						'AM'    => __( 'Armenia' ),
						'AW'    => __( 'Aruba' ),
						'AU'    => __( 'Australia' ),
						'AT'    => __( 'Austria' ),
						'AZ'    => __( 'Azerbaijan' ),
						'BS'    => __( 'Bahamas' ),
						'BH'    => __( 'Bahrain' ),
						'BD'    => __( 'Bangladesh' ),
						'BB'    => __( 'Barbados' ),
						'BY'    => __( 'Belarus' ),
						'BE'    => __( 'Belgium' ),
						'PW'    => __( 'Belau' ),
						'BZ'    => __( 'Belize' ),
						'BJ'    => __( 'Benin' ),
						'BM'    => __( 'Bermuda' ),
						'BT'    => __( 'Bhutan' ),
						'BO'    => __( 'Bolivia' ),
						'BQ'    => __( 'Bonaire, Saint Eustatius and Saba' ),
						'BA'    => __( 'Bosnia and Herzegovina' ),
						'BW'    => __( 'Botswana' ),
						'BV'    => __( 'Bouvet Island' ),
						'BR'    => __( 'Brazil' ),
						'IO'    => __( 'British Indian Ocean Territory' ),
						'VG'    => __( 'British Virgin Islands' ),
						'BN'    => __( 'Brunei' ),
						'BG'    => __( 'Bulgaria' ),
						'BF'    => __( 'Burkina Faso' ),
						'BI'    => __( 'Burundi' ),
						'KH'    => __( 'Cambodia' ),
						'CM'    => __( 'Cameroon' ),
						'CA'    => __( 'Canada' ),
						'CV'    => __( 'Cape Verde' ),
						'KY'    => __( 'Cayman Islands' ),
						'CF'    => __( 'Central African Republic' ),
						'TD'    => __( 'Chad' ),
						'CL'    => __( 'Chile' ),
						'CN'    => __( 'China' ),
						'CX'    => __( 'Christmas Island' ),
						'CC'    => __( 'Cocos (Keeling) Islands' ),
						'CO'    => __( 'Colombia' ),
						'KM'    => __( 'Comoros' ),
						'CG'    => __( 'Congo (Brazzaville)' ),
						'CD'    => __( 'Congo (Kinshasa)' ),
						'CK'    => __( 'Cook Islands' ),
						'CR'    => __( 'Costa Rica' ),
						'HR'    => __( 'Croatia' ),
						'CU'    => __( 'Cuba' ),
						'CW'    => __( 'CuraÇao' ),
						'CY'    => __( 'Cyprus' ),
						'CZ'    => __( 'Czech Republic' ),
						'DK'    => __( 'Denmark' ),
						'DJ'    => __( 'Djibouti' ),
						'DM'    => __( 'Dominica' ),
						'DO'    => __( 'Dominican Republic' ),
						'EC'    => __( 'Ecuador' ),
						'EG'    => __( 'Egypt' ),
						'SV'    => __( 'El Salvador' ),
						'GQ'    => __( 'Equatorial Guinea' ),
						'ER'    => __( 'Eritrea' ),
						'EE'    => __( 'Estonia' ),
						'ET'    => __( 'Ethiopia' ),
						'FK'    => __( 'Falkland Islands' ),
						'FO'    => __( 'Faroe Islands' ),
						'FJ'    => __( 'Fiji' ),
						'FI'    => __( 'Finland' ),
						'FR'    => __( 'France' ),
						'GF'    => __( 'French Guiana' ),
						'PF'    => __( 'French Polynesia' ),
						'TF'    => __( 'French Southern Territories' ),
						'GA'    => __( 'Gabon' ),
						'GM'    => __( 'Gambia' ),
						'GE'    => __( 'Georgia' ),
						'DE'    => __( 'Germany' ),
						'GH'    => __( 'Ghana' ),
						'GI'    => __( 'Gibraltar' ),
						'GR'    => __( 'Greece' ),
						'GL'    => __( 'Greenland' ),
						'GD'    => __( 'Grenada' ),
						'GP'    => __( 'Guadeloupe' ),
						'GT'    => __( 'Guatemala' ),
						'GG'    => __( 'Guernsey' ),
						'GN'    => __( 'Guinea' ),
						'GW'    => __( 'Guinea-Bissau' ),
						'GY'    => __( 'Guyana' ),
						'HT'    => __( 'Haiti' ),
						'HM'    => __( 'Heard Island and McDonald Islands' ),
						'HN'    => __( 'Honduras' ),
						'HK'    => __( 'Hong Kong' ),
						'HU'    => __( 'Hungary' ),
						'IS'    => __( 'Iceland' ),
						'IN'    => __( 'India' ),
						'ID'    => __( 'Indonesia' ),
						'IR'    => __( 'Iran' ),
						'IQ'    => __( 'Iraq' ),
						'IE'    => __( 'Republic of Ireland' ),
						'IM'    => __( 'Isle of Man' ),
						'IL'    => __( 'Israel' ),
						'IT'    => __( 'Italy' ),
						'CI'    => __( 'Ivory Coast' ),
						'JM'    => __( 'Jamaica' ),
						'JP'    => __( 'Japan' ),
						'JE'    => __( 'Jersey' ),
						'JO'    => __( 'Jordan' ),
						'KZ'    => __( 'Kazakhstan' ),
						'KE'    => __( 'Kenya' ),
						'KI'    => __( 'Kiribati' ),
						'KW'    => __( 'Kuwait' ),
						'KG'    => __( 'Kyrgyzstan' ),
						'LA'    => __( 'Laos' ),
						'LV'    => __( 'Latvia' ),
						'LB'    => __( 'Lebanon' ),
						'LS'    => __( 'Lesotho' ),
						'LR'    => __( 'Liberia' ),
						'LY'    => __( 'Libya' ),
						'LI'    => __( 'Liechtenstein' ),
						'LT'    => __( 'Lithuania' ),
						'LU'    => __( 'Luxembourg' ),
						'MO'    => __( 'Macao S.A.R., China' ),
						'MK'    => __( 'Macedonia' ),
						'MG'    => __( 'Madagascar' ),
						'MW'    => __( 'Malawi' ),
						'MY'    => __( 'Malaysia' ),
						'MV'    => __( 'Maldives' ),
						'ML'    => __( 'Mali' ),
						'MT'    => __( 'Malta' ),
						'MH'    => __( 'Marshall Islands' ),
						'MQ'    => __( 'Martinique' ),
						'MR'    => __( 'Mauritania' ),
						'MU'    => __( 'Mauritius' ),
						'YT'    => __( 'Mayotte' ),
						'MX'    => __( 'Mexico' ),   
						'FM'    => __( 'Micronesia' ),
						'MD'    => __( 'Moldova' ),   
						'MC'    => __( 'Monaco' ),    
						'MN'    => __( 'Mongolia' ),  
						'ME'    => __( 'Montenegro' ), 
						'MS'    => __( 'Montserrat' ),                              
						'MA'    => __( 'Morocco' ),                              
						'MZ'    => __( 'Mozambique' ),                              
						'MM'    => __( 'Myanmar' ),                              
						'NA'    => __( 'Namibia' ),                              
						'NR'    => __( 'Nauru' ),                              
						'NP'    => __( 'Nepal' ),                              
						'NL'    => __( 'Netherlands' ),                              
						'AN'    => __( 'Netherlands Antilles' ),                              
						'NC'    => __( 'New Caledonia' ),                              
						'NZ'    => __( 'New Zealand' ),                              
						'NI'    => __( 'Nicaragua' ),                              
						'NE'    => __( 'Niger' ),                              
						'NG'    => __( 'Nigeria' ),                              
						'NU'    => __( 'Niue' ),                              
						'NF'    => __( 'Norfolk Island' ),                              
						'KP'    => __( 'North Korea' ),                              
						'NO'    => __( 'Norway' ),                              
						'OM'    => __( 'Oman' ),                              
						'PK'    => __( 'Pakistan' ),                              
						'PS'    => __( 'Palestinian Territory' ),                              
						'PA'    => __( 'Panama' ),                              
						'PG'    => __( 'Papua New Guinea' ),                              
						'PY'    => __( 'Paraguay' ),                              
						'PE'    => __( 'Peru' ),                              
						'PH'    => __( 'Philippines' ),                              
						'PN'    => __( 'Pitcairn' ),                              
						'PL'    => __( 'Poland' ),                              
						'PT'    => __( 'Portugal' ),                              
						'QA'    => __( 'Qatar' ),                              
						'RE'    => __( 'Reunion' ),                              
						'RO'    => __( 'Romania' ),                              
						'RU'    => __( 'Russia' ),                              
						'RW'    => __( 'Rwanda' ),                              
						'BL'    => __( 'Saint Barthélemy' ),                              
						'SH'    => __( 'Saint Helena' ),                              
						'KN'    => __( 'Saint Kitts and Nevis' ),                              
						'LC'    => __( 'Saint Lucia' ),                              
						'MF'    => __( 'Saint Martin (French part)' ),                              
						'SX'    => __( 'Saint Martin (Dutch part)' ),                              
						'PM'    => __( 'Saint Pierre and Miquelon' ),                              
						'VC'    => __( 'Saint Vincent and the Grenadines' ),                              
						'SM'    => __( 'San Marino' ),                              
						'ST'    => __( 'São Tomé and Príncipe' ),                              
						'SA'    => __( 'Saudi Arabia' ),                              
						'SN'    => __( 'Senegal' ),                              
						'RS'    => __( 'Serbia' ),                              
						'SC'    => __( 'Seychelles' ),                              
						'SL'    => __( 'Sierra Leone' ),                              
						'SG'    => __( 'Singapore' ),                              
						'SK'    => __( 'Slovakia' ),                              
						'SI'    => __( 'Slovenia' ),                              
						'SB'    => __( 'Solomon Islands' ),                              
						'SO'    => __( 'Somalia' ),                              
						'ZA'    => __( 'South Africa' ),                              
						'GS'    => __( 'South Georgia/Sandwich Islands' ),                              
						'KR'    => __( 'South Korea' ),                              
						'SS'    => __( 'South Sudan' ),                              
						'ES'    => __( 'Spain' ),                              
						'LK'    => __( 'Sri Lanka' ),                              
						'SD'    => __( 'Sudan' ),                              
						'SR'    => __( 'Suriname' ),                              
						'SJ'    => __( 'Svalbard and Jan Mayen' ),                              
						'SZ'    => __( 'Swaziland' ),                              
						'SE'    => __( 'Sweden' ),                              
						'CH'    => __( 'Switzerland' ),                              
						'SY'    => __( 'Syria' ),                              
						'TW'    => __( 'Taiwan' ),                              
						'TJ'    => __( 'Tajikistan' ),                              
						'TZ'    => __( 'Tanzania' ),                              
						'TH'    => __( 'Thailand' ),                              
						'TL'    => __( 'Timor-Leste' ),                              
						'TG'    => __( 'Togo' ),                              
						'TK'    => __( 'Tokelau' ),                              
						'TO'    => __( 'Tonga' ),                              
						'TT'    => __( 'Trinidad and Tobago' ),                              
						'TN'    => __( 'Tunisia' ),                              
						'TR'    => __( 'Turkey' ),                              
						'TM'    => __( 'Turkmenistan' ),                              
						'TC'    => __( 'Turks and Caicos Islands' ),                              
						'TV'    => __( 'Tuvalu' ),                              
						'UG'    => __( 'Uganda' ),                              
						'UA'    => __( 'Ukraine' ),                              
						'AE'    => __( 'United Arab Emirates' ),                              
						'GB'    => __( 'United Kingdom (UK)' ),                              
						'US'    => __( 'United States (US)' ),                              
						'UY'    => __( 'Uruguay' ),                              
						'UZ'    => __( 'Uzbekistan' ),                              
						'VU'    => __( 'Vanuatu' ),                              
						'VA'    => __( 'Vatican' ),                              
						'VE'    => __( 'Venezuela' ),                              
						'VN'    => __( 'Vietnam' ),                              
						'WF'    => __( 'Wallis and Futuna' ),                              
						'EH'    => __( 'Western Sahara' ),                              
						'WS'    => __( 'Western Samoa' ),                              
						'YE'    => __( 'Yemen' ),                              
						'ZM'    => __( 'Zambia' ),                              
						'ZW'    => __( 'Zimbabwe' )
					);
					//print_r($user_country_array);
				?>
					
				<select name="user-country" id="user-country">
					<?php
						foreach($user_country_array as $key => $value) { ?>
							<option value="<?php echo $key; ?>"
								<?php 
									if ( $user_country_value == $key ) {
										echo "selected";
									}									
								?>
							><?php echo $value; ?></option>
						<?php }
					?>					
				</select><br />
				
				<span class="description"><?php _e("Please enter your country."); ?></span>
			</td>
		</tr>
	</table>
<?php }

// save the field entries
add_action( 'personal_options_update', 'save_pp_additional_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_pp_additional_user_profile_fields' );

function save_pp_additional_user_profile_fields( $user_id ) {
	if ( !current_user_can( 'edit_user', $user_id ) ) { return false; }
	
	update_user_meta( $user_id, 'organisation', $_POST['school-organization'] );
	update_user_meta( $user_id, 'school_type', $_POST['school-type'] );
	update_user_meta( $user_id, 'grade_level', $_POST['user-grade-level'] );
	update_user_meta( $user_id, 'donor_address', $_POST['user-address'] );
	update_user_meta( $user_id, 'donor_address_2', $_POST['user-address-2'] );
	update_user_meta( $user_id, 'donor_city', $_POST['user-city'] );
	update_user_meta( $user_id, 'donor_state', $_POST['user-state'] );
	update_user_meta( $user_id, 'donor_postcode', $_POST['user-postcode'] );
	update_user_meta( $user_id, 'donor_country', $_POST['user-country'] );
	}
	
	// Paginate campaigns in the leaderboard
function paginate_campaigns() {
    global $campaigns, $wp_rewrite;

    //$campaigns->query_vars['paged'] > 1 ? $current = $campaigns->query_vars['paged'] : $current = 1;
    $pagination = array(
        'base' => @add_query_arg('page','%#%'),
        'format' => '',
        'total' => $campaigns->max_num_pages,
        'current' => $current,
        'show_all' => true,
        'type' => 'array',
        'prev_next' => false,
        //'next_text' => __('Next »')
    );
    
    if( $wp_rewrite->using_permalinks() )
        $pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 'page', get_pagenum_link( 1 ) ) ) . '?page=%#%/', 'paged' );

    if( !empty($campaigns->query_vars['s']) )
        $pagination['add_args'] = array( 's' => get_query_var( 's' ) );

    $pages = paginate_links( $pagination );
	//echo "<h2>";
	//var_dump($pages);
	//echo "</h2>";
    if( is_array( $pages ) ) {     	
        $paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
        echo '<ul class="pagination">';
        //echo '<li><span>'. $paged . ' of ' . $wp_query->max_num_pages .'</span></li>';
        foreach ( $pages as $page ) {  
            echo "<li>$page</li>";                     
        }
        echo '</ul>';               
    }
    
    
    
function rt_pagination($pages = '', $range = 4) {
    $html = null;
    $showitems = ($range * 2) + 1;
    global $paged;
    if (empty($paged)) $paged = 1;
    if ($pages == '') {
        global $wp_query;
        $pages = $wp_query->max_num_pages;
        if (!$pages) {
            $pages = 1;
        }
    }

    if (1 != $pages) {

        $html .= '<div class="rt-pagination">';
        $html .= '<ul class="pagination">';

        if ($paged > 1 && $showitems < $pages) $html .= "<li><a href='" . get_pagenum_link($paged - 1) . "' aria-label='Previous'><i class='fa fa-chevron-left' aria-hidden='true'></i></li>";

        for ($i = 1; $i <= $pages; $i++) {

            if (1 != $pages && (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems)) {
                $html .= ($paged == $i) ? "<li class=\"active\"><span>" . $i . "</span>

    </li>" : "<li><a href='" . get_pagenum_link($i) . "'>" . $i . "</a></li>";

            }

        }

        if ($paged < $pages && $showitems < $pages) $html .= "<li><a href=\"" . get_pagenum_link($paged + 1) . "\"  aria-label='Next'><i class='fa fa-chevron-right' aria-hidden='true'></i></a></li>";

        $html .= "</ul>";
        $html .= "</div>";
    }

    return $html;

}

function mrCountryList() {
    return array(
        'AF' => __('Afghanistan'),
        'AX' => __('Åland Islands'),
        'AL' => __('Albania'),
        'DZ' => __('Algeria'),
        'AD' => __('Andorra'),
        'AO' => __('Angola'),
        'AI' => __('Anguilla'),
        'AQ' => __('Antarctica'),
        'AG' => __('Antigua and Barbuda'),
        'AR' => __('Argentina'),
        'AM' => __('Armenia'),
        'AW' => __('Aruba'),
        'AU' => __('Australia'),
        'AT' => __('Austria'),
        'AZ' => __('Azerbaijan'),
        'BS' => __('Bahamas'),
        'BH' => __('Bahrain'),
        'BD' => __('Bangladesh'),
        'BB' => __('Barbados'),
        'BY' => __('Belarus'),
        'BE' => __('Belgium'),
        'PW' => __('Belau'),
        'BZ' => __('Belize'),
        'BJ' => __('Benin'),
        'BM' => __('Bermuda'),
        'BT' => __('Bhutan'),
        'BO' => __('Bolivia'),
        'BQ' => __('Bonaire, Saint Eustatius and Saba'),
        'BA' => __('Bosnia and Herzegovina'),
        'BW' => __('Botswana'),
        'BV' => __('Bouvet Island'),
        'BR' => __('Brazil'),
        'IO' => __('British Indian Ocean Territory'),
        'VG' => __('British Virgin Islands'),
        'BN' => __('Brunei'),
        'BG' => __('Bulgaria'),
        'BF' => __('Burkina Faso'),
        'BI' => __('Burundi'),
        'KH' => __('Cambodia'),
        'CM' => __('Cameroon'),
        'CA' => __('Canada'),
        'CV' => __('Cape Verde'),
        'KY' => __('Cayman Islands'),
        'CF' => __('Central African Republic'),
        'TD' => __('Chad'),
        'CL' => __('Chile'),
        'CN' => __('China'),
        'CX' => __('Christmas Island'),
        'CC' => __('Cocos (Keeling) Islands'),
        'CO' => __('Colombia'),
        'KM' => __('Comoros'),
        'CG' => __('Congo (Brazzaville)'),
        'CD' => __('Congo (Kinshasa)'),
        'CK' => __('Cook Islands'),
        'CR' => __('Costa Rica'),
        'HR' => __('Croatia'),
        'CU' => __('Cuba'),
        'CW' => __('CuraÇao'),
        'CY' => __('Cyprus'),
        'CZ' => __('Czech Republic'),
        'DK' => __('Denmark'),
        'DJ' => __('Djibouti'),
        'DM' => __('Dominica'),
        'DO' => __('Dominican Republic'),
        'EC' => __('Ecuador'),
        'EG' => __('Egypt'),
        'SV' => __('El Salvador'),
        'GQ' => __('Equatorial Guinea'),
        'ER' => __('Eritrea'),
        'EE' => __('Estonia'),
        'ET' => __('Ethiopia'),
        'FK' => __('Falkland Islands'),
        'FO' => __('Faroe Islands'),
        'FJ' => __('Fiji'),
        'FI' => __('Finland'),
        'FR' => __('France'),
        'GF' => __('French Guiana'),
        'PF' => __('French Polynesia'),
        'TF' => __('French Southern Territories'),
        'GA' => __('Gabon'),
        'GM' => __('Gambia'),
        'GE' => __('Georgia'),
        'DE' => __('Germany'),
        'GH' => __('Ghana'),
        'GI' => __('Gibraltar'),
        'GR' => __('Greece'),
        'GL' => __('Greenland'),
        'GD' => __('Grenada'),
        'GP' => __('Guadeloupe'),
        'GT' => __('Guatemala'),
        'GG' => __('Guernsey'),
        'GN' => __('Guinea'),
        'GW' => __('Guinea-Bissau'),
        'GY' => __('Guyana'),
        'HT' => __('Haiti'),
        'HM' => __('Heard Island and McDonald Islands'),
        'HN' => __('Honduras'),
        'HK' => __('Hong Kong'),
        'HU' => __('Hungary'),
        'IS' => __('Iceland'),
        'IN' => __('India'),
        'ID' => __('Indonesia'),
        'IR' => __('Iran'),
        'IQ' => __('Iraq'),
        'IE' => __('Republic of Ireland'),
        'IM' => __('Isle of Man'),
        'IL' => __('Israel'),
        'IT' => __('Italy'),
        'CI' => __('Ivory Coast'),
        'JM' => __('Jamaica'),
        'JP' => __('Japan'),
        'JE' => __('Jersey'),
        'JO' => __('Jordan'),
        'KZ' => __('Kazakhstan'),
        'KE' => __('Kenya'),
        'KI' => __('Kiribati'),
        'KW' => __('Kuwait'),
        'KG' => __('Kyrgyzstan'),
        'LA' => __('Laos'),
        'LV' => __('Latvia'),
        'LB' => __('Lebanon'),
        'LS' => __('Lesotho'),
        'LR' => __('Liberia'),
        'LY' => __('Libya'),
        'LI' => __('Liechtenstein'),
        'LT' => __('Lithuania'),
        'LU' => __('Luxembourg'),
        'MO' => __('Macao S.A.R., China'),
        'MK' => __('Macedonia'),
        'MG' => __('Madagascar'),
        'MW' => __('Malawi'),
        'MY' => __('Malaysia'),
        'MV' => __('Maldives'),
        'ML' => __('Mali'),
        'MT' => __('Malta'),
        'MH' => __('Marshall Islands'),
        'MQ' => __('Martinique'),
        'MR' => __('Mauritania'),
        'MU' => __('Mauritius'),
        'YT' => __('Mayotte'),
        'MX' => __('Mexico'),
        'FM' => __('Micronesia'),
        'MD' => __('Moldova'),
        'MC' => __('Monaco'),
        'MN' => __('Mongolia'),
        'ME' => __('Montenegro'),
        'MS' => __('Montserrat'),
        'MA' => __('Morocco'),
        'MZ' => __('Mozambique'),
        'MM' => __('Myanmar'),
        'NA' => __('Namibia'),
        'NR' => __('Nauru'),
        'NP' => __('Nepal'),
        'NL' => __('Netherlands'),
        'AN' => __('Netherlands Antilles'),
        'NC' => __('New Caledonia'),
        'NZ' => __('New Zealand'),
        'NI' => __('Nicaragua'),
        'NE' => __('Niger'),
        'NG' => __('Nigeria'),
        'NU' => __('Niue'),
        'NF' => __('Norfolk Island'),
        'KP' => __('North Korea'),
        'NO' => __('Norway'),
        'OM' => __('Oman'),
        'PK' => __('Pakistan'),
        'PS' => __('Palestinian Territory'),
        'PA' => __('Panama'),
        'PG' => __('Papua New Guinea'),
        'PY' => __('Paraguay'),
        'PE' => __('Peru'),
        'PH' => __('Philippines'),
        'PN' => __('Pitcairn'),
        'PL' => __('Poland'),
        'PT' => __('Portugal'),
        'QA' => __('Qatar'),
        'RE' => __('Reunion'),
        'RO' => __('Romania'),
        'RU' => __('Russia'),
        'RW' => __('Rwanda'),
        'BL' => __('Saint Barthélemy'),
        'SH' => __('Saint Helena'),
        'KN' => __('Saint Kitts and Nevis'),
        'LC' => __('Saint Lucia'),
        'MF' => __('Saint Martin (French part)'),
        'SX' => __('Saint Martin (Dutch part)'),
        'PM' => __('Saint Pierre and Miquelon'),
        'VC' => __('Saint Vincent and the Grenadines'),
        'SM' => __('San Marino'),
        'ST' => __('São Tomé and Príncipe'),
        'SA' => __('Saudi Arabia'),
        'SN' => __('Senegal'),
        'RS' => __('Serbia'),
        'SC' => __('Seychelles'),
        'SL' => __('Sierra Leone'),
        'SG' => __('Singapore'),
        'SK' => __('Slovakia'),
        'SI' => __('Slovenia'),
        'SB' => __('Solomon Islands'),
        'SO' => __('Somalia'),
        'ZA' => __('South Africa'),
        'GS' => __('South Georgia/Sandwich Islands'),
        'KR' => __('South Korea'),
        'SS' => __('South Sudan'),
        'ES' => __('Spain'),
        'LK' => __('Sri Lanka'),
        'SD' => __('Sudan'),
        'SR' => __('Suriname'),
        'SJ' => __('Svalbard and Jan Mayen'),
        'SZ' => __('Swaziland'),
        'SE' => __('Sweden'),
        'CH' => __('Switzerland'),
        'SY' => __('Syria'),
        'TW' => __('Taiwan'),
        'TJ' => __('Tajikistan'),
        'TZ' => __('Tanzania'),
        'TH' => __('Thailand'),
        'TL' => __('Timor-Leste'),
        'TG' => __('Togo'),
        'TK' => __('Tokelau'),
        'TO' => __('Tonga'),
        'TT' => __('Trinidad and Tobago'),
        'TN' => __('Tunisia'),
        'TR' => __('Turkey'),
        'TM' => __('Turkmenistan'),
        'TC' => __('Turks and Caicos Islands'),
        'TV' => __('Tuvalu'),
        'UG' => __('Uganda'),
        'UA' => __('Ukraine'),
        'AE' => __('United Arab Emirates'),
        'GB' => __('United Kingdom (UK)'),
        'US' => __('United States (US)'),
        'UY' => __('Uruguay'),
        'UZ' => __('Uzbekistan'),
        'VU' => __('Vanuatu'),
        'VA' => __('Vatican'),
        'VE' => __('Venezuela'),
        'VN' => __('Vietnam'),
        'WF' => __('Wallis and Futuna'),
        'EH' => __('Western Sahara'),
        'WS' => __('Western Samoa'),
        'YE' => __('Yemen'),
        'ZM' => __('Zambia'),
        'ZW' => __('Zimbabwe')
    );
}

function mrStateList() {
    return array(
        'AL'=>'Alabama',
        'AK'=>'Alaska',
        'AZ'=>'Arizona',
        'AR'=>'Arkansas',
        'CA'=>'California',
        'CO'=>'Colorado',
        'CT'=>'Connecticut',
        'DE'=>'Delaware',
        'DC'=>'District of Columbia',
        'FL'=>'Florida',
        'GA'=>'Georgia',
        'HI'=>'Hawaii',
        'ID'=>'Idaho',
        'IL'=>'Illinois',
        'IN'=>'Indiana',
        'IA'=>'Iowa',
        'KS'=>'Kansas',
        'KY'=>'Kentucky',
        'LA'=>'Louisiana',
        'ME'=>'Maine',
        'MD'=>'Maryland',
        'MA'=>'Massachusetts',
        'MI'=>'Michigan',
        'MN'=>'Minnesota',
        'MS'=>'Mississippi',
        'MO'=>'Missouri',
        'MT'=>'Montana',
        'NE'=>'Nebraska',
        'NV'=>'Nevada',
        'NH'=>'New Hampshire',
        'NJ'=>'New Jersey',
        'NM'=>'New Mexico',
        'NY'=>'New York',
        'NC'=>'North Carolina',
        'ND'=>'North Dakota',
        'OH'=>'Ohio',
        'OK'=>'Oklahoma',
        'OR'=>'Oregon',
        'PA'=>'Pennsylvania',
        'RI'=>'Rhode Island',
        'SC'=>'South Carolina',
        'SD'=>'South Dakota',
        'TN'=>'Tennessee',
        'TX'=>'Texas',
        'UT'=>'Utah',
        'VT'=>'Vermont',
        'VA'=>'Virginia',
        'WA'=>'Washington',
        'WV'=>'West Virginia',
        'WI'=>'Wisconsin',
        'WY'=>'Wyoming',
    );
}

function mrGradeLabel() {
    return array(
        'grade1' => __('Grade 1'),
        'grade2' => __('Grade 2'),
        'grade3' => __('Grade 3'),
        'grade4' => __('Grade 4'),
        'grade5' => __('Grade 5'),
        'grade6' => __('Grade 6'),
        'grade7' => __('Grade 7'),
        'grade8' => __('Grade 8'),
        'grade9' => __('Grade 9'),
        'grade10' => __('Grade 10'),
        'grade11' => __('Grade 11'),
        'grade12' => __('Grade 12'),
        'university' => __('University')
    );

}
}

add_filter('reach_site_title', function() {
	return '';
});
add_filter('reach_site_tagline', function() {
	return '';
});

/* HIDE ADMIN BAR */
if(!current_user_can('administrator'))
    add_filter( 'show_admin_bar', '__return_false' );


add_filter('charitable_email_headers', function($headers, $emailObj){
	error_log('EMAIL HEADERS: '.print_r($headers,1));
	error_log('EMAIL OBJECT: '.print_r($emailObj));
	return $headers;
}, 10, 2);
